#!/bin/sh
# Installs Live Background for the current user and adds a dock launcher.
set -e
UUID="live-background@bazzite.local"
SRC="$(cd "$(dirname "$0")" && pwd)/$UUID"
DEST="$HOME/.local/share/gnome-shell/extensions/$UUID"

mkdir -p "$DEST"
cp -r "$SRC/." "$DEST/"
glib-compile-schemas "$DEST/schemas"
chmod +x "$DEST/toggle.sh"

mkdir -p "$HOME/.local/share/applications"
cat > "$HOME/.local/share/applications/live-background-toggle.desktop" << DESKTOP
[Desktop Entry]
Type=Application
Name=Live Background
Comment=Pause or play the animated background
Exec=$DEST/toggle.sh
Icon=$DEST/icon.svg
Terminal=false
StartupNotify=false
Categories=Utility;
DESKTOP
update-desktop-database "$HOME/.local/share/applications" 2>/dev/null || true

echo
echo "Live Background is installed."
echo "1. Log out and log back in (GNOME on Wayland only loads new extensions at login)."
echo "2. Run:  gnome-extensions enable $UUID"
echo "3. Search your apps for 'Live Background' and pin it to the dock to pause/play."
