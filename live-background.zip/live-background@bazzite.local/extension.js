// Live Background: animated desktop backgrounds for GNOME Shell 50.
//
// Safety design: drawing runs at low main-loop priority so mouse and keyboard
// always go first, frames are rendered at reduced resolution, and a watchdog
// lowers the frame rate or pauses the animation if it ever gets too slow.

import Clutter from 'gi://Clutter';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';

import {Engine, THEMES, scaledSize} from './engine.js';
import {loadLogo, loadImage} from './logo.js';

const START_DELAY_MS = 4000;   // let the desktop finish loading first
const MIN_FPS = 10;
const HARD_LIMIT_MS = 250;     // one frame this slow pauses immediately

const LiveIndicator = GObject.registerClass(
class LiveIndicator extends PanelMenu.Button {
    _init(ext) {
        super._init(0.0, 'Live Background');
        this._ext = ext;

        this._icon = new St.Icon({
            icon_name: 'weather-clear-night-symbolic',
            style_class: 'system-status-icon',
        });
        this.add_child(this._icon);

        this._toggleItem = new PopupMenu.PopupMenuItem('Pause');
        this._toggleItem.connect('activate', () => ext.togglePaused());
        this.menu.addMenuItem(this._toggleItem);
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());

        this._themeItems = new Map();
        for (const [id, name] of THEMES) {
            const item = new PopupMenu.PopupMenuItem(name);
            item.connect('activate', () => ext.settings.set_string('theme', id));
            this.menu.addMenuItem(item);
            this._themeItems.set(id, item);
        }

        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        const prefsItem = new PopupMenu.PopupMenuItem('Settings');
        prefsItem.connect('activate', () => ext.openPreferences());
        this.menu.addMenuItem(prefsItem);

        this.sync();
    }

    sync() {
        const settings = this._ext.settings;
        const paused = settings.get_boolean('paused');
        this._toggleItem.label.text = paused ? 'Play' : 'Pause';
        this._icon.opacity = paused ? 110 : 255;
        const theme = settings.get_string('theme');
        for (const [id, item] of this._themeItems)
            item.setOrnament(id === theme ? PopupMenu.Ornament.DOT : PopupMenu.Ornament.NONE);
    }
});

export default class LiveBackgroundExtension extends Extension {
    enable() {
        this.settings = this.getSettings();
        if (this.settings.get_string('theme') === 'cyclone')
            this.settings.set_string('theme', 'storm');
        this._speed = this.settings.get_double('speed');
        this._outputs = [];
        this._signals = [];
        this._timerId = 0;
        this._delayId = 0;
        this._indicator = null;
        this._overviewActors = [];
        this._wsClones = new Map();
        this._ready = false;
        this._resetWatchdog();
        this._logo = undefined;
        this._wall = undefined;

        this._build();
        this._applyLogo();
        this._attachAll();

        this._connect(Main.layoutManager, 'monitors-changed', () => this._rebuild());
        this._connect(Main.layoutManager, 'startup-complete', () => this._raise());
        this._connect(Main.layoutManager._backgroundGroup, 'child-added', (_group, child) => {
            if (!this._outputs.some(o => o.area === child))
                this._raise();
        });
        this._connect(global.display, 'in-fullscreen-changed', () => this._updateRunning());
        this._connect(Main.overview, 'showing', () => this._scanWorkspaces());

        this._connect(this.settings, 'changed::theme', () => this._applyTheme());
        this._connect(this.settings, 'changed::paused', () => {
            if (!this.settings.get_boolean('paused'))
                this._resetWatchdog();
            this._updateRunning();
            this._indicator?.sync();
        });
        this._connect(this.settings, 'changed::speed', () => {
            this._speed = this.settings.get_double('speed');
        });
        this._connect(this.settings, 'changed::fps', () => {
            this._resetWatchdog();
            this._restartTimer();
        });
        this._connect(this.settings, 'changed::quality', () => this._rebuild());
        this._connect(this.settings, 'changed::logo-path', () => { this._logo = undefined; this._applyLogo(); });
        this._connect(this.settings, 'changed::logo-remove-bg', () => { this._logo = undefined; this._applyLogo(); });
        this._connect(this.settings, 'changed::orbs-wallpaper', () => { this._wall = undefined; this._applyLogo(); });
        this._connect(this.settings, 'changed::orbs-dim', () => this._applyLogo());
        this._connect(this.settings, 'changed::pause-fullscreen', () => this._updateRunning());
        this._connect(this.settings, 'changed::show-indicator', () => this._updateIndicator());
        this._connect(this.settings, 'changed::show-in-overview', () => this._reattach());
        this._connect(this.settings, 'changed::overview-dim', () => this._reattach());

        this._updateIndicator();

        this._delayId = GLib.timeout_add(GLib.PRIORITY_LOW, START_DELAY_MS, () => {
            this._delayId = 0;
            this._ready = true;
            this._updateRunning();
            return GLib.SOURCE_REMOVE;
        });
    }

    disable() {
        this._stop();
        if (this._delayId) {
            GLib.source_remove(this._delayId);
            this._delayId = 0;
        }
        for (const [obj, id] of this._signals)
            obj.disconnect(id);
        this._signals = [];
        this._detachAll();
        this._destroyOutputs();
        this._indicator?.destroy();
        this._indicator = null;
        this.settings = null;
    }

    togglePaused() {
        this.settings.set_boolean('paused', !this.settings.get_boolean('paused'));
    }

    _connect(obj, signal, handler) {
        this._signals.push([obj, obj.connect(signal, handler)]);
    }

    /* ----- Desktop layer ----- */

    _build() {
        const theme = this.settings.get_string('theme');
        const rs = Math.max(0.4, Math.min(1, this.settings.get_double('quality')));
        const group = Main.layoutManager._backgroundGroup;
        for (const monitor of Main.layoutManager.monitors) {
            const engine = new Engine(monitor.width, monitor.height, rs);
            this._safeStep(engine, () => {
                engine.setTheme(theme);
                engine.step(1 / 30, null);
            });

            // The actor holds the smaller image and is scaled up on the GPU.
            const area = new St.DrawingArea({
                x: monitor.x,
                y: monitor.y,
                width: scaledSize(monitor.width, rs),
                height: scaledSize(monitor.height, rs),
                reactive: false,
            });
            area.set_scale(1 / rs, 1 / rs);
            if (this._logo)
                engine.setLogo(this._logo);
            if (this._wall)
                engine.setWallpaper(this._wall);
            engine.setOption('orbsDim', this.settings.get_int('orbs-dim'));
            area.connect('repaint', a => {
                const t0 = GLib.get_monotonic_time();
                const cr = a.get_context();
                engine.paint(cr);
                cr.$dispose();
                this._paintUs += GLib.get_monotonic_time() - t0;
            });
            group.add_child(area);
            this._outputs.push({monitor, engine, area});
        }
        this._raise();
    }

    _destroyOutputs() {
        for (const o of this._outputs) {
            o.area.destroy();
            o.engine.destroy();
        }
        this._outputs = [];
    }

    _rebuild() {
        this._stop();
        this._detachAll();
        this._destroyOutputs();
        this._build();
        this._attachAll();
        this._resetWatchdog();
        this._updateRunning();
    }

    // Keep our layer directly above the wallpaper, below windows.
    _raise() {
        const group = Main.layoutManager._backgroundGroup;
        for (const o of this._outputs) {
            if (o.area.get_parent() === group)
                group.set_child_above_sibling(o.area, null);
        }
    }

    // Load the user's chosen image only when the Neon theme needs it.
    _applyLogo() {
        const theme = this.settings.get_string('theme');
        if (theme === 'orbs') {
            if (this._wall === undefined) {
                try {
                    this._wall = loadImage(this.settings.get_string('orbs-wallpaper'));
                } catch (e) {
                    console.error(`[Live Background] could not load wallpaper: ${e}`);
                    this._wall = null;
                }
            }
            for (const o of this._outputs) {
                o.engine.setWallpaper(this._wall);
                o.engine.setOption('orbsDim', this.settings.get_int('orbs-dim'));
            }
            return;
        }
        if (theme !== 'neon')
            return;
        if (this._logo === undefined) {
            try {
                this._logo = loadLogo(this.settings.get_string('logo-path'), this.settings.get_boolean('logo-remove-bg'));
            } catch (e) {
                console.error(`[Live Background] could not load image: ${e}`);
                this._logo = null;
            }
        }
        for (const o of this._outputs)
            o.engine.setLogo(this._logo);
    }

    _applyTheme() {
        this._applyLogo();
        const theme = this.settings.get_string('theme');
        for (const o of this._outputs) {
            this._safeStep(o.engine, () => {
                o.engine.setTheme(theme);
                o.engine.step(1 / 30, null);
            });
            o.area.queue_repaint();
        }
        this._resetWatchdog();
        this._indicator?.sync();
    }

    _safeStep(engine, fn) {
        try {
            fn();
        } catch (e) {
            console.error(`[Live Background] ${e}\n${e.stack}`);
        }
    }

    /* ----- Overview and app grid ----- */

    _attachAll() {
        if (!this.settings.get_boolean('show-in-overview'))
            return;
        this._attachOverview();
        this._scanWorkspaces();
    }

    _detachAll() {
        for (const a of this._overviewActors)
            a.destroy();
        this._overviewActors = [];
        for (const [wb, entry] of this._wsClones) {
            wb.disconnect(entry.destroyId);
            entry.holder.opacity = entry.prev;
        }
        this._wsClones.clear();
    }

    _reattach() {
        this._detachAll();
        this._attachAll();
    }

    _attachOverview() {
        const group = Main.layoutManager.overviewGroup;
        const anchor = Main.overview._overview;
        const dim = this.settings.get_int('overview-dim') / 100;
        for (const o of this._outputs) {
            const m = o.monitor;
            const clone = new Clutter.Clone({source: o.area, x: m.x, y: m.y, width: m.width, height: m.height});
            const shade = new St.Widget({
                x: m.x, y: m.y, width: m.width, height: m.height,
                style: `background-color: rgba(0, 0, 0, ${dim});`,
            });
            for (const a of [clone, shade]) {
                if (anchor && anchor.get_parent() === group)
                    group.insert_child_below(a, anchor);
                else
                    group.insert_child_at_index(a, 0);
                this._overviewActors.push(a);
            }
        }
    }

    _scanWorkspaces() {
        if (!this.settings.get_boolean('show-in-overview'))
            return;
        const walk = actor => {
            if (actor._backgroundGroup && actor._bgManager && typeof actor._monitorIndex === 'number')
                this._attachWorkspace(actor);
            for (const child of actor.get_children())
                walk(child);
        };
        try {
            walk(Main.layoutManager.overviewGroup);
        } catch (e) {
            console.error(`[Live Background] ${e}`);
        }
    }

    // Workspace previews (window picker and the strip above the app grid) draw
    // their own shrunken wallpaper. Hide it so the full-size animation behind
    // the overview shows straight through and everything lines up.
    _attachWorkspace(wb) {
        const holder = wb._backgroundGroup;
        if (!holder || this._wsClones.has(wb))
            return;
        const prev = holder.opacity;
        holder.opacity = 0;
        const destroyId = wb.connect('destroy', () => this._wsClones.delete(wb));
        this._wsClones.set(wb, {holder, prev, destroyId});
    }

    /* ----- Top bar icon ----- */

    _updateIndicator() {
        const show = this.settings.get_boolean('show-indicator');
        if (show && !this._indicator) {
            this._indicator = new LiveIndicator(this);
            Main.panel.addToStatusArea(this.uuid, this._indicator);
        } else if (!show && this._indicator) {
            this._indicator.destroy();
            this._indicator = null;
        }
    }

    /* ----- Running, pausing, watchdog ----- */

    _anyFullscreen() {
        const n = global.display.get_n_monitors();
        for (let i = 0; i < n; i++) {
            if (global.display.get_monitor_in_fullscreen(i))
                return true;
        }
        return false;
    }

    _shouldRun() {
        if (!this._ready || this.settings.get_boolean('paused'))
            return false;
        if (this.settings.get_boolean('pause-fullscreen') && this._anyFullscreen())
            return false;
        return true;
    }

    _updateRunning() {
        if (this._shouldRun())
            this._start();
        else
            this._stop();
    }

    _resetWatchdog() {
        this._fps = Math.max(MIN_FPS, Math.min(60, this.settings?.get_int('fps') ?? 24));
        this._avgMs = 0;
        this._slowFrames = 0;
        this._paintUs = 0;
    }

    _restartTimer() {
        if (!this._timerId)
            return;
        this._stop();
        this._start();
    }

    _start() {
        if (this._timerId)
            return;
        this._last = GLib.get_monotonic_time();
        // Low priority: input, window drawing and everything else run first.
        this._timerId = GLib.timeout_add(GLib.PRIORITY_LOW, Math.round(1000 / this._fps), () => {
            this._tick();
            return GLib.SOURCE_CONTINUE;
        });
    }

    _stop() {
        if (this._timerId) {
            GLib.source_remove(this._timerId);
            this._timerId = 0;
        }
    }

    _autoPause(reason) {
        this._stop();
        console.warn(`[Live Background] paused: ${reason}`);
        Main.notify('Live Background paused',
            'The animation was slowing your desktop down. Try a lower quality or frame rate in its settings, then press Play.');
        this.settings.set_boolean('paused', true);
    }

    _tick() {
        const t0 = GLib.get_monotonic_time();
        const dt = Math.min(0.1, (t0 - this._last) / 1e6) * this._speed;
        this._last = t0;
        const [px, py, mods] = global.get_pointer();
        // Left button held? Note whether the press started on the bare desktop
        // (so dragging inside a window never grabs anything behind it).
        const down = (mods & Clutter.ModifierType.BUTTON1_MASK) !== 0;
        if (down && !this._down) {
            const hit = global.stage.get_actor_at_pos(Clutter.PickMode.ALL, px, py);
            this._pressFree = this._outputs.some(o => o.area === hit);
        }
        if (!down)
            this._pressFree = false;
        this._down = down;
        for (const o of this._outputs) {
            const m = o.monitor;
            const inside = px >= m.x && px < m.x + m.width && py >= m.y && py < m.y + m.height;
            const ptr = inside ? {x: px - m.x, y: py - m.y, down, free: this._pressFree} : null;
            this._safeStep(o.engine, () => o.engine.step(dt, ptr));
            o.area.queue_repaint();
        }

        // Watchdog: cost of this frame's drawing plus the previous frame's paint.
        const ms = (GLib.get_monotonic_time() - t0 + this._paintUs) / 1000;
        this._paintUs = 0;
        if (ms > HARD_LIMIT_MS) {
            this._autoPause(`frame took ${Math.round(ms)} ms`);
            return;
        }
        this._avgMs = this._avgMs ? this._avgMs * 0.9 + ms * 0.1 : ms;
        const budget = 1000 / this._fps * 0.5;   // use at most half of each frame
        if (this._avgMs > budget) {
            if (++this._slowFrames > this._fps * 2) {
                this._slowFrames = 0;
                if (this._fps > MIN_FPS) {
                    this._fps = Math.max(MIN_FPS, Math.floor(this._fps * 0.7));
                    console.warn(`[Live Background] slow frames (${this._avgMs.toFixed(1)} ms), lowering to ${this._fps} fps`);
                    this._restartTimer();
                } else {
                    this._autoPause(`average frame ${this._avgMs.toFixed(1)} ms at ${MIN_FPS} fps`);
                }
            }
        } else {
            this._slowFrames = Math.max(0, this._slowFrames - 1);
        }
    }
}
