#!/bin/sh
# Pause or play Live Background (used by the dock launcher).
DIR="$(dirname "$(readlink -f "$0")")"
SCHEMA=org.gnome.shell.extensions.live-background
if [ "$(gsettings --schemadir "$DIR/schemas" get "$SCHEMA" paused)" = "true" ]; then
    gsettings --schemadir "$DIR/schemas" set "$SCHEMA" paused false
else
    gsettings --schemadir "$DIR/schemas" set "$SCHEMA" paused true
fi
