import Adw from 'gi://Adw';
import Gio from 'gi://Gio';
import Gtk from 'gi://Gtk';

import {ExtensionPreferences} from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

const THEMES = [
    ['matrix', 'Matrix rain'],
    ['code', 'Code stream'],
    ['storm', 'Thunderstorm'],
    ['spiders', 'Spiders'],
    ['starfield', 'Starfield'],
    ['fireflies', 'Fireflies'],
    ['kittens', 'Kittens'],
    ['cursorcat', 'Cursor cat'],
    ['neon', 'Neon emblem'],
    ['orbs', 'Floating orbs'],
];

export default class LiveBackgroundPrefs extends ExtensionPreferences {
    fillPreferencesWindow(window) {
        const settings = this.getSettings();
        window._settings = settings;

        const page = new Adw.PreferencesPage({title: 'Live Background', icon_name: 'weather-clear-night-symbolic'});

        const look = new Adw.PreferencesGroup({title: 'Background'});
        page.add(look);

        const ids = THEMES.map(t => t[0]);
        const themeRow = new Adw.ComboRow({
            title: 'Theme',
            model: Gtk.StringList.new(THEMES.map(t => t[1])),
        });
        themeRow.selected = Math.max(0, ids.indexOf(settings.get_string('theme')));
        themeRow.connect('notify::selected', () => settings.set_string('theme', ids[themeRow.selected]));
        settings.connect('changed::theme', () => {
            const i = ids.indexOf(settings.get_string('theme'));
            if (i >= 0 && themeRow.selected !== i)
                themeRow.selected = i;
        });
        look.add(themeRow);

        const pausedRow = new Adw.SwitchRow({title: 'Paused'});
        settings.bind('paused', pausedRow, 'active', Gio.SettingsBindFlags.DEFAULT);
        look.add(pausedRow);

        const speedRow = new Adw.SpinRow({
            title: 'Speed',
            digits: 2,
            adjustment: new Gtk.Adjustment({lower: 0.25, upper: 3, step_increment: 0.25, page_increment: 0.5}),
        });
        settings.bind('speed', speedRow, 'value', Gio.SettingsBindFlags.DEFAULT);
        look.add(speedRow);

        const neonGroup = new Adw.PreferencesGroup({title: 'Neon emblem theme', description: 'Pick an image of your own to show in the middle. With no image chosen, the centre stays empty.'});
        page.add(neonGroup);
        const imgRow = new Adw.ActionRow({title: 'Image'});
        const showPath = () => { imgRow.subtitle = settings.get_string('logo-path') || 'None chosen'; };
        showPath();
        settings.connect('changed::logo-path', showPath);
        const chooseBtn = new Gtk.Button({label: 'Choose…', valign: Gtk.Align.CENTER});
        chooseBtn.connect('clicked', () => {
            const filter = new Gtk.FileFilter({name: 'Images'});
            filter.add_pixbuf_formats();
            const filters = new Gio.ListStore({item_type: Gtk.FileFilter});
            filters.append(filter);
            const dlg = new Gtk.FileDialog({title: 'Choose an image', filters});
            dlg.open(window, null, (d, res) => {
                try {
                    const file = d.open_finish(res);
                    if (file?.get_path())
                        settings.set_string('logo-path', file.get_path());
                } catch (e) {
                    // dialog cancelled
                }
            });
        });
        const clearBtn = new Gtk.Button({icon_name: 'edit-clear-symbolic', valign: Gtk.Align.CENTER, tooltip_text: 'Remove image'});
        clearBtn.connect('clicked', () => settings.set_string('logo-path', ''));
        imgRow.add_suffix(chooseBtn);
        imgRow.add_suffix(clearBtn);
        neonGroup.add(imgRow);
        const bgRow = new Adw.SwitchRow({title: 'Remove picture background', subtitle: 'Cuts out a plain or gradient background (white or dark) around the picture'});
        settings.bind('logo-remove-bg', bgRow, 'active', Gio.SettingsBindFlags.DEFAULT);
        neonGroup.add(bgRow);

        const orbGroup = new Adw.PreferencesGroup({title: 'Floating orbs theme', description: 'Optionally put a picture of your own behind the orbs. It gets darkened and tinted to blend in.'});
        page.add(orbGroup);
        const wallRow = new Adw.ActionRow({title: 'Wallpaper'});
        const showWall = () => { wallRow.subtitle = settings.get_string('orbs-wallpaper') || 'None (theme colours)'; };
        showWall();
        settings.connect('changed::orbs-wallpaper', showWall);
        const wallBtn = new Gtk.Button({label: 'Choose…', valign: Gtk.Align.CENTER});
        wallBtn.connect('clicked', () => {
            const filter = new Gtk.FileFilter({name: 'Images'});
            filter.add_pixbuf_formats();
            const filters = new Gio.ListStore({item_type: Gtk.FileFilter});
            filters.append(filter);
            new Gtk.FileDialog({title: 'Choose a wallpaper', filters}).open(window, null, (d, res) => {
                try {
                    const file = d.open_finish(res);
                    if (file?.get_path())
                        settings.set_string('orbs-wallpaper', file.get_path());
                } catch (e) {
                    // dialog cancelled
                }
            });
        });
        const wallClear = new Gtk.Button({icon_name: 'edit-clear-symbolic', valign: Gtk.Align.CENTER, tooltip_text: 'Remove wallpaper'});
        wallClear.connect('clicked', () => settings.set_string('orbs-wallpaper', ''));
        wallRow.add_suffix(wallBtn);
        wallRow.add_suffix(wallClear);
        orbGroup.add(wallRow);
        const dimOrbs = new Adw.SpinRow({
            title: 'Wallpaper darkening',
            subtitle: 'Percent. Higher blends it more into the dark theme',
            adjustment: new Gtk.Adjustment({lower: 0, upper: 90, step_increment: 5, page_increment: 10}),
        });
        settings.bind('orbs-dim', dimOrbs, 'value', Gio.SettingsBindFlags.DEFAULT);
        orbGroup.add(dimOrbs);

        const ov = new Adw.PreferencesGroup({title: 'Overview'});
        page.add(ov);

        const ovRow = new Adw.SwitchRow({
            title: 'Show in overview and app grid',
            subtitle: 'Animates the Activities view and the app grid too',
        });
        settings.bind('show-in-overview', ovRow, 'active', Gio.SettingsBindFlags.DEFAULT);
        ov.add(ovRow);

        const dimRow = new Adw.SpinRow({
            title: 'Overview darkening',
            subtitle: 'Percent, so app icons stay readable',
            adjustment: new Gtk.Adjustment({lower: 0, upper: 90, step_increment: 5, page_increment: 10}),
        });
        settings.bind('overview-dim', dimRow, 'value', Gio.SettingsBindFlags.DEFAULT);
        settings.bind('show-in-overview', dimRow, 'sensitive', Gio.SettingsBindFlags.GET);
        ov.add(dimRow);

        const perf = new Adw.PreferencesGroup({title: 'Performance'});
        page.add(perf);

        const fpsRow = new Adw.SpinRow({
            title: 'Frame rate',
            subtitle: 'Lower values use less CPU',
            adjustment: new Gtk.Adjustment({lower: 10, upper: 60, step_increment: 5, page_increment: 10}),
        });
        settings.bind('fps', fpsRow, 'value', Gio.SettingsBindFlags.DEFAULT);
        perf.add(fpsRow);

        const qualityRow = new Adw.SpinRow({
            title: 'Quality',
            subtitle: 'Drawing resolution. 1.0 is sharpest; lower is much lighter on the CPU',
            digits: 1,
            adjustment: new Gtk.Adjustment({lower: 0.4, upper: 1, step_increment: 0.1, page_increment: 0.2}),
        });
        settings.bind('quality', qualityRow, 'value', Gio.SettingsBindFlags.DEFAULT);
        perf.add(qualityRow);

        const fsRow = new Adw.SwitchRow({
            title: 'Pause for fullscreen apps',
            subtitle: 'Stops the animation while a game or video is fullscreen',
        });
        settings.bind('pause-fullscreen', fsRow, 'active', Gio.SettingsBindFlags.DEFAULT);
        perf.add(fsRow);

        const panelRow = new Adw.SwitchRow({title: 'Show top bar icon'});
        settings.bind('show-indicator', panelRow, 'active', Gio.SettingsBindFlags.DEFAULT);
        perf.add(panelRow);

        window.add(page);
    }
}
