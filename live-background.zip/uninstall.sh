#!/bin/sh
UUID="live-background@bazzite.local"
gnome-extensions disable "$UUID" 2>/dev/null || true
rm -rf "$HOME/.local/share/gnome-shell/extensions/$UUID"
rm -f "$HOME/.local/share/applications/live-background-toggle.desktop"
echo "Live Background removed. Log out and back in to finish."
