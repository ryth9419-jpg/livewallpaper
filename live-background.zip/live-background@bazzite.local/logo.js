// Loads an image chosen by the user for the Neon theme, optionally removing a
// plain white/light background, and returns it as a Cairo surface.

import Cairo from 'cairo';
import GdkPixbuf from 'gi://GdkPixbuf';
import GLib from 'gi://GLib';

function keyOutBackground(pb) {
    if (!pb.get_has_alpha())
        pb = pb.add_alpha(false, 0, 0, 0);
    const w = pb.get_width(), h = pb.get_height(), rs = pb.get_rowstride(), n = w * h;
    const px = new Uint8Array(pb.get_pixels());
    const idx = p => ((p / w) | 0) * rs + (p % w) * 4;
    const diff = (i, j) => Math.max(Math.abs(px[i] - px[j]), Math.abs(px[i + 1] - px[j + 1]), Math.abs(px[i + 2] - px[j + 2]));

    // 1. Find the subject's outline: anywhere the colour changes quickly.
    //    Smooth backgrounds (plain or gradient) change slowly, so they pass.
    const edge = new Uint8Array(n);
    for (let y = 1; y < h - 1; y++) {
        for (let x = 1; x < w - 1; x++) {
            const p = y * w + x;
            const g = diff(idx(p - 1), idx(p + 1)) + diff(idx(p - w), idx(p + w));
            if (g > 16) edge[p] = 1;
        }
    }
    // thicken the outline by a pixel so no small gaps let the fill leak in
    const wall = new Uint8Array(n);
    for (let y = 1; y < h - 1; y++) {
        for (let x = 1; x < w - 1; x++) {
            const p = y * w + x;
            if (edge[p] || edge[p - 1] || edge[p + 1] || edge[p - w] || edge[p + w]) wall[p] = 1;
        }
    }
    // 2. Flood-fill the background in from the picture's border, stopping at the outline.
    const bg = new Uint8Array(n), stack = [];
    const seed = p => { if (!bg[p] && !wall[p]) { bg[p] = 1; stack.push(p); } };
    for (let x = 0; x < w; x++) { seed(x); seed((h - 1) * w + x); }
    for (let y = 0; y < h; y++) { seed(y * w); seed(y * w + w - 1); }
    while (stack.length) {
        const p = stack.pop(), x = p % w, y = (p / w) | 0;
        if (x + 1 < w) seed(p + 1);
        if (x > 0) seed(p - 1);
        if (y + 1 < h) seed(p + w);
        if (y > 0) seed(p - w);
    }
    // 3. Outline pixels fade out the more they look like the nearby background.
    const alpha = new Uint8Array(n).fill(255);
    for (let p = 0; p < n; p++) {
        if (bg[p]) { alpha[p] = 0; continue; }
        if (!wall[p]) continue;
        const x = p % w, y = (p / w) | 0, i = idx(p);
        let best = 999;
        for (let dy = -3; dy <= 3; dy++) {
            for (let dx = -3; dx <= 3; dx++) {
                const xx = x + dx, yy = y + dy;
                if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
                const q = yy * w + xx;
                if (bg[q]) best = Math.min(best, diff(i, idx(q)));
            }
        }
        if (best < 999)
            alpha[p] = Math.round(255 * Math.max(0, Math.min(1, (best - 12) / 60)));
    }
    for (let p = 0; p < n; p++)
        px[idx(p) + 3] = Math.min(px[idx(p) + 3], alpha[p]);
    return GdkPixbuf.Pixbuf.new_from_bytes(new GLib.Bytes(px), GdkPixbuf.Colorspace.RGB, true, 8, w, h, rs);
}

export function loadLogo(path, removeBg, size = 720) {
    if (!path || !GLib.file_test(path, GLib.FileTest.EXISTS))
        return null;
    let pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(path, size, size, true);
    if (removeBg)
        pb = keyOutBackground(pb);
    const dir = GLib.build_filenamev([GLib.get_user_cache_dir(), 'live-background']);
    GLib.mkdir_with_parents(dir, 0o755);
    const out = GLib.build_filenamev([dir, 'logo.png']);
    pb.savev(out, 'png', [], []);
    const surface = Cairo.ImageSurface.createFromPNG(out);
    return {surface, w: pb.get_width(), h: pb.get_height(), rs: 1};
}

// A plain picture (no background removal), e.g. a wallpaper for the orbs theme.
export function loadImage(path, size = 2048) {
    if (!path || !GLib.file_test(path, GLib.FileTest.EXISTS))
        return null;
    const pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(path, size, size, true);
    const dir = GLib.build_filenamev([GLib.get_user_cache_dir(), 'live-background']);
    GLib.mkdir_with_parents(dir, 0o755);
    const out = GLib.build_filenamev([dir, 'wallpaper.png']);
    pb.savev(out, 'png', [], []);
    return {surface: Cairo.ImageSurface.createFromPNG(out), w: pb.get_width(), h: pb.get_height(), rs: 1};
}
