// Live Background rendering engine.
// Each theme draws with a small Canvas-2D-style wrapper around Cairo, into a
// persistent offscreen surface that the extension paints onto the desktop.

import Cairo from 'cairo';
import GLib from 'gi://GLib';
import Pango from 'gi://Pango';
import PangoCairo from 'gi://PangoCairo';

export const THEMES = [
    ['matrix', 'Matrix rain'],
    ['code', 'Code stream'],
    ['storm', 'Thunderstorm'],
    ['spiders', 'Spiders'],
    ['starfield', 'Starfield'],
    ['fireflies', 'Fireflies'],
    ['kittens', 'Kittens'],
    ['cursorcat', 'Cursor cat'],
    ['neon', 'Neon emblem'],
    ['orbs', 'Floating orbs'],
];

const TAU = Math.PI * 2;
const rand = (a, b) => a + Math.random() * (b - a);
const angDiff = a => Math.atan2(Math.sin(a), Math.cos(a));

/* ---------- Colour parsing (cached) ---------- */
const colorCache = new Map();
function hslToRgb(h, s, l) {
    if (s === 0)
        return [l, l, l];
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
    const f = t => {
        if (t < 0) t += 1;
        if (t > 1) t -= 1;
        if (t < 1 / 6) return p + (q - p) * 6 * t;
        if (t < 1 / 2) return q;
        if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
        return p;
    };
    return [f(h + 1 / 3), f(h), f(h - 1 / 3)];
}
function parseColor(s) {
    let c = colorCache.get(s);
    if (c)
        return c;
    if (s[0] === '#') {
        let h = s.slice(1);
        if (h.length === 3)
            h = h.split('').map(x => x + x).join('');
        c = [parseInt(h.slice(0, 2), 16) / 255, parseInt(h.slice(2, 4), 16) / 255, parseInt(h.slice(4, 6), 16) / 255, 1];
    } else if (s.startsWith('rgb')) {
        const p = s.slice(s.indexOf('(') + 1, -1).split(',').map(parseFloat);
        c = [p[0] / 255, p[1] / 255, p[2] / 255, p.length > 3 ? p[3] : 1];
    } else if (s.startsWith('hsl')) {
        const p = s.slice(s.indexOf('(') + 1, -1).split(',').map(parseFloat);
        c = [...hslToRgb(p[0] / 360, p[1] / 100, p[2] / 100), p.length > 3 ? p[3] : 1];
    } else {
        c = [0, 0, 0, 0];
    }
    if (colorCache.size > 4000)
        colorCache.clear();
    colorCache.set(s, c);
    return c;
}

class Grad {
    constructor(pattern) {
        this.pattern = pattern;
    }

    addColorStop(o, color) {
        const k = parseColor(color);
        this.pattern.addColorStopRGBA(o, k[0], k[1], k[2], k[3]);
    }
}

/* ---------- Canvas-like wrapper around a Cairo context ---------- */
class Ctx2D {
    constructor(surface, rs = 1) {
        this.cr = new Cairo.Context(surface);
        if (rs !== 1)
            this.cr.scale(rs, rs);
        this._fill = [0, 0, 0, 1];
        this._stroke = [0, 0, 0, 1];
        this._lw = 1;
        this.globalAlpha = 1;
        this._stack = [];
        // Accepted but ignored (Cairo has no cheap blur).
        this.shadowBlur = 0;
        this.shadowColor = 'transparent';
    }

    set fillStyle(v) { this._fill = typeof v === 'string' ? parseColor(v) : v; }
    get fillStyle() { return this._fill; }
    set strokeStyle(v) { this._stroke = typeof v === 'string' ? parseColor(v) : v; }
    get strokeStyle() { return this._stroke; }
    set lineWidth(v) { this._lw = v; this.cr.setLineWidth(v); }
    get lineWidth() { return this._lw; }
    set lineCap(v) { this.cr.setLineCap(v === 'round' ? Cairo.LineCap.ROUND : Cairo.LineCap.BUTT); }
    set lineJoin(v) { this.cr.setLineJoin(v === 'round' ? Cairo.LineJoin.ROUND : Cairo.LineJoin.MITER); }
    set globalCompositeOperation(v) { this.cr.setOperator(v === 'lighter' ? Cairo.Operator.ADD : Cairo.Operator.OVER); }

    _src(s) {
        if (Array.isArray(s))
            this.cr.setSourceRGBA(s[0], s[1], s[2], s[3] * this.globalAlpha);
        else
            this.cr.setSource(s.pattern);
    }

    fillRect(x, y, w, h) { this.cr.newPath(); this.cr.rectangle(x, y, w, h); this._src(this._fill); this.cr.fill(); }
    beginPath() { this.cr.newPath(); }
    moveTo(x, y) { this.cr.moveTo(x, y); }
    lineTo(x, y) { this.cr.lineTo(x, y); }
    closePath() { this.cr.closePath(); }
    bezierCurveTo(a, b, c, d, x, y) { this.cr.curveTo(a, b, c, d, x, y); }
    rect(x, y, w, h) { this.cr.rectangle(x, y, w, h); }
    arc(x, y, r, a0, a1) { this.cr.arc(x, y, r, a0, a1); }
    ellipse(x, y, rx, ry, rot, a0, a1) {
        const cr = this.cr;
        cr.save(); cr.translate(x, y); cr.rotate(rot); cr.scale(rx, ry);
        cr.arc(0, 0, 1, a0, a1);
        cr.restore();
    }

    fill() { this._src(this._fill); this.cr.fill(); }
    stroke() { this._src(this._stroke); this.cr.stroke(); }
    clip() { this.cr.clip(); }
    save() { this.cr.save(); this._stack.push([this._fill, this._stroke, this.globalAlpha, this._lw]); }
    restore() {
        this.cr.restore();
        const s = this._stack.pop();
        if (s)
            [this._fill, this._stroke, this.globalAlpha, this._lw] = s;
    }

    translate(x, y) { this.cr.translate(x, y); }
    rotate(a) { this.cr.rotate(a); }
    scale(x, y) { this.cr.scale(x, y); }
    createRadialGradient(x0, y0, r0, x1, y1, r1) { return new Grad(new Cairo.RadialGradient(x0, y0, r0, x1, y1, r1)); }
    createLinearGradient(x0, y0, x1, y1) { return new Grad(new Cairo.LinearGradient(x0, y0, x1, y1)); }

    drawImage(img, x, y, w, h) {
        const cr = this.cr;
        cr.save();
        cr.translate(x, y);
        if (w !== undefined)
            cr.scale(w / img.w, h / img.h);
        cr.newPath();
        cr.rectangle(0, 0, img.w, img.h);
        cr.clip();
        if (img.rs !== 1)
            cr.scale(1 / img.rs, 1 / img.rs);
        cr.setSourceSurface(img.surface, 0, 0);
        cr.paintWithAlpha(this.globalAlpha);
        cr.restore();
    }

    // Text: Pango layouts (handle font fallback and coloured markup).
    layout(text, px, markup = false) {
        const l = PangoCairo.create_layout(this.cr);
        const fd = Pango.FontDescription.from_string('Monospace');
        fd.set_absolute_size(px * Pango.SCALE);
        l.set_font_description(fd);
        if (markup)
            l.set_markup(text, -1);
        else
            l.set_text(text, -1);
        return l;
    }

    drawLayout(l, x, y) {
        this.cr.moveTo(x, y);
        this._src(this._fill);
        PangoCairo.show_layout(this.cr, l);
    }
}

export const scaledSize = (n, rs) => Math.max(1, Math.ceil(n * rs));

// A drawing surface. Drawing uses logical coordinates (w x h), but pixels are
// stored at rs times that size, so lower rs means much less CPU work.
function makeLayer(w, h, rs = 1) {
    const surface = new Cairo.ImageSurface(Cairo.Format.ARGB32, scaledSize(w, rs), scaledSize(h, rs));
    return {surface, w, h, rs, ctx: new Ctx2D(surface, rs)};
}

/* ---------- Themes ---------- */
function makeThemes(env) {
    const ctx = env.ctx, W = env.W, H = env.H;
    const dot = (x, y, r) => { ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill(); };

    /* Matrix rain: characters glitch out when the mouse moves through them */
    const matrix = (() => {
        const fs = 18;
        const chars = Array.from('アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワン0123456789Z:.=*+-<>');
        let drops = [], speeds = [], rain = null, glyphsR = null, glyphsM = null, cols = 0, rows = 0, cell = null, born = null;
        let t = 0, lastP = null, gUntil = null, gNext = null, gShift = null, gGlyph = null;
        const active = new Set();
        const GLITCH = ['rgba(255,42,109,', 'rgba(5,217,232,', 'rgba(255,255,255,', 'rgba(216,255,216,'];
        function init() {
            rain = makeLayer(W, H, env.rs);
            glyphsR = chars.map(ch => rain.ctx.layout(ch, fs));
            if (!glyphsM) glyphsM = chars.map(ch => ctx.layout(ch, fs));
            cols = Math.ceil(W / fs); rows = Math.ceil(H / fs);
            cell = new Int16Array(cols * rows).fill(-1); born = new Float32Array(cols * rows);
            drops = Array.from({length: cols}, () => rand(-H / fs, 0));
            speeds = Array.from({length: cols}, () => rand(0.6, 1.4));
            rain.ctx.fillStyle = '#000000'; rain.ctx.fillRect(0, 0, W, H);
            gUntil = new Float32Array(cols * rows); gNext = new Float32Array(cols * rows); gShift = new Float32Array(cols * rows); gGlyph = new Int16Array(cols * rows);
            active.clear(); t = 0; lastP = null;
        }
        function frame(dt) {
            t += dt;
            // the rain itself, drawn into its own fading layer
            const r = rain.ctx;
            r.fillStyle = `rgba(0,0,0,${Math.min(1, dt * 3).toFixed(2)})`;
            r.fillRect(0, 0, W, H);
            for (let i = 0; i < drops.length; i++) {
                const prev = Math.floor(drops[i]);
                drops[i] += speeds[i] * dt * 18;
                const row = Math.floor(drops[i]);
                if (row !== prev && row >= 0 && row < rows) {
                    const gi = (Math.random() * glyphsR.length) | 0;
                    r.fillStyle = Math.random() < 0.12 ? '#d8ffd8' : '#33f06a';
                    r.drawLayout(glyphsR[gi], i * fs, row * fs);
                    cell[row * cols + i] = gi; born[row * cols + i] = t;
                }
                if (row * fs > H && Math.random() < 0.03)
                    drops[i] = rand(-20, 0);
            }
            ctx.drawImage(rain, 0, 0);

            // glitch: characters the mouse passes through scramble and flicker for a moment
            const p = env.pointer;
            if (p && lastP && Math.hypot(p.x - lastP.x, p.y - lastP.y) > 1) {
                const steps = Math.min(12, Math.ceil(Math.hypot(p.x - lastP.x, p.y - lastP.y) / (fs * 0.7)));
                for (let s2 = 1; s2 <= steps; s2++) {
                    const x = lastP.x + (p.x - lastP.x) * s2 / steps, y = lastP.y + (p.y - lastP.y) * s2 / steps;
                    const cc = Math.floor(x / fs), rr = Math.floor(y / fs);
                    for (let dc = -1; dc <= 1; dc++) {
                        for (let dr = -1; dr <= 1; dr++) touch(cc + dc, rr + dr, dc === 0 && dr === 0 ? 1 : 0.55);
                    }
                }
            }
            lastP = p ? {x: p.x, y: p.y} : null;
            if (!active.size) return;
            const k = H / 1080;
            for (const idx of active) {
                const left = gUntil[idx] - t;
                if (left <= 0 || t - born[idx] > 2) { active.delete(idx); continue; }
                const c = idx % cols, rw = (idx / cols) | 0;
                if (t > gNext[idx]) { gNext[idx] = t + rand(0.04, 0.12); gShift[idx] = Math.random() < 0.5 ? rand(-0.45, 0.45) * fs : 0; gGlyph[idx] = (Math.random() * glyphsM.length) | 0; }
                if (Math.random() < 0.12) continue;          // flicker out now and then
                const a = Math.min(1, left * 2.5) * Math.max(0.25, 1 - (t - born[idx]) / 2);
                const x = c * fs + gShift[idx], y = rw * fs, off = 2.5 * k;
                ctx.fillStyle = 'rgba(0,0,0,.92)'; ctx.fillRect(c * fs, y, fs, fs);
                ctx.globalCompositeOperation = 'lighter';
                ctx.fillStyle = `${GLITCH[0]}${(a * 0.75).toFixed(2)})`; ctx.drawLayout(glyphsM[gGlyph[idx]], x - off, y);
                ctx.fillStyle = `${GLITCH[1]}${(a * 0.75).toFixed(2)})`; ctx.drawLayout(glyphsM[gGlyph[idx]], x + off, y);
                ctx.globalCompositeOperation = 'source-over';
                ctx.fillStyle = Math.random() < 0.5 ? `${GLITCH[3]}${a.toFixed(2)})` : `rgba(51,240,106,${a.toFixed(2)})`;
                ctx.drawLayout(glyphsM[(gGlyph[idx] + 11) % glyphsM.length], x, y);
            }
        }
        function touch(c, rw, strength) {
            if (c < 0 || rw < 0 || c >= cols || rw >= rows) return;
            const idx = rw * cols + c;
            if (cell[idx] < 0 || t - born[idx] > 1.6) return;          // only real, visible characters glitch
            if (Math.random() > strength) return;
            gUntil[idx] = Math.max(gUntil[idx], t + rand(0.25, 0.7));
            active.add(idx);
            // the glitch runs a little way up and down the same line of text
            for (const d of [-1, 1]) {
                let r2 = rw + d, n = (Math.random() * 3) | 0;
                while (n-- > 0 && r2 >= 0 && r2 < rows) {
                    const j = r2 * cols + c;
                    if (cell[j] >= 0 && t - born[j] < 1.6) { gUntil[j] = Math.max(gUntil[j], t + rand(0.15, 0.45)); active.add(j); }
                    r2 += d;
                }
            }
        }
        return {init, frame};
    })();

    /* Code stream */
    const code = (() => {
        const SNIPPETS = [
            'const frame = (dt) => render(scene, dt);', 'if (fullscreen) pause(); else resume();',
            'for (let i = 0; i < cols; i++) drop(i);', 'fn main() { let mut rng = rand::thread_rng(); }',
            'git commit -m "fix shader uniforms"', 'while True: monitor.poll(interval=1.0)',
            'export default class LiveBackground extends Extension {}', 'glUniform1f(timeLoc, elapsed);',
            'return new Promise(r => setTimeout(r, 16));', 'SELECT name, ram_mb FROM procs ORDER BY ram_mb DESC;',
            'let theme = settings.get_string("theme");', 'printf("%d frames\\n", count);',
            'import Gio from "gi://Gio";', 'def swirl(p, t): return rotate(p, t * 0.5)',
            'const x = Math.sin(t * 2.0) * 0.5 + 0.5;', 'for (const w of windows) w.minimize();',
            'uniform float u_time; varying vec2 uv;', 'if (err) throw new Error("no display");',
            'async function load() { const res = await fetch(url); return res.json(); }',
            'struct Particle { x: f32, y: f32, vx: f32, vy: f32 }',
            'impl Particle { pub fn step(&mut self, dt: f32) { self.x += self.vx * dt; } }',
            'use std::collections::HashMap;', 'match event { Event::Quit => break, _ => continue }',
            'int main(void) { return render_loop(); }', 'static char buffer[4096];',
            'func main() { http.ListenAndServe(":8080", nil) }', 'package main',
            'public static void main(String[] args) { run(); }', 'try { parse(input); } catch (e) { log(e); }',
            'except KeyError as err: print(err)', 'squares = [n * n for n in range(64)]',
            'lambda x: x * 0.5 + offset', 'switch (state) { case IDLE: wake(); break; }',
            'for f in *.rpm; do sudo dnf install "$f"; done', 'if [ -f ~/.config/live-bg.conf ]; then echo "loaded"; fi',
            'echo "frames: $FPS"', 'INSERT INTO scores (player, points) VALUES ("p1", 42);',
            'SELECT * FROM matches WHERE winner IS NOT null;', 'interface Theme { name: string; fps: number; }',
            'type Vec2 = { x: number; y: number };', 'enum Mode { Play, Pause, Hidden }',
            'const shader = gl.createShader(gl.FRAGMENT_SHADER);', 'gl_FragColor = vec4(uv.x, uv.y, sin(u_time), 1.0);',
            'float d = length(uv - 0.5); col *= smoothstep(0.4, 0.0, d);', 'with open("log.txt") as f: lines = f.readlines()',
            'yield from walk(tree.left)', 'loop { let frame = rx.recv()?; draw(frame); }',
            'docker run --rm -it fedora:latest bash', 'ssh root@10.0.0.2 "uptime"',
            'window.addEventListener("resize", resize);', 'this.timer = setInterval(() => this.tick(), 1000);',
            'self.velocity = self.velocity.lerp(target, 0.1)', 'nums.sort((a, b) => b - a).slice(0, 10);',
            '0x7f3a 0x00ff 0xdead 0xbeef 0x1337 0xc0de', 'Array.from({ length: 8 }, (_, i) => i * i);',
            'const [state, setState] = useState(false);', 'printf("cpu: %.1f%%\\n", load * 100.0);',
            'git push origin main --force-with-lease', 'chmod +x LiveBackground.AppImage && ./LiveBackground.AppImage',
            'while read -r line; do echo "$line"; done < input.txt', '@keyframes spin { to { transform: rotate(360deg); } }',
            '.dock { display: flex; gap: 8px; backdrop-filter: blur(12px); }', '<div class="matrix" data-speed="1.5"></div>',
            'malloc(sizeof(struct node) * count);', 'if (x > W || x < 0) vx = -vx;',
            'return a.score > b.score ? a : b;', '10110100 01101001 11100010 00011111',
        ];
        const KW = /^(const|let|if|else|for|fn|def|return|while|True|export|default|class|extends|import|from|new|SELECT|FROM|ORDER|BY|DESC|git|mut|uniform|float|varying|vec2|vec4|throw|of|async|await|function|struct|impl|pub|use|match|int|void|char|static|public|func|package|var|try|catch|except|in|lambda|switch|case|break|echo|then|fi|do|done|WHERE|INSERT|INTO|VALUES|IS|NOT|null|true|false|self|this|type|interface|enum|loop|yield|with|as|sudo|continue)$/;
        let lanes = [];
        function markup(text, alpha) {
            const spans = (text.match(/"[^"]*"|\w+|\s+|[^\w\s]/g) || []).map(t => {
                let col = '#b8c2d1';
                if (KW.test(t)) col = '#7aa2ff';
                else if (t[0] === '"') col = '#f2b36b';
                else if (/^\d/.test(t)) col = '#c58cff';
                else if (/^[^\w\s]$/.test(t)) col = '#6b7688';
                return `<span foreground="${col}">${GLib.markup_escape_text(t, -1)}</span>`;
            });
            return `<span fgalpha="${Math.round(alpha * 100)}%">${spans.join('')}</span>`;
        }
        function fill(l, initial) {
            l.size = Math.round(rand(11, 22));
            const parts = Array.from({length: 2 + ((Math.random() * 3) | 0)}, () => SNIPPETS[(Math.random() * SNIPPETS.length) | 0]);
            const alpha = 0.25 + (l.size - 11) / 11 * 0.65;
            l.layout = ctx.layout(markup(parts.join('      '), alpha), l.size, true);
            l.width = l.layout.get_pixel_size()[0];
            l.speed = l.size * rand(4, 8);
            l.x = initial ? rand(-l.width, W) : -l.width - rand(0, W * 0.6);
        }
        function init() {
            const gap = 21, n = Math.ceil(H / gap) + 1;
            lanes = Array.from({length: n}, (_, i) => {
                const l = {y: i * gap + rand(-4, 4)};
                fill(l, true);
                return l;
            });
        }
        function frame(dt) {
            ctx.fillStyle = '#070a10';
            ctx.fillRect(0, 0, W, H);
            for (const l of lanes) {
                l.x += l.speed * dt;
                if (l.x > W)
                    fill(l, false);
                ctx.drawLayout(l.layout, l.x, l.y - l.size * 0.6);
            }
        }
        return {init, frame};
    })();

    /* Thunderstorm: drifting clouds, layered rain, splashes, lightning, drops on the glass */
    const storm = (() => {
        let sky = null, hills = null, clouds = [], drops = [], splashes = [], bolts = [], beads = [];
        let flash = 0, pulses = [], since = 0, nextStrike = 3, nextBead = 4, t = 0, horizon = 0;
        const RAIN = [[190, 200, 220, 0.14, 0.7], [195, 205, 225, 0.24, 1.0], [205, 215, 235, 0.38, 1.5]];
        const rainBuckets = [[], [], []];

        function cloudPair(h, count, dark, seedY) {
            const dk = makeLayer(W, h, env.rs), lt = makeLayer(W, h, env.rs);
            for (let i = 0; i < count; i++) {
                const x = rand(0, W), y = rand(-h * 0.1, h * seedY), r = rand(h * 0.12, h * 0.38);
                for (const ox of [0, -W, W]) {
                    if (x + ox + r < 0 || x + ox - r > W) continue;
                    for (const [L, c, a] of [[dk, dark, 0.5], [lt, [150, 165, 205], 0.32]]) {
                        const g = L.ctx.createRadialGradient(x + ox, y, 0, x + ox, y, r);
                        g.addColorStop(0, `rgba(${c[0]},${c[1]},${c[2]},${a})`);
                        g.addColorStop(1, `rgba(${c[0]},${c[1]},${c[2]},0)`);
                        L.ctx.fillStyle = g;
                        L.ctx.fillRect(x + ox - r, y - r, r * 2, r * 2);
                    }
                }
            }
            return {dk, lt, off: rand(0, W)};
        }
        function newDrop(d, initial) {
            d.z = Math.random();
            d.l = 14 + d.z * 34;
            d.v = 650 + d.z * 950;
            d.x = rand(-W * 0.2, W);
            d.y = initial ? rand(-H, H) : rand(-H * 0.3, -20);
            d.gy = horizon + rand(-H * 0.02, H - horizon) * (0.3 + d.z * 0.7);
        }
        function bolt(x0, y0, x1, y1, disp, iters) {
            let pts = [[x0, y0], [x1, y1]];
            for (let it = 0; it < iters; it++) {
                const np = [pts[0]];
                for (let i = 0; i < pts.length - 1; i++) {
                    const [ax, ay] = pts[i], [bx, by] = pts[i + 1];
                    np.push([(ax + bx) / 2 + rand(-1, 1) * disp, (ay + by) / 2 + rand(-0.25, 0.25) * disp], [bx, by]);
                }
                pts = np;
                disp *= 0.55;
            }
            return pts;
        }
        function strike() {
            since = 0;
            const sheet = Math.random() < 0.35;
            pulses = sheet ? [[0, 0.45], [0.15, 0.3]] : [[0, 1], [0.09, 0.45], [0.2, 0.85], [0.34, 0.4]];
            if (sheet) return;
            const x = rand(W * 0.08, W * 0.92), top = rand(H * 0.04, H * 0.18);
            const gx = x + rand(-W * 0.12, W * 0.12), gy = horizon + rand(0, (H - horizon) * 0.25);
            const main = bolt(x, top, gx, gy, W * 0.07, 7);
            const paths = [{pts: main, w: 1}];
            const nb = (rand(2, 6)) | 0;
            for (let b = 0; b < nb; b++) {
                const [sx, sy] = main[(rand(0.1, 0.7) * main.length) | 0];
                const len = rand(H * 0.08, H * 0.26), ang = Math.PI / 2 + rand(-1.1, 1.1);
                paths.push({pts: bolt(sx, sy, sx + Math.cos(ang) * len, sy + Math.sin(ang) * len, len * 0.25, 5), w: rand(0.35, 0.6)});
            }
            bolts.push({paths, life: 0.45, max: 0.45, gx, gy});
        }
        function newBead() {
            const r = rand(6, 17);
            beads.push({x: rand(W * 0.04, W * 0.96), y: rand(H * 0.04, H * 0.7), r, life: rand(7, 14), age: 0,
                vy: 0, slide: rand(1, 3), trail: [], tmp: makeLayer(r * 4, r * 4, env.rs)});
        }
        function init() {
            horizon = H * 0.8;
            sky = ctx.createLinearGradient(0, 0, 0, H);
            sky.addColorStop(0, '#06080d'); sky.addColorStop(0.6, '#0e121a'); sky.addColorStop(1, '#151a22');
            clouds = [cloudPair(H * 0.5, 26, [34, 38, 48], 0.7), cloudPair(H * 0.62, 22, [20, 23, 30], 0.6)];
            clouds[0].speed = 6; clouds[1].speed = 16;
            hills = makeLayer(W, H - horizon + H * 0.08, env.rs);
            const g = hills.ctx, hh = hills.h;
            g.fillStyle = '#05060a';
            g.beginPath(); g.moveTo(0, hh);
            for (let x = 0; x <= W + 20; x += 20) {
                const y = H * 0.08 + Math.sin(x * 0.004) * H * 0.025 + Math.sin(x * 0.011 + 2) * H * 0.012 + rand(-2, 2);
                g.lineTo(x, y);
            }
            g.lineTo(W, hh); g.closePath(); g.fill();
            const n = Math.round(Math.min(1100, W * H / 1800));
            drops = Array.from({length: n}, () => { const d = {}; newDrop(d, true); return d; });
            splashes = []; bolts = []; beads = []; pulses = []; flash = 0; t = 0;
            nextStrike = rand(2, 5); nextBead = rand(3, 6);
        }
        function drawClouds(c, lit) {
            const y = 0;
            ctx.drawImage(c.dk, c.off - W, y); ctx.drawImage(c.dk, c.off, y);
            if (lit > 0.02) {
                ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = Math.min(1, lit);
                ctx.drawImage(c.lt, c.off - W, y); ctx.drawImage(c.lt, c.off, y);
                ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
            }
        }
        function drawBolts() {
            ctx.globalCompositeOperation = 'lighter'; ctx.lineJoin = 'round'; ctx.lineCap = 'round';
            for (const b of bolts) {
                const a = Math.max(0, Math.min(1, flash * 1.2)) * (b.life / b.max) ** 0.5;
                if (a < 0.02) continue;
                for (const [wm, col, al] of [[9, '150,165,255', 0.12], [3.5, '190,200,255', 0.35], [1.4, '255,255,255', 1]]) {
                    for (const p of b.paths) {
                        ctx.strokeStyle = `rgba(${col},${(al * a).toFixed(2)})`; ctx.lineWidth = wm * p.w;
                        ctx.beginPath(); ctx.moveTo(p.pts[0][0], p.pts[0][1]);
                        for (let i = 1; i < p.pts.length; i++) ctx.lineTo(p.pts[i][0], p.pts[i][1]);
                        ctx.stroke();
                    }
                }
                const gr = ctx.createRadialGradient(b.gx, b.gy, 0, b.gx, b.gy, H * 0.15);
                gr.addColorStop(0, `rgba(200,210,255,${(0.45 * a).toFixed(2)})`); gr.addColorStop(1, 'rgba(200,210,255,0)');
                ctx.fillStyle = gr; ctx.fillRect(b.gx - H * 0.15, b.gy - H * 0.15, H * 0.3, H * 0.3);
            }
            ctx.globalCompositeOperation = 'source-over';
        }
        function rain(dt) {
            const wind = 0.16 + Math.sin(t * 0.35) * 0.07;
            for (const b of rainBuckets) b.length = 0;
            for (const d of drops) {
                d.y += d.v * dt; d.x += d.v * wind * dt;
                if (d.y >= d.gy) {
                    if (d.z > 0.45 && splashes.length < 220) {
                        for (let k = 0; k < 2; k++) splashes.push({x: d.x, y: d.gy, vx: rand(-60, 60) * d.z, vy: -rand(40, 110) * d.z, life: rand(0.15, 0.3)});
                    }
                    newDrop(d, false);
                    continue;
                }
                const bi = d.z < 0.4 ? 0 : d.z < 0.75 ? 1 : 2;
                rainBuckets[bi].push(d.x, d.y, d.x - d.l * wind, d.y - d.l);
            }
            ctx.lineCap = 'butt';
            RAIN.forEach(([r, g, b, a, w], i) => {
                const s = rainBuckets[i];
                if (!s.length) return;
                ctx.strokeStyle = `rgba(${r},${g},${b},${a})`; ctx.lineWidth = w;
                ctx.beginPath();
                for (let k = 0; k < s.length; k += 4) { ctx.moveTo(s[k], s[k + 1]); ctx.lineTo(s[k + 2], s[k + 3]); }
                ctx.stroke();
            });
            ctx.fillStyle = 'rgba(200,210,230,.45)';
            for (let i = splashes.length - 1; i >= 0; i--) {
                const p = splashes[i];
                p.life -= dt;
                if (p.life <= 0) { splashes.splice(i, 1); continue; }
                p.vy += 500 * dt; p.x += p.vx * dt; p.y += p.vy * dt;
                ctx.fillRect(p.x, p.y, 1.4, 1.4);
            }
        }
        function glass(dt) {
            nextBead -= dt;
            if (nextBead <= 0 && beads.length < 5) { newBead(); nextBead = rand(4, 10); }
            for (let i = beads.length - 1; i >= 0; i--) {
                const d = beads[i];
                d.age += dt; d.life -= dt; d.slide -= dt;
                if (d.slide <= 0) { d.vy = rand(50, 140); d.slide = rand(1.5, 4); }
                if (d.vy > 0) {
                    d.y += d.vy * dt; d.vy *= Math.exp(-dt * 2.5);
                    if (Math.random() < dt * 8) d.trail.push({x: d.x + rand(-1.5, 1.5), y: d.y - d.r * 0.7, r: rand(0.8, 2.2), life: rand(2, 4)});
                    if (d.vy < 6) d.vy = 0;
                }
                if (d.life <= 0 || d.y - d.r > H) { beads.splice(i, 1); continue; }
                const a = Math.min(1, d.life, d.age * 4), r = d.r * Math.min(1, 0.4 + d.age * 3);
                for (let k = d.trail.length - 1; k >= 0; k--) {
                    const tr = d.trail[k];
                    tr.life -= dt;
                    if (tr.life <= 0) { d.trail.splice(k, 1); continue; }
                    ctx.fillStyle = `rgba(200,210,230,${(0.22 * Math.min(1, tr.life)).toFixed(2)})`; dot(tr.x, tr.y, tr.r);
                }
                // Refraction: grab what is behind the drop and show it shrunk and upside down.
                const T = d.tmp;
                T.ctx.drawImage(env.main, -(d.x - d.r * 2), -(d.y - d.r * 2));
                ctx.save();
                ctx.beginPath(); ctx.arc(d.x, d.y, r, 0, TAU); ctx.clip();
                ctx.translate(d.x, d.y); ctx.scale(1, -1);
                ctx.globalAlpha = a;
                ctx.drawImage(T, -r * 1.15, -r * 1.15, r * 2.3, r * 2.3);
                ctx.restore();
                ctx.strokeStyle = `rgba(0,0,0,${(0.35 * a).toFixed(2)})`; ctx.lineWidth = r * 0.14;
                ctx.beginPath(); ctx.arc(d.x, d.y, r * 0.93, 0, TAU); ctx.stroke();
                ctx.strokeStyle = `rgba(255,255,255,${(0.2 * a).toFixed(2)})`; ctx.lineWidth = r * 0.12;
                ctx.beginPath(); ctx.arc(d.x, d.y, r * 0.75, 0.25 * Math.PI, 0.75 * Math.PI); ctx.stroke();
                ctx.fillStyle = `rgba(255,255,255,${(0.6 * a).toFixed(2)})`;
                ctx.beginPath(); ctx.ellipse(d.x - r * 0.35, d.y - r * 0.42, r * 0.28, r * 0.15, -0.6, 0, TAU); ctx.fill();
            }
        }
        function frame(dt) {
            t += dt; since += dt;
            nextStrike -= dt;
            if (nextStrike <= 0) { strike(); nextStrike = rand(2.5, 9); }
            for (const [at, amp] of pulses) {
                if (since >= at && since - dt < at) flash = Math.max(flash, amp);
            }
            flash *= Math.exp(-dt * 7);
            for (let i = bolts.length - 1; i >= 0; i--) { bolts[i].life -= dt; if (bolts[i].life <= 0) bolts.splice(i, 1); }
            for (const c of clouds) { c.off = (c.off + c.speed * dt) % W; }

            ctx.fillStyle = sky; ctx.fillRect(0, 0, W, H);
            drawClouds(clouds[0], flash * 0.8);
            drawBolts();
            drawClouds(clouds[1], flash);
            ctx.drawImage(hills, 0, horizon - H * 0.08);
            rain(dt);
            if (flash > 0.02) { ctx.fillStyle = `rgba(200,210,255,${(flash * 0.22).toFixed(2)})`; ctx.fillRect(0, 0, W, H); }
            glass(dt);
        }
        return {init, frame};
    })();

    /* Spiders + snakes */
    const critters = (() => {
        let S = [], K = [], webs = [], marks = [], vignette = null, mouse = null;
        const bias = [0.95, 0.4, -0.15, -0.7];
        const SPECIES = [
            // house spider
            {w: 4, size: [7, 12], speed: [45, 80], leg: 1, thick: 0.13, body: '#3a2e26', head: '#2e241e', legC: '#241c17', mark: 'chevrons', weaver: true},
            // black widow
            {w: 2, size: [8, 12], speed: [35, 60], leg: 1.15, thick: 0.11, body: '#050506', head: '#0a0a0c', legC: '#050506', mark: 'widow', bold: true},
            // brown tarantula
            {w: 3, size: [16, 25], speed: [28, 45], leg: 0.95, thick: 0.22, body: '#3b2716', head: '#4a3220', legC: '#2a1a0e', mark: 'hairy', knee: '#9a6630', hunter: true, bold: true},
            // redknee tarantula
            {w: 2, size: [15, 23], speed: [30, 48], leg: 0.95, thick: 0.23, body: '#141010', head: '#1c1515', legC: '#141010', mark: 'hairy', knee: '#e5761f', hunter: true, bold: true},
            // cobalt blue tarantula
            {w: 1, size: [15, 22], speed: [30, 48], leg: 0.95, thick: 0.23, body: '#1b2a6b', head: '#22337f', legC: '#1a2866', mark: 'hairy', knee: '#6fa0ff', hunter: true, bold: true},
            // jumping spider
            {w: 2, size: [5, 8], speed: [60, 90], leg: 0.7, thick: 0.17, body: '#151517', head: '#1d1d20', legC: '#121214', mark: 'spots', jumper: true},
            // peacock spider
            {w: 1, size: [4, 6], speed: [60, 90], leg: 0.7, thick: 0.16, body: '#1d4fd6', head: '#16161a', legC: '#2a2a30', mark: 'peacock', jumper: true},
            // wolf spider
            {w: 3, size: [9, 14], speed: [80, 130], leg: 1.05, thick: 0.15, body: '#5a4630', head: '#4c3a28', legC: '#3a2c1e', mark: 'stripes', stripe: '#a08a64'},
            // daddy long-legs
            {w: 2, size: [4, 6], speed: [40, 70], leg: 3.2, thick: 0.06, body: '#6b5a44', head: '#5c4c38', legC: '#4a3e30', mark: 'none'},
            // garden orb weaver
            {w: 2, size: [9, 13], speed: [35, 55], leg: 1.1, thick: 0.12, body: '#e8c020', head: '#d8d0b8', legC: '#2a2418', mark: 'bands', abd: 1.25, weaver: true},
            // huntsman
            {w: 2, size: [12, 17], speed: [110, 170], leg: 1.6, thick: 0.12, body: '#6b5238', head: '#5e4832', legC: '#4e3a26', mark: 'stripes', stripe: '#3e2c1c', hunter: true, bold: true},
            // green lynx spider
            {w: 2, size: [7, 10], speed: [55, 85], leg: 1.15, thick: 0.12, body: '#45c24a', head: '#3aa83f', legC: '#c8b050', mark: 'stripes', stripe: '#e8e070'},
            // crab spider
            {w: 2, size: [6, 9], speed: [30, 50], leg: 1.3, thick: 0.14, body: '#f0e6a0', head: '#e6d888', legC: '#d8cc80', mark: 'crab'},
        ];
        const SNAKES = [
            {head: '#357f31', width: [9, 12], color: i => (i % 9 < 1 ? '#2c6b29' : '#3f9a3a')},
            {head: '#141414', width: [7, 9], color: i => { const b = i % 14; return b < 2 ? '#f2d03b' : b < 7 ? '#c8321f' : b < 9 ? '#f2d03b' : '#141414'; }},
            {head: '#8a6a40', width: [12, 16], color: i => ((Math.sin(i * 0.7) + Math.sin(i * 0.23)) > 0.6 ? '#5b3b1f' : '#b89260')},
            {head: '#1a6fb8', width: [8, 10], color: i => (i % 7 < 1 ? '#0f4f8c' : '#2a8be0')},
            {head: '#efe4b0', width: [12, 15], color: i => ((Math.sin(i * 0.6) + Math.sin(i * 0.21)) > 0.7 ? '#f0c040' : '#f6efd2')},
            {head: '#7a6040', width: [10, 13], color: i => { const b = i % 10; return b < 3 ? '#4a3420' : b < 4 ? '#d9c79a' : '#8f7350'; }, rattle: true},
            {head: '#d8662a', width: [8, 10], color: i => { const b = i % 12; return b < 5 ? '#c0301e' : b < 6 ? '#2a1a10' : '#ee8a3a'; }},
            {head: '#111111', width: [7, 9], color: i => (i % 8 < 3 ? '#f0f0f0' : '#151515')},
        ];
        const totalW = SPECIES.reduce((a, s) => a + s.w, 0);
        function pick() {
            let r = Math.random() * totalW;
            for (const s of SPECIES) {
                if ((r -= s.w) < 0)
                    return s;
            }
            return SPECIES[0];
        }
        const onT = () => [rand(40, W - 40), rand(40, H - 40)];
        function offT(extra) {
            const e = (Math.random() * 4) | 0, o = rand(60, 120) + extra;
            if (e === 0) return [-o, rand(0, H)];
            if (e === 1) return [W + o, rand(0, H)];
            if (e === 2) return [rand(0, W), -o];
            return [rand(0, W), H + o];
        }
        const isOff = (x, y, m) => x < -m || x > W + m || y < -m || y > H + m;
        function mk() {
            const sp = pick(), [tx, ty] = onT();
            return {sp, x: rand(0, W), y: rand(0, H), h: rand(0, TAU), sz: rand(sp.size[0], sp.size[1]), ph: rand(0, 6), moving: true,
                state: 'wander', t: rand(2, 6), tx, ty, speed: rand(sp.speed[0], sp.speed[1]), hop: rand(0, 1), hv: 0, fx: 0, fy: 0,
                prey: null, snake: null, seg: 0, web: null};
        }
        function mkSnake() {
            const sp = SNAKES[(Math.random() * SNAKES.length) | 0], w = rand(sp.width[0], sp.width[1]), seg = w * 0.45, n = 58;
            const [ex, ey] = offT(200), h = Math.atan2(H / 2 - ey, W / 2 - ex), [tx, ty] = onT();
            const pts = Array.from({length: n}, (_, j) => ({x: ex - Math.cos(h) * seg * j, y: ey - Math.sin(h) * seg * j}));
            return {sp, w, seg, pts, h, ph: rand(0, 6), state: 'wander', t: rand(6, 12), tx, ty, speed: rand(45, 75),
                tk: rand(1, 3), tongue: 0, fx: 0, fy: 0, moving: true, thrash: 0, prey: null};
        }
        function makeWeb(cx, cy) {
            const R = rand(55, 130), n = (rand(12, 18)) | 0, rings = (rand(9, 14)) | 0;
            const spokes = Array.from({length: n}, (_, i) => ({a: i / n * TAU + rand(-0.12, 0.12), len: R * rand(0.8, 1.1)}));
            const spiral = [], r0 = R * 0.12, total = rings * n;
            for (let j = 0; j <= total; j++) {
                const s = spokes[j % n], f = j / total, rr = r0 + (s.len - r0) * f;
                spiral.push([cx + Math.cos(s.a) * rr, cy + Math.sin(s.a) * rr]);
            }
            return {cx, cy, R, spokes, spiral, p: 0, life: rand(90, 180)};
        }
        function webCursor(wb) {
            if (wb.p < 0.3) {
                const n = wb.spokes.length, f = wb.p / 0.3 * n, i = Math.min(n - 1, f | 0), s = wb.spokes[i], u = f - i;
                const rr = s.len * (u < 0.5 ? u * 2 : 2 - u * 2);
                return [wb.cx + Math.cos(s.a) * rr, wb.cy + Math.sin(s.a) * rr];
            }
            const i = Math.min(wb.spiral.length - 1, (((wb.p - 0.3) / 0.7) * wb.spiral.length) | 0);
            return wb.spiral[i];
        }
        function updateMouse(dt) {
            const p = env.pointer;
            if (!p) { mouse = null; return; }
            if (mouse) {
                const d = Math.max(dt, 0.001);
                mouse.vx = mouse.vx * 0.6 + ((p.x - mouse.x) / d) * 0.4;
                mouse.vy = mouse.vy * 0.6 + ((p.y - mouse.y) / d) * 0.4;
                mouse.x = p.x; mouse.y = p.y;
            } else {
                mouse = {x: p.x, y: p.y, vx: 0, vy: 0};
            }
        }
        function init() {
            const n = Math.max(12, Math.min(40, Math.round(W * H / 34000)));
            S = Array.from({length: n}, mk).sort((a, b) => b.sz - a.sz);
            const k = Math.max(2, Math.min(5, Math.round(W * H / 380000)));
            K = Array.from({length: k}, mkSnake);
            webs = []; marks = []; mouse = null;
            vignette = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.2, W / 2, H / 2, Math.hypot(W, H) / 2);
            vignette.addColorStop(0, 'rgba(0,0,0,0)');
            vignette.addColorStop(1, 'rgba(0,0,0,.55)');
        }
        function next(s) {
            s.snake = null; s.prey = null; s.web = null;
            if (isOff(s.x, s.y, 10)) { s.state = 'away'; s.t = rand(1.5, 6); return; }
            const r = Math.random();
            if (mouse && r < 0.1) { s.state = 'chase'; s.t = rand(5, 9); return; }
            if (s.sp.bold && r < 0.2) {
                const vis = K.filter(k => !isOff(k.pts[20].x, k.pts[20].y, 0));
                if (vis.length) {
                    s.state = 'attackSnake'; s.snake = vis[(Math.random() * vis.length) | 0];
                    s.seg = (rand(8, 45)) | 0; s.t = rand(5, 9);
                    return;
                }
            }
            if (s.sp.weaver && r < 0.28 && webs.length < 3) {
                const cx = rand(W * 0.1, W * 0.9), cy = rand(H * 0.1, H * 0.85);
                if (!webs.some(wb => Math.hypot(wb.cx - cx, wb.cy - cy) < wb.R + 140)) {
                    s.web = makeWeb(cx, cy); webs.push(s.web);
                    s.state = 'toWeb'; s.t = 20;
                    return;
                }
            }
            if (s.sp.hunter && r < 0.4) {
                let best = null, bd = 400;
                for (const o of S) {
                    if (o === s || o.sz > s.sz * 0.6 || isOff(o.x, o.y, 0)) continue;
                    const d = Math.hypot(o.x - s.x, o.y - s.y);
                    if (d < bd) { bd = d; best = o; }
                }
                if (best) { s.state = 'hunt'; s.prey = best; s.t = rand(4, 8); return; }
            }
            if (r < 0.5) { s.state = 'rest'; s.t = rand(0.6, 3); return; }
            if (r < 0.62) { s.state = 'leave'; [s.tx, s.ty] = offT(0); s.t = 14; return; }
            s.state = 'wander'; [s.tx, s.ty] = onT(); s.t = rand(3, 8);
        }
        function mouseThreat(x, y, near, chaser) {
            if (!mouse) return false;
            const dx = x - mouse.x, dy = y - mouse.y, d = Math.hypot(dx, dy) || 1;
            const app = (mouse.vx * dx + mouse.vy * dy) / d;
            if (chaser) return app > 140 && d < 280;
            return d < near || (app > 160 && d < 240);
        }
        function flee(s, x, y) {
            if (s.state !== 'flee') { s.state = 'flee'; s.t = rand(0.7, 1.2); s.snake = null; s.web = null; }
            s.t = Math.max(s.t, 0.5); s.fx = x; s.fy = y;
        }
        function snakeBitten(k, s) {
            k.thrash = 1;
            if (Math.random() < 0.5) {
                k.state = 'flee'; k.t = rand(1.5, 2.5); k.fx = s.x; k.fy = s.y;
            } else {
                k.state = 'strike'; k.prey = s; k.t = rand(0.8, 1.4);
            }
        }
        function updateSpider(s, dt) {
            const chaser = s.state === 'chase' || s.state === 'bite';
            if (mouseThreat(s.x, s.y, 100 + s.sz * 4, chaser)) {
                flee(s, mouse.x, mouse.y);
            } else if (!s.sp.hunter || s.state === 'attackSnake') {
                let hit = false;
                for (const k of K) {
                    if (s.state === 'attackSnake' && k === s.snake && k.state !== 'strike') continue;
                    const h = k.pts[0];
                    if (Math.hypot(s.x - h.x, s.y - h.y) < 90 + s.sz * 2) { flee(s, h.x, h.y); hit = true; break; }
                }
                if (!hit) {
                    for (const o of S) {
                        if (o.state === 'hunt' && o.prey === s && Math.hypot(s.x - o.x, s.y - o.y) < 130) { flee(s, o.x, o.y); break; }
                    }
                }
            }
            s.t -= dt;
            let v = s.speed, turn = 3, target = null;
            switch (s.state) {
            case 'rest':
                s.moving = false;
                if (s.t <= 0) next(s);
                break;
            case 'away':
                s.moving = false;
                if (s.t <= 0) { s.state = 'wander'; [s.tx, s.ty] = onT(); s.t = rand(4, 9); }
                break;
            case 'wander':
            case 'leave':
                s.moving = true; target = [s.tx, s.ty]; s.h += rand(-1, 1) * dt * 1.5;
                if (Math.hypot(s.tx - s.x, s.ty - s.y) < 20 || s.t <= 0) {
                    if (s.state === 'leave' && isOff(s.x, s.y, 10)) { s.state = 'away'; s.t = rand(1.5, 6); } else next(s);
                }
                break;
            case 'chase':
                if (!mouse) { next(s); break; }
                s.moving = true; target = [mouse.x, mouse.y]; turn = 5; v *= 1.5;
                if (Math.hypot(mouse.x - s.x, mouse.y - s.y) < 14 + s.sz) { s.state = 'bite'; s.t = 0.18; } else if (s.t <= 0) next(s);
                break;
            case 'bite':
                s.moving = true; turn = 12; v *= 4;
                if (mouse) target = [mouse.x, mouse.y];
                if (s.t <= 0) {
                    const bx = mouse ? mouse.x : s.x, by = mouse ? mouse.y : s.y;
                    marks.push({x: bx, y: by, t: 0.9});
                    s.state = 'flee'; s.fx = bx; s.fy = by; s.t = rand(0.5, 0.9);
                }
                break;
            case 'attackSnake': {
                const k = s.snake;
                if (!k || !K.includes(k) || s.t <= 0) { next(s); break; }
                const p = k.pts[Math.min(k.pts.length - 1, s.seg)];
                if (isOff(p.x, p.y, 0)) { next(s); break; }
                s.moving = true; target = [p.x, p.y]; turn = 6; v *= 1.7;
                if (Math.hypot(p.x - s.x, p.y - s.y) < s.sz + k.w * 0.6) {
                    marks.push({x: p.x, y: p.y, t: 0.9});
                    snakeBitten(k, s);
                    s.snake = null;
                    s.state = 'flee'; s.fx = p.x; s.fy = p.y; s.t = rand(0.9, 1.5);
                }
                break;
            }
            case 'toWeb': {
                const wb = s.web;
                if (!wb || !webs.includes(wb) || s.t <= 0) { next(s); break; }
                s.moving = true; target = [wb.cx, wb.cy];
                if (Math.hypot(wb.cx - s.x, wb.cy - s.y) < 8) { s.state = 'weave'; s.t = 999; }
                break;
            }
            case 'weave': {
                const wb = s.web;
                if (!wb || !webs.includes(wb)) { next(s); break; }
                wb.p = Math.min(1, wb.p + dt / rand(9, 12));
                const [cx, cy] = webCursor(wb);
                const ang = Math.atan2(cy - s.y, cx - s.x);
                if (Math.hypot(cx - s.x, cy - s.y) > 0.5) s.h = ang;
                s.ph += dt * 14;
                s.x += (cx - s.x) * Math.min(1, dt * 12); s.y += (cy - s.y) * Math.min(1, dt * 12);
                s.moving = false;
                if (wb.p >= 1) { s.state = 'sitWeb'; s.t = rand(8, 25); }
                return;
            }
            case 'sitWeb': {
                const wb = s.web;
                s.moving = false;
                if (!wb || !webs.includes(wb) || s.t <= 0) { next(s); break; }
                s.x += (wb.cx - s.x) * Math.min(1, dt * 4); s.y += (wb.cy - s.y) * Math.min(1, dt * 4);
                return;
            }
            case 'hunt':
                if (!s.prey || isOff(s.prey.x, s.prey.y, 0) || s.t <= 0) { next(s); break; }
                s.moving = true; target = [s.prey.x, s.prey.y]; v *= 1.6;
                if (Math.hypot(s.prey.x - s.x, s.prey.y - s.y) < s.sz) next(s);
                break;
            case 'flee':
                s.moving = true; turn = 10; v *= 2.8;
                target = [s.x + (s.x - s.fx), s.y + (s.y - s.fy)];
                if (s.t <= 0) {
                    if (isOff(s.x, s.y, 10)) { s.state = 'away'; s.t = rand(1.5, 5); } else { s.state = 'wander'; [s.tx, s.ty] = onT(); s.t = rand(3, 7); }
                }
                break;
            }
            if (s.moving) {
                if (target) s.h += angDiff(Math.atan2(target[1] - s.y, target[0] - s.x) - s.h) * Math.min(1, turn * dt);
                if (s.sp.jumper) {
                    s.hop -= dt;
                    if (s.hop <= 0) { s.hv = 1; s.hop = rand(0.35, 1.1) / (s.state === 'flee' ? 2.8 : 1); }
                    s.hv *= Math.exp(-dt * 9); v *= s.hv * 4;
                }
                s.x = Math.max(-160, Math.min(W + 160, s.x + Math.cos(s.h) * v * dt));
                s.y = Math.max(-160, Math.min(H + 160, s.y + Math.sin(s.h) * v * dt));
                s.ph += dt * v / (s.sz * s.sp.leg * 0.35);
            }
        }
        function updateSnake(k, dt) {
            const head = k.pts[0];
            if (k.state !== 'strike' && mouseThreat(head.x, head.y, 150, false)) {
                if (k.state !== 'flee') { k.state = 'flee'; k.t = rand(1.2, 2); }
                k.t = Math.max(k.t, 0.8); k.fx = mouse.x; k.fy = mouse.y;
            }
            k.t -= dt;
            k.thrash = Math.max(0, k.thrash - dt);
            let v = k.speed, turn = 1.6, target = null;
            switch (k.state) {
            case 'rest':
            case 'away':
                k.moving = k.thrash > 0;
                if (k.t <= 0) { k.state = 'wander'; [k.tx, k.ty] = onT(); k.t = rand(6, 14); }
                break;
            case 'wander':
            case 'leave':
                k.moving = true; target = [k.tx, k.ty];
                if (Math.hypot(k.tx - head.x, k.ty - head.y) < 30 || k.t <= 0) {
                    if (k.state === 'leave' && isOff(head.x, head.y, 200)) {
                        k.state = 'away'; k.t = rand(3, 9);
                    } else {
                        const r = Math.random();
                        if (r < 0.2) { k.state = 'rest'; k.t = rand(1.5, 4); } else if (r < 0.45) { k.state = 'leave'; [k.tx, k.ty] = offT(240); k.t = 25; } else { k.state = 'wander'; [k.tx, k.ty] = onT(); k.t = rand(6, 12); }
                    }
                }
                break;
            case 'strike': {
                const p = k.prey;
                k.moving = true; turn = 4; v *= 2.6;
                if (!p || k.t <= 0) { k.state = 'wander'; [k.tx, k.ty] = onT(); k.t = rand(6, 12); k.prey = null; break; }
                target = [p.x, p.y];
                if (Math.hypot(p.x - head.x, p.y - head.y) < p.sz + k.w) {
                    flee(p, head.x, head.y); p.t = rand(1.2, 2);
                    k.state = 'wander'; [k.tx, k.ty] = onT(); k.t = rand(6, 12); k.prey = null;
                }
                break;
            }
            case 'flee':
                k.moving = true; turn = 3; v *= 2.2;
                target = [head.x + (head.x - k.fx), head.y + (head.y - k.fy)];
                if (k.t <= 0) {
                    if (isOff(head.x, head.y, 30)) { k.state = 'away'; k.t = rand(3, 8); } else { k.state = 'wander'; [k.tx, k.ty] = onT(); k.t = rand(6, 12); }
                }
                break;
            }
            k.tk -= dt;
            if (k.tk <= 0) { k.tongue = 0.35; k.tk = rand(1.5, 4); }
            k.tongue -= dt;
            if (!k.moving) return;
            if (target) k.h += angDiff(Math.atan2(target[1] - head.y, target[0] - head.x) - k.h) * Math.min(1, turn * dt);
            if (k.thrash > 0) v = Math.max(v, k.speed * 1.5);
            k.ph += dt * v / 12 * (1 + k.thrash * 3);
            const dir = k.h + Math.sin(k.ph) * (0.55 + k.thrash * 1.1);
            head.x = Math.max(-420, Math.min(W + 420, head.x + Math.cos(dir) * v * dt));
            head.y = Math.max(-420, Math.min(H + 420, head.y + Math.sin(dir) * v * dt));
            for (let i = 1; i < k.pts.length; i++) {
                const a = k.pts[i - 1], b = k.pts[i], dx = b.x - a.x, dy = b.y - a.y, d = Math.hypot(dx, dy) || 1;
                if (d > k.seg) { b.x = a.x + dx / d * k.seg; b.y = a.y + dy / d * k.seg; }
            }
        }
        function drawWebs(dt) {
            ctx.lineCap = 'round';
            for (let i = webs.length - 1; i >= 0; i--) {
                const wb = webs[i];
                wb.life -= dt;
                if (mouse && Math.hypot(mouse.x - wb.cx, mouse.y - wb.cy) < wb.R && Math.hypot(mouse.vx, mouse.vy) > 400)
                    wb.life = Math.min(wb.life, 1.5);
                if (wb.life <= 0) { webs.splice(i, 1); continue; }
                const a = Math.min(1, wb.life / 3) * 0.32;
                ctx.strokeStyle = `rgba(225,228,238,${a.toFixed(2)})`; ctx.lineWidth = 0.8;
                const n = wb.spokes.length, sp = Math.min(1, wb.p / 0.3) * n;
                ctx.beginPath();
                for (let j = 0; j < Math.ceil(sp); j++) {
                    const s = wb.spokes[j], f = Math.min(1, sp - j);
                    ctx.moveTo(wb.cx, wb.cy); ctx.lineTo(wb.cx + Math.cos(s.a) * s.len * f, wb.cy + Math.sin(s.a) * s.len * f);
                }
                ctx.stroke();
                if (wb.p > 0.3) {
                    const m = Math.min(wb.spiral.length, (((wb.p - 0.3) / 0.7) * wb.spiral.length) | 0);
                    if (m > 1) {
                        ctx.lineWidth = 0.6;
                        ctx.beginPath(); ctx.moveTo(wb.spiral[0][0], wb.spiral[0][1]);
                        for (let j = 1; j < m; j++) ctx.lineTo(wb.spiral[j][0], wb.spiral[j][1]);
                        ctx.stroke();
                    }
                }
            }
        }
        function drawSnake(k) {
            const n = k.pts.length, w = k.w;
            if (k.pts.every(p => isOff(p.x, p.y, 20))) return;
            if (k.sp.rattle) {
                const a = k.pts[n - 2], b = k.pts[n - 1], ang = Math.atan2(b.y - a.y, b.x - a.x);
                const shake = k.thrash > 0 || k.state === 'flee' ? Math.sin(k.ph * 9) * 0.4 : 0;
                ctx.fillStyle = '#cdbb90';
                for (let j = 1; j <= 4; j++) {
                    const d = j * w * 0.32;
                    ctx.beginPath(); ctx.ellipse(b.x + Math.cos(ang + shake) * d, b.y + Math.sin(ang + shake) * d, w * 0.2, w * 0.15, ang + shake, 0, TAU); ctx.fill();
                }
            }
            for (let i = n - 1; i >= 0; i--) {
                const t = i / (n - 1), prof = t < 0.08 ? 0.8 + t * 2.5 : Math.pow(1 - t, 0.6) * 0.95 + 0.05;
                ctx.fillStyle = k.sp.color(i);
                dot(k.pts[i].x, k.pts[i].y, Math.max(0.8, w * 0.5 * prof));
            }
            ctx.strokeStyle = 'rgba(255,255,255,.1)'; ctx.lineWidth = w * 0.22; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
            ctx.beginPath(); ctx.moveTo(k.pts[1].x, k.pts[1].y);
            for (let i = 2; i < n * 0.8; i++) ctx.lineTo(k.pts[i].x, k.pts[i].y);
            ctx.stroke();
            const p0 = k.pts[0], p1 = k.pts[1], a = Math.atan2(p0.y - p1.y, p0.x - p1.x);
            ctx.save(); ctx.translate(p0.x, p0.y); ctx.rotate(a);
            if (k.tongue > 0 || k.state === 'strike') {
                ctx.strokeStyle = '#d0283a'; ctx.lineWidth = 1.2; ctx.beginPath();
                ctx.moveTo(w * 0.8, 0); ctx.lineTo(w * 1.6, 0); ctx.lineTo(w * 1.95, -w * 0.25);
                ctx.moveTo(w * 1.6, 0); ctx.lineTo(w * 1.95, w * 0.25); ctx.stroke();
            }
            ctx.fillStyle = k.sp.head; ctx.beginPath(); ctx.ellipse(w * 0.25, 0, w * 0.75, w * 0.55, 0, 0, TAU); ctx.fill();
            ctx.fillStyle = '#0b0b0b'; dot(w * 0.55, -w * 0.3, Math.max(0.8, w * 0.1)); dot(w * 0.55, w * 0.3, Math.max(0.8, w * 0.1));
            ctx.restore();
        }
        function drawSpider(s) {
            const z = s.sz, sp = s.sp, L = z * sp.leg, ab = sp.abd || 1;
            const moving = s.moving || s.state === 'weave';
            ctx.save(); ctx.translate(s.x, s.y); ctx.rotate(s.h);
            ctx.strokeStyle = sp.legC; ctx.lineWidth = Math.max(0.8, z * sp.thick); ctx.lineJoin = 'round'; ctx.lineCap = 'round';
            const knees = [];
            ctx.beginPath();
            for (const side of [-1, 1]) {
                for (let j = 0; j < 4; j++) {
                    const swing = moving ? Math.sin(s.ph + (j % 2) * Math.PI + (side > 0 ? Math.PI : 0)) * 0.28 : 0;
                    const ang = side * (Math.PI / 2 - bias[j] - swing);
                    const rx = z * 0.35 - j * z * 0.12, ry = side * z * 0.12;
                    const kx = rx + Math.cos(ang) * L, ky = ry + Math.sin(ang) * L;
                    const fa = ang + side * (j < 2 ? -0.45 : 0.45);
                    ctx.moveTo(rx, ry); ctx.lineTo(kx, ky);
                    ctx.lineTo(kx + Math.cos(fa) * L * 1.15, ky + Math.sin(fa) * L * 1.15);
                    knees.push(kx, ky);
                }
            }
            ctx.stroke();
            if (sp.mark === 'hairy') {
                ctx.fillStyle = sp.knee;
                for (let i = 0; i < knees.length; i += 2) dot(knees[i], knees[i + 1], z * 0.1);
            }
            const ax = -z * 0.55 * ab;
            ctx.fillStyle = sp.body; ctx.beginPath(); ctx.ellipse(ax, 0, z * 0.65 * ab, z * 0.5 * ab, 0, 0, TAU); ctx.fill();
            ctx.fillStyle = sp.head; ctx.beginPath(); ctx.ellipse(z * 0.25, 0, z * 0.4, z * 0.32, 0, 0, TAU); ctx.fill();
            switch (sp.mark) {
            case 'chevrons':
                ctx.strokeStyle = '#7a6654'; ctx.lineWidth = Math.max(0.7, z * 0.07); ctx.beginPath();
                for (let k = 0; k < 3; k++) { const x = -z * 0.25 - k * z * 0.28; ctx.moveTo(x - z * 0.12, -z * 0.2); ctx.lineTo(x, 0); ctx.lineTo(x - z * 0.12, z * 0.2); }
                ctx.stroke();
                break;
            case 'widow': {
                ctx.fillStyle = '#2c2c33'; ctx.beginPath(); ctx.ellipse(-z * 0.7, -z * 0.18, z * 0.22, z * 0.1, 0, 0, TAU); ctx.fill();
                const hx = -z * 0.6, a = z * 0.22, b = z * 0.13;
                ctx.fillStyle = '#d41a1a'; ctx.beginPath(); ctx.moveTo(hx - a, -b); ctx.lineTo(hx - a, b); ctx.lineTo(hx + a, -b); ctx.lineTo(hx + a, b); ctx.closePath(); ctx.fill();
                break;
            }
            case 'stripes':
                ctx.strokeStyle = sp.stripe; ctx.lineWidth = Math.max(0.7, z * 0.08); ctx.beginPath();
                for (const y of [-z * 0.12, z * 0.12]) { ctx.moveTo(z * 0.5, y); ctx.lineTo(-z * 1.0, y); }
                ctx.stroke();
                break;
            case 'spots':
                ctx.fillStyle = '#e8e8e8'; dot(-z * 0.45, -z * 0.2, z * 0.1); dot(-z * 0.45, z * 0.2, z * 0.1); dot(-z * 0.85, 0, z * 0.1);
                break;
            case 'peacock':
                ctx.fillStyle = '#e0442a'; ctx.beginPath(); ctx.ellipse(ax - z * 0.15, 0, z * 0.42, z * 0.38, 0, 0, TAU); ctx.fill();
                ctx.fillStyle = '#ffb02e'; dot(ax - z * 0.2, -z * 0.18, z * 0.09); dot(ax - z * 0.2, z * 0.18, z * 0.09);
                ctx.fillStyle = '#35d0e8'; dot(ax + z * 0.15, 0, z * 0.1);
                break;
            case 'bands':
                ctx.strokeStyle = '#111111'; ctx.lineWidth = Math.max(0.8, z * 0.1); ctx.beginPath();
                for (let k = 0; k < 4; k++) { const x = ax + z * 0.35 * ab - k * z * 0.24 * ab; const hy = z * 0.42 * ab * Math.sqrt(Math.max(0, 1 - ((x - ax) / (z * 0.65 * ab)) ** 2)); ctx.moveTo(x, -hy); ctx.lineTo(x, hy); }
                ctx.stroke();
                break;
            case 'crab':
                ctx.fillStyle = '#e87a90'; ctx.beginPath(); ctx.ellipse(ax, -z * 0.3, z * 0.4, z * 0.08, 0, 0, TAU); ctx.fill();
                ctx.beginPath(); ctx.ellipse(ax, z * 0.3, z * 0.4, z * 0.08, 0, 0, TAU); ctx.fill();
                break;
            }
            if (sp.jumper) {
                ctx.fillStyle = '#000000'; dot(z * 0.55, -z * 0.13, z * 0.13); dot(z * 0.55, z * 0.13, z * 0.13);
                ctx.fillStyle = 'rgba(255,255,255,.8)'; dot(z * 0.6, -z * 0.15, z * 0.04); dot(z * 0.6, z * 0.11, z * 0.04);
            } else if (sp.mark !== 'widow') {
                ctx.fillStyle = '#bb3333'; dot(z * 0.58, -z * 0.08, Math.max(0.7, z * 0.05)); dot(z * 0.58, z * 0.08, Math.max(0.7, z * 0.05));
            }
            if (s.state === 'bite' || s.state === 'attackSnake') {
                ctx.strokeStyle = '#dddddd'; ctx.lineWidth = Math.max(0.8, z * 0.06); ctx.beginPath();
                ctx.moveTo(z * 0.6, -z * 0.1); ctx.lineTo(z * 0.85, -z * 0.03); ctx.moveTo(z * 0.6, z * 0.1); ctx.lineTo(z * 0.85, z * 0.03); ctx.stroke();
            }
            ctx.restore();
        }
        function frame(dt) {
            updateMouse(dt);
            ctx.fillStyle = '#2c2d33'; ctx.fillRect(0, 0, W, H);
            ctx.fillStyle = vignette; ctx.fillRect(0, 0, W, H);
            drawWebs(dt);
            for (const k of K) { updateSnake(k, dt); drawSnake(k); }
            for (const s of S) {
                updateSpider(s, dt);
                if (!isOff(s.x, s.y, 60)) drawSpider(s);
            }
            for (let i = marks.length - 1; i >= 0; i--) {
                const m = marks[i];
                m.t -= dt;
                if (m.t <= 0) { marks.splice(i, 1); continue; }
                const a = m.t / 0.9;
                ctx.strokeStyle = `rgba(220,40,40,${(a * 0.6).toFixed(2)})`; ctx.lineWidth = 2;
                ctx.beginPath(); ctx.arc(m.x, m.y, 10 + (1 - a) * 16, 0, TAU); ctx.stroke();
                ctx.fillStyle = `rgba(200,20,20,${a.toFixed(2)})`; dot(m.x - 3, m.y, 1.8); dot(m.x + 3, m.y, 1.8);
            }
        }
        return {init, frame};
    })();

    /* Starfield with a nebula backdrop, passing suns and planets */
    const starfield = (() => {
        const LEVELS = 10;
        let S = [], P = [], sun = null, neb = null, t = 0;
        const buckets = Array.from({length: LEVELS}, () => []);
        const PLANETS = [
            {light: '#f6d2a2', base: '#d9a066', dark: '#5a3a1c', bands: ['rgba(120,70,30,.35)', 'rgba(255,230,190,.25)'], ring: false},
            {light: '#fff3d6', base: '#e2cc96', dark: '#6b5a3a', bands: ['rgba(150,120,70,.3)'], ring: true},
            {light: '#a8d4ff', base: '#3f7fd0', dark: '#0c1f45', bands: ['rgba(80,170,90,.45)', 'rgba(255,255,255,.3)'], ring: false},
            {light: '#f0a080', base: '#c2553a', dark: '#3b120a', bands: [], ring: false},
            {light: '#d8fbff', base: '#7fd6e0', dark: '#1d4a5a', bands: ['rgba(255,255,255,.18)'], ring: true},
            {light: '#e2d4ff', base: '#a58bd9', dark: '#2a1d4a', bands: ['rgba(60,30,110,.35)', 'rgba(255,255,255,.15)'], ring: false},
        ];
        const SUNS = [
            {core: '#fffbe8', glow: '255,200,90'},
            {core: '#ffffff', glow: '150,190,255'},
            {core: '#fff2dc', glow: '255,120,60'},
            {core: '#fff0f8', glow: '255,120,190'},
        ];
        const NEB = [[120, 60, 210], [210, 60, 150], [60, 110, 230], [40, 190, 210], [230, 120, 60], [90, 200, 140]];
        const gauss = () => (rand(-1, 1) + rand(-1, 1) + rand(-1, 1)) / 3;

        function buildNebula() {
            const L = makeLayer(W * 1.3, H * 1.3, env.rs), g = L.ctx;
            g.globalCompositeOperation = 'lighter';
            const clouds = 2 + ((Math.random() * 2) | 0);
            for (let c = 0; c < clouds; c++) {
                const cx = rand(0.15, 0.85) * L.w, cy = rand(0.15, 0.85) * L.h;
                const pal = [NEB[(Math.random() * NEB.length) | 0], NEB[(Math.random() * NEB.length) | 0]];
                for (let i = 0; i < 45; i++) {
                    const x = cx + gauss() * L.w * 0.35, y = cy + gauss() * L.h * 0.3, r = rand(0.04, 0.17) * L.w;
                    const col = pal[i % 2], a = rand(0.04, 0.09);
                    const gr = g.createRadialGradient(x, y, 0, x, y, r);
                    gr.addColorStop(0, `rgba(${col[0]},${col[1]},${col[2]},${a.toFixed(3)})`);
                    gr.addColorStop(1, `rgba(${col[0]},${col[1]},${col[2]},0)`);
                    g.fillStyle = gr; g.fillRect(x - r, y - r, r * 2, r * 2);
                }
            }
            g.globalCompositeOperation = 'source-over';
            for (let i = 0; i < 18; i++) {
                const x = rand(0, L.w), y = rand(0, L.h), r = rand(0.03, 0.1) * L.w;
                const gr = g.createRadialGradient(x, y, 0, x, y, r);
                gr.addColorStop(0, 'rgba(0,0,6,.35)'); gr.addColorStop(1, 'rgba(0,0,6,0)');
                g.fillStyle = gr; g.fillRect(x - r, y - r, r * 2, r * 2);
            }
            return L;
        }
        function reset(s, initial) { s.x = rand(-1, 1); s.y = rand(-1, 1); s.z = initial ? rand(0.05, 1) : 1; s.pz = s.z; }
        function resetP(p, initial) {
            p.def = PLANETS[(Math.random() * PLANETS.length) | 0];
            const a = rand(0, TAU), m = rand(0.2, 1);
            p.x = Math.cos(a) * m; p.y = Math.sin(a) * m;
            p.z = initial ? rand(0.3, 1) : 1;
            p.r = rand(0.006, 0.02); p.tilt = rand(-0.6, 0.6);
            p.bands = Array.from({length: 4}, () => ({o: rand(-0.9, 0.7), w: rand(0.08, 0.25)}));
            p.wait = initial ? rand(0, 2) : rand(1, 6);
        }
        function resetSun(s, initial) {
            s.def = SUNS[(Math.random() * SUNS.length) | 0];
            const a = rand(0, TAU), m = rand(0.3, 0.9);
            s.x = Math.cos(a) * m; s.y = Math.sin(a) * m;
            s.z = 1; s.r = rand(0.008, 0.02); s.spin = rand(0, TAU);
            s.wait = initial ? rand(3, 8) : rand(8, 20);
        }
        function init() {
            const n = Math.round(Math.min(700, W * H / 2600));
            S = Array.from({length: n}, () => { const s = {}; reset(s, true); return s; });
            P = Array.from({length: 2}, () => { const p = {}; resetP(p, true); return p; });
            sun = {}; resetSun(sun, true);
            neb = buildNebula();
            t = 0;
        }
        function ring(p, sx, sy, R, front) {
            ctx.save(); ctx.translate(sx, sy); ctx.rotate(p.tilt);
            ctx.beginPath(); ctx.rect(-R * 3, front ? 0 : -R * 1.2, R * 6, R * 1.2); ctx.clip();
            ctx.strokeStyle = 'rgba(235,220,185,.55)'; ctx.lineWidth = R * 0.22;
            ctx.beginPath(); ctx.ellipse(0, 0, R * 1.9, R * 0.45, 0, 0, TAU); ctx.stroke();
            ctx.strokeStyle = 'rgba(235,220,185,.3)'; ctx.lineWidth = R * 0.1;
            ctx.beginPath(); ctx.ellipse(0, 0, R * 2.3, R * 0.56, 0, 0, TAU); ctx.stroke();
            ctx.restore();
        }
        function planet(p, sx, sy, R) {
            const d = p.def;
            if (d.ring) ring(p, sx, sy, R, false);
            const g = ctx.createRadialGradient(sx - R * 0.35, sy - R * 0.35, R * 0.05, sx, sy, R);
            g.addColorStop(0, d.light); g.addColorStop(0.6, d.base); g.addColorStop(1, d.dark);
            ctx.fillStyle = g; dot(sx, sy, R);
            if (d.bands.length) {
                ctx.save(); ctx.beginPath(); ctx.arc(sx, sy, R, 0, TAU); ctx.clip();
                ctx.translate(sx, sy); ctx.rotate(p.tilt);
                p.bands.forEach((b, i) => { ctx.fillStyle = d.bands[i % d.bands.length]; ctx.fillRect(-R, b.o * R, R * 2, b.w * R); });
                ctx.restore();
            }
            const sh = ctx.createRadialGradient(sx - R * 0.45, sy - R * 0.45, R * 0.3, sx - R * 0.2, sy - R * 0.2, R * 1.6);
            sh.addColorStop(0, 'rgba(0,0,0,0)'); sh.addColorStop(1, 'rgba(0,0,6,.85)');
            ctx.fillStyle = sh; dot(sx, sy, R);
            if (d.ring) ring(p, sx, sy, R, true);
        }
        function drawSun(s, sx, sy, R) {
            const gl = s.def.glow;
            ctx.globalCompositeOperation = 'lighter';
            const c = ctx.createRadialGradient(sx, sy, 0, sx, sy, R * 7);
            c.addColorStop(0, `rgba(${gl},.55)`); c.addColorStop(0.18, `rgba(${gl},.2)`); c.addColorStop(1, `rgba(${gl},0)`);
            ctx.fillStyle = c; ctx.fillRect(sx - R * 7, sy - R * 7, R * 14, R * 14);
            ctx.lineCap = 'round';
            for (let i = 0; i < 6; i++) {
                const a = s.spin + t * 0.15 + i * Math.PI / 3, len = R * (i % 2 ? 6 : 9);
                ctx.strokeStyle = `rgba(${gl},.12)`; ctx.lineWidth = Math.max(1, R * 0.12);
                ctx.beginPath(); ctx.moveTo(sx - Math.cos(a) * len, sy - Math.sin(a) * len); ctx.lineTo(sx + Math.cos(a) * len, sy + Math.sin(a) * len); ctx.stroke();
            }
            ctx.globalCompositeOperation = 'source-over';
            const core = ctx.createRadialGradient(sx, sy, 0, sx, sy, R);
            core.addColorStop(0, s.def.core); core.addColorStop(0.75, `rgba(${gl},1)`); core.addColorStop(1, `rgba(${gl},0)`);
            ctx.fillStyle = core; dot(sx, sy, R);
        }
        function frame(dt) {
            t += dt;
            ctx.fillStyle = '#000006'; ctx.fillRect(0, 0, W, H);
            ctx.drawImage(neb, -W * 0.15 + Math.sin(t * 0.02) * W * 0.1, -H * 0.15 + Math.cos(t * 0.017) * H * 0.1);
            const cx = W / 2, cy = H / 2, k = Math.max(W, H) * 0.5;
            for (const b of buckets) b.length = 0;
            for (const s of S) {
                s.pz = s.z; s.z -= dt * 0.3;
                if (s.z <= 0.02) { reset(s, false); continue; }
                const sx = cx + s.x / s.z * k, sy = cy + s.y / s.z * k;
                if (sx < -50 || sx > W + 50 || sy < -50 || sy > H + 50) { reset(s, false); continue; }
                const lvl = Math.min(LEVELS - 1, ((1 - s.z) * LEVELS) | 0);
                buckets[lvl].push(cx + s.x / s.pz * k, cy + s.y / s.pz * k, sx + 0.1, sy);
            }
            ctx.lineCap = 'round';
            for (let l = 0; l < LEVELS; l++) {
                const b = buckets[l];
                if (!b.length) continue;
                const tt = (l + 1) / LEVELS;
                ctx.strokeStyle = `rgba(210,225,255,${tt.toFixed(2)})`; ctx.lineWidth = 0.4 + tt * 2.4;
                ctx.beginPath();
                for (let i = 0; i < b.length; i += 4) { ctx.moveTo(b[i], b[i + 1]); ctx.lineTo(b[i + 2], b[i + 3]); }
                ctx.stroke();
            }
            if (sun.wait > 0) {
                sun.wait -= dt;
            } else {
                sun.z -= dt * 0.3;
                const sx = cx + sun.x / sun.z * k, sy = cy + sun.y / sun.z * k, R = sun.r / sun.z * k, m = R * 7;
                if (sun.z < 0.03 || sx + m < 0 || sx - m > W || sy + m < 0 || sy - m > H) resetSun(sun, false);
                else drawSun(sun, sx, sy, R);
            }
            P.sort((a, b) => b.z - a.z);
            for (const p of P) {
                if (p.wait > 0) { p.wait -= dt; continue; }
                p.z -= dt * 0.3;
                const sx = cx + p.x / p.z * k, sy = cy + p.y / p.z * k, R = p.r / p.z * k, m = R * 2.4;
                if (p.z < 0.03 || sx + m < 0 || sx - m > W || sy + m < 0 || sy - m > H) { resetP(p, false); continue; }
                planet(p, sx, sy, R);
            }
        }
        return {init, frame};
    })();

    /* Kittens (a cosy room full of cats) and Cursor cat (one cat that hunts your mouse), with boxes, furniture and balls of wool you can pick up */
    const makeKittens = solo => {
        let back = null, plats = [], boxes = [], balls = [], cats = [], items = [], bowls = [], post = null, rug = null;
        let fy = 0, sc = 1, now = 0, G = 2400, held = null, ptr = null, prevDown = false;
        const COATS = [
            {base: '#d98a3d', top: '#e9a55a', under: '#b86b2a', dark: '#a35a22', light: '#f4dcb8', pattern: 'tabby', eye: '#c8a43a'},
            {base: '#26262a', top: '#34343a', under: '#1a1a1d', dark: '#121214', light: '#3c3c42', pattern: 'solid', eye: '#e2c040'},
            {base: '#efece6', top: '#fbfaf7', under: '#d5d0c6', dark: '#c9c2b6', light: '#ffffff', pattern: 'solid', eye: '#69a6e0'},
            {base: '#8b9096', top: '#a2a7ad', under: '#6e7378', dark: '#5a5f64', light: '#d4d7da', pattern: 'tabby', eye: '#8ec45a'},
            {base: '#f2ece1', top: '#fbf7ef', under: '#d8cfc0', dark: '#2a2a2e', light: '#ffffff', pattern: 'calico', eye: '#c79a3c'},
            {base: '#222226', top: '#2e2e33', under: '#18181b', dark: '#101012', light: '#f2f2f2', pattern: 'tuxedo', eye: '#9cc85a'},
            {base: '#ece0c6', top: '#f6eedc', under: '#d6c6a6', dark: '#4e3a2c', light: '#fbf3e4', pattern: 'siamese', eye: '#5aa0e8'},
            {base: '#7d6a55', top: '#94806a', under: '#615140', dark: '#3e3228', light: '#d9cbb6', pattern: 'tabby', eye: '#a8b85a'},
            {base: '#6f7a86', top: '#86919c', under: '#59636e', dark: '#4c5560', light: '#8f9aa5', pattern: 'solid', eye: '#7cc87a'},
            {base: '#f1e4cc', top: '#f9f0de', under: '#d9c7a8', dark: '#c9a878', light: '#fffaf0', pattern: 'tabby', eye: '#c9a040'},
            {base: '#f4f2ee', top: '#ffffff', under: '#dcd8d0', dark: '#222226', light: '#ffffff', pattern: 'cow', eye: '#c8a83a'},
            {base: '#c9944f', top: '#dcab66', under: '#a87838', dark: '#4a3018', light: '#f0dcb8', pattern: 'spots', eye: '#8fbf4f'},
        ];
        const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
        const lerp = (a, b, t) => a + (b - a) * t;

        /* ================= room ================= */
        let win = null;
        function buildRoom() {
            back = makeLayer(W, H, env.rs);
            const g = back.ctx;
            const wall = g.createLinearGradient(0, 0, 0, fy);
            wall.addColorStop(0, '#3a2f3f'); wall.addColorStop(1, '#5b4650');
            g.fillStyle = wall; g.fillRect(0, 0, W, fy);
            g.strokeStyle = 'rgba(255,255,255,.035)'; g.lineWidth = W * 0.012;
            g.beginPath();
            for (let x = W * 0.02; x < W; x += W * 0.045) { g.moveTo(x, 0); g.lineTo(x, fy); }
            g.stroke();
            const {x: wx, y: wy, w: ww, h: wh} = win;
            const sky = g.createLinearGradient(0, wy, 0, wy + wh);
            sky.addColorStop(0, '#0d1838'); sky.addColorStop(1, '#2b3d6b');
            g.fillStyle = '#2a1f1a'; g.fillRect(wx - H * 0.015, wy - H * 0.015, ww + H * 0.03, wh + H * 0.03);
            g.fillStyle = sky; g.fillRect(wx, wy, ww, wh);
            g.fillStyle = 'rgba(255,255,255,.8)';
            for (let i = 0; i < 25; i++) g.fillRect(wx + rand(0, ww), wy + rand(0, wh * 0.8), 1.5, 1.5);
            g.fillStyle = '#f4efd8'; g.beginPath(); g.arc(wx + ww * 0.72, wy + wh * 0.28, H * 0.035, 0, TAU); g.fill();
            g.fillStyle = '#2a1f1a'; g.fillRect(wx + ww / 2 - H * 0.006, wy, H * 0.012, wh); g.fillRect(wx, wy + wh / 2 - H * 0.006, ww, H * 0.012);
            const sill = plats[3];
            g.fillStyle = '#4a372b'; g.fillRect(sill.x0, sill.y, sill.x1 - sill.x0, H * 0.02);
            g.fillStyle = '#5c4636'; g.fillRect(sill.x0, sill.y, sill.x1 - sill.x0, H * 0.005);
            const lamp = g.createRadialGradient(W * 0.88, H * 0.28, 0, W * 0.88, H * 0.28, W * 0.45);
            lamp.addColorStop(0, 'rgba(255,190,110,.22)'); lamp.addColorStop(1, 'rgba(255,190,110,0)');
            g.fillStyle = lamp; g.fillRect(0, 0, W, H);
            const fl = g.createLinearGradient(0, fy, 0, H);
            fl.addColorStop(0, '#7a4e33'); fl.addColorStop(1, '#4e301f');
            g.fillStyle = fl; g.fillRect(0, fy, W, H - fy);
            g.strokeStyle = 'rgba(0,0,0,.18)'; g.lineWidth = 1.5;
            g.beginPath();
            for (let y = fy + H * 0.04; y < H; y += H * 0.05) { g.moveTo(0, y); g.lineTo(W, y); }
            g.stroke();
            g.fillStyle = '#2e2018'; g.fillRect(0, fy - H * 0.022, W, H * 0.022);
            g.fillStyle = 'rgba(160,60,70,.55)'; g.beginPath(); g.ellipse(rug.x, fy + H * 0.09, rug.w, H * 0.05, 0, 0, TAU); g.fill();
            g.strokeStyle = 'rgba(240,200,150,.35)'; g.lineWidth = 3; g.beginPath(); g.ellipse(rug.x, fy + H * 0.09, rug.w * 0.85, H * 0.038, 0, 0, TAU); g.stroke();
            for (const p of [plats[1], plats[2]]) {
                g.fillStyle = '#5a3a24';
                g.fillRect(p.x0 + H * 0.01, p.y, H * 0.016, fy - p.y);
                g.fillRect(p.x1 - H * 0.026, p.y, H * 0.016, fy - p.y);
                g.fillStyle = '#7b5233'; g.fillRect(p.x0 - H * 0.008, p.y, p.x1 - p.x0 + H * 0.016, H * 0.02);
                g.fillStyle = '#93663f'; g.fillRect(p.x0 - H * 0.008, p.y, p.x1 - p.x0 + H * 0.016, H * 0.005);
            }
            // scratching post
            g.fillStyle = '#6e5440'; g.fillRect(post.x - H * 0.05, fy - H * 0.018, H * 0.1, H * 0.018);
            g.fillStyle = '#c8ad80'; g.fillRect(post.x - post.w / 2, post.top, post.w, fy - post.top);
            g.strokeStyle = 'rgba(110,85,50,.5)'; g.lineWidth = 1.2; g.beginPath();
            for (let y = post.top + 3; y < fy - H * 0.02; y += 4) { g.moveTo(post.x - post.w / 2, y); g.lineTo(post.x + post.w / 2, y + 2); }
            g.stroke();
            g.fillStyle = '#7d6048'; g.fillRect(post.x - H * 0.035, post.top - H * 0.012, H * 0.07, H * 0.014);
            // bowls
            for (const b of bowls) {
                g.fillStyle = b.col;
                g.beginPath(); g.moveTo(b.x - b.w / 2, fy - b.h); g.lineTo(b.x + b.w / 2, fy - b.h); g.lineTo(b.x + b.w * 0.38, fy); g.lineTo(b.x - b.w * 0.38, fy); g.closePath(); g.fill();
                g.fillStyle = b.food; g.beginPath(); g.ellipse(b.x, fy - b.h, b.w * 0.44, b.h * 0.25, 0, 0, TAU); g.fill();
            }
            for (const b of boxes) {
                g.fillStyle = '#8f6537'; g.fillRect(b.x - b.w / 2, b.top - b.h * 0.16, b.w, b.h * 0.16);
                g.fillStyle = '#b5844e';
                g.beginPath(); g.moveTo(b.x - b.w / 2, b.top); g.lineTo(b.x - b.w / 2 - b.w * 0.22, b.top - b.h * 0.42); g.lineTo(b.x - b.w / 2 + b.w * 0.06, b.top - b.h * 0.36); g.closePath(); g.fill();
                g.beginPath(); g.moveTo(b.x + b.w / 2, b.top); g.lineTo(b.x + b.w / 2 + b.w * 0.2, b.top - b.h * 0.45); g.lineTo(b.x + b.w / 2 - b.w * 0.05, b.top - b.h * 0.38); g.closePath(); g.fill();
            }
        }
        function drawBoxFront(b) {
            if (b.crate) {
                ctx.fillStyle = '#b08455'; ctx.fillRect(b.x - b.w / 2, b.top, b.w, b.h);
                ctx.fillStyle = 'rgba(60,40,20,.45)';
                for (let i = 1; i < 3; i++) ctx.fillRect(b.x - b.w / 2, b.top + b.h * i / 3 - 1, b.w, 2.5);
                ctx.fillStyle = '#8a6440'; ctx.fillRect(b.x - b.w / 2, b.top, b.w * 0.08, b.h); ctx.fillRect(b.x + b.w * 0.42, b.top, b.w * 0.08, b.h);
                return;
            }
            ctx.fillStyle = '#c99657'; ctx.fillRect(b.x - b.w / 2, b.top, b.w, b.h);
            ctx.fillStyle = 'rgba(0,0,0,.12)'; ctx.fillRect(b.x + b.w * 0.18, b.top, b.w * 0.32, b.h);
            ctx.fillStyle = 'rgba(230,220,190,.55)'; ctx.fillRect(b.x - b.w * 0.06, b.top, b.w * 0.12, b.h * 0.35);
            ctx.strokeStyle = 'rgba(90,60,30,.6)'; ctx.lineWidth = 1.5;
            ctx.beginPath(); ctx.rect(b.x - b.w / 2, b.top, b.w, b.h); ctx.stroke();
        }

        /* ================= things on the table ================= */
        function resetItem(it) {
            const p = plats[it.plat ?? 1];
            it.x = lerp(p.x0, p.x1, it.home); it.y = p.y; it.vx = 0; it.vy = 0; it.rot = 0; it.state = 'table'; it.alpha = 0; it.t = 0;
        }
        function updateItems(dt) {
            for (const it of items) {
                const p = plats[it.plat ?? 1];
                it.alpha = Math.min(1, it.alpha + dt);
                if (it.state === 'table') {
                    if (it.x < p.x0 || it.x > p.x1) { it.state = 'fall'; it.vx = (it.x < p.x0 ? -1 : 1) * 60 * sc; it.vy = -40 * sc; }
                } else if (it.state === 'fall') {
                    it.vy += G * dt; it.x += it.vx * dt; it.y += it.vy * dt; it.rot += (it.vx > 0 ? 1 : -1) * dt * 7;
                    const ground = surfaceBelow(it.x, it.y - it.vy * dt + 1);
                    if (it.y >= ground) { it.y = ground; it.state = 'floor'; it.rot = (it.vx > 0 ? 1 : -1) * Math.PI / 2; it.t = rand(18, 35); }
                } else if (it.state === 'floor') {
                    it.t -= dt;
                    if (it.t < 1) it.alpha = Math.max(0, it.t);
                    if (it.t <= 0) resetItem(it);
                }
            }
        }
        function drawItem(it) {
            if (it.alpha <= 0.02) return;
            const u = H * 0.02;
            ctx.save(); ctx.globalAlpha = it.alpha; ctx.translate(it.x, it.y);
            if (it.state === 'floor' && it.type === 'mug') {
                ctx.fillStyle = 'rgba(120,80,40,.45)'; ctx.beginPath(); ctx.ellipse(it.rot > 0 ? u * 2.2 : -u * 2.2, -1, u * 1.6, u * 0.3, 0, 0, TAU); ctx.fill();
            }
            ctx.rotate(it.rot);
            if (it.type === 'mug') {
                ctx.fillStyle = it.col; ctx.fillRect(-u * 0.8, -u * 2, u * 1.6, u * 2);
                ctx.strokeStyle = it.col; ctx.lineWidth = u * 0.35; ctx.beginPath(); ctx.arc(u * 0.95, -u * 1.05, u * 0.5, -1.4, 1.4); ctx.stroke();
                ctx.fillStyle = 'rgba(255,255,255,.25)'; ctx.fillRect(-u * 0.6, -u * 1.9, u * 0.3, u * 1.7);
            } else {
                ctx.fillStyle = '#b8603a';
                ctx.beginPath(); ctx.moveTo(-u, -u * 1.6); ctx.lineTo(u, -u * 1.6); ctx.lineTo(u * 0.75, 0); ctx.lineTo(-u * 0.75, 0); ctx.closePath(); ctx.fill();
                ctx.fillStyle = '#4f9a48';
                for (const [lx, ly, a] of [[-u * 0.6, -u * 2.6, -0.5], [u * 0.6, -u * 2.7, 0.5], [0, -u * 3.1, 0], [-u * 0.2, -u * 2.2, -0.2]]) { ctx.beginPath(); ctx.ellipse(lx, ly, u * 0.35, u * 0.95, a, 0, TAU); ctx.fill(); }
            }
            ctx.restore();
        }

        /* ================= wool ================= */
        function surfaceBelow(x, yTop) {
            let best = fy;
            for (let i = 1; i < plats.length; i++) {
                const p = plats[i];
                if (x >= p.x0 && x <= p.x1 && p.y >= yTop - 1 && p.y < best) best = p.y;
            }
            return best;
        }
        function updateBalls(dt) {
            for (const b of balls) {
                if (b === held) {
                    const px = ptr.x, py = Math.min(ptr.y, fy - b.r);
                    b.vx = lerp(b.vx, (px - b.x) / Math.max(dt, 0.001), 0.5);
                    b.vy = lerp(b.vy, (py - b.y) / Math.max(dt, 0.001), 0.5);
                    b.x = px; b.y = py; b.wob *= Math.exp(-dt * 4);
                } else {
                    const ground = surfaceBelow(b.x, b.y + b.r) - b.r;
                    if (b.y < ground - 0.5 || b.vy < 0) {
                        b.vy += G * dt;
                        b.y += b.vy * dt; b.x += b.vx * dt;
                        if (b.y >= ground) { b.y = ground; b.vy = Math.abs(b.vy) > 200 * sc ? -b.vy * 0.35 : 0; b.vx *= 0.8; }
                    } else {
                        b.y = ground; b.vy = 0;
                        b.x += b.vx * dt; b.vx *= Math.exp(-dt * 1.1);
                    }
                    b.wob = 0;
                }
                if (b.x < b.r) { b.x = b.r; b.vx = Math.abs(b.vx) * 0.6; }
                if (b.x > W - b.r) { b.x = W - b.r; b.vx = -Math.abs(b.vx) * 0.6; }
                b.rot += b.vx * dt / b.r;
                // the loose strand: one free end on a rope
                const t = b.tail, ax = b.x, ay = b.y + b.r * 0.6, L = b.r * 5;
                t.vy += G * dt; t.vx *= Math.exp(-dt * 3); t.vy *= Math.exp(-dt * 1.5);
                t.x += t.vx * dt; t.y += t.vy * dt;
                const fl = surfaceBelow(t.x, t.y) - 1;
                if (t.y > fl) { t.y = fl; t.vy = 0; t.vx *= Math.exp(-dt * 6); }
                const dx = t.x - ax, dy = t.y - ay, d = Math.hypot(dx, dy) || 1;
                if (d > L) { t.x = ax + dx / d * L; t.y = ay + dy / d * L; t.vx += (ax - t.x) * 0.5; t.vy += (ay - t.y) * 0.5; }
            }
        }
        function drawBall(b) {
            const t = b.tail, ax = b.x, ay = b.y + b.r * 0.6, L = b.r * 5;
            const slack = Math.max(0, L - Math.hypot(t.x - ax, t.y - ay));
            const sy = Math.min(Math.max(ay, t.y) + slack * 0.6, surfaceBelow((ax + t.x) / 2, Math.min(ay, t.y)) - 1);
            ctx.strokeStyle = b.col; ctx.lineWidth = Math.max(1, b.r * 0.12); ctx.lineCap = 'round';
            ctx.beginPath(); ctx.moveTo(ax, ay);
            ctx.bezierCurveTo(ax, sy, t.x, sy, t.x, t.y);
            ctx.stroke();
            const ground = surfaceBelow(b.x, b.y + b.r);
            const sh = Math.max(0.15, 1 - (ground - b.y - b.r) / (H * 0.4));
            ctx.fillStyle = `rgba(0,0,0,${(0.2 * sh).toFixed(2)})`; ctx.beginPath(); ctx.ellipse(b.x, ground, b.r * sh, b.r * 0.22 * sh, 0, 0, TAU); ctx.fill();
            const wx = b.x + Math.sin(now * 30) * b.wob;
            ctx.fillStyle = b.col; dot(wx, b.y, b.r);
            ctx.save(); ctx.beginPath(); ctx.arc(wx, b.y, b.r, 0, TAU); ctx.clip();
            ctx.strokeStyle = b.dark; ctx.lineWidth = Math.max(1, b.r * 0.09);
            for (let i = 0; i < 4; i++) {
                ctx.save(); ctx.translate(wx, b.y); ctx.rotate(b.rot + i * 0.8);
                ctx.beginPath(); ctx.ellipse(0, 0, b.r * 0.92, b.r * 0.36, 0, 0, TAU); ctx.stroke();
                ctx.restore();
            }
            ctx.restore();
            ctx.fillStyle = 'rgba(255,255,255,.18)'; dot(wx - b.r * 0.35, b.y - b.r * 0.35, b.r * 0.3);
        }
        const ballActive = b => b === held || b.y < surfaceBelow(b.x, b.y + b.r) - b.r - 2 || Math.abs(b.vy) > 1;

        /* ================= cat drawing: a simple skeleton ================= */
        // Facing +x. Rig points are relative to the feet position, in units of s.
        function ik(rx, ry, tx, ty, a, b, bend) {
            let dx = tx - rx, dy = ty - ry, d = Math.hypot(dx, dy);
            const dd = clamp(d, Math.abs(a - b) + 0.01, a + b - 0.01);
            const base = Math.atan2(dy, dx);
            const al = Math.acos(clamp((a * a + dd * dd - b * b) / (2 * a * dd), -1, 1));
            return [rx + Math.cos(base + bend * al) * a, ry + Math.sin(base + bend * al) * a, rx + Math.cos(base) * dd, ry + Math.sin(base) * dd];
        }
        function seg(x0, y0, x1, y1, w, col) {
            ctx.strokeStyle = col; ctx.lineWidth = w; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
        }
        function hindLeg(k, r, s, foot, far) {
            if (!foot) return;
            const c = k.coat, col = far ? c.under : (c.pattern === 'siamese' ? c.base : c.base);
            const [hx, hy] = r.hip;
            const hock = foot.hock || [foot.p[0] - 0.07 * s, foot.p[1] - 0.14 * s];
            const [kx, ky, ex, ey] = ik(hx, hy, hock[0], hock[1], 0.27 * s, 0.25 * s, -1);
            const fold = r.fold || 0;
            ctx.fillStyle = far ? c.under : c.base;
            const ang = Math.atan2(ky - hy, kx - hx);
            ctx.beginPath(); ctx.ellipse((hx + kx) / 2, (hy + ky) / 2, 0.2 * s, (0.12 + fold * 0.05) * s, ang, 0, TAU); ctx.fill();
            const low = c.pattern === 'siamese' ? c.dark : (c.pattern === 'tuxedo' || c.pattern === 'cow') && !far ? c.light : col;
            seg(kx, ky, ex, ey, 0.085 * s, far ? c.under : c.base);
            seg(ex, ey, foot.p[0], foot.p[1] - 0.02 * s, 0.065 * s, far ? (c.pattern === 'siamese' ? c.dark : c.under) : low);
            ctx.fillStyle = far ? (c.pattern === 'siamese' ? c.dark : c.under) : low;
            ctx.beginPath(); ctx.ellipse(foot.p[0] + 0.03 * s, foot.p[1] - 0.025 * s, 0.055 * s, 0.03 * s, 0, 0, TAU); ctx.fill();
        }
        function foreLeg(k, r, s, foot, far) {
            if (!foot) return;
            const c = k.coat;
            const [sx, sy] = r.sh;
            const [ex, ey, px, py] = ik(sx, sy + 0.04 * s, foot.p[0], foot.p[1] - 0.02 * s, 0.24 * s, 0.3 * s, 1);
            const col = far ? c.under : c.base;
            const low = c.pattern === 'siamese' ? c.dark : (c.pattern === 'tuxedo' || c.pattern === 'cow') && !far ? c.light : col;
            seg(sx, sy + 0.04 * s, ex, ey, 0.105 * s, col);
            seg(ex, ey, px, py, 0.07 * s, far && c.pattern !== 'siamese' ? col : low);
            ctx.fillStyle = far && c.pattern !== 'siamese' ? col : low;
            ctx.beginPath(); ctx.ellipse(px + 0.02 * s, py, 0.05 * s, 0.03 * s, 0, 0, TAU); ctx.fill();
        }
        function tail(k, r, s) {
            const c = k.coat, tl = r.tail;
            const n = 16, segL = 0.05 * s * (tl.len || 1);
            let x = r.hip[0] - 0.2 * s, y = r.hip[1] - 0.04 * s, a = tl.a0;
            const puff = tl.puff || 1;
            for (let i = 0; i < n; i++) {
                const f = i / (n - 1);
                a += tl.curl * (1 + f * (tl.tip || 0)) + Math.sin(now * (tl.speed || 1.6) - i * 0.4 + k.ph) * (tl.sway || 0.05) * f;
                x += Math.cos(a) * segL; y += Math.sin(a) * segL;
                if (!tl.hang) y = Math.min(y, -0.035 * s);
                const rr = (0.055 - 0.022 * f) * s * puff;
                ctx.fillStyle = c.pattern === 'siamese' ? (f > 0.2 ? c.dark : c.base)
                    : c.pattern === 'tabby' && i % 3 === 0 && f > 0.15 ? c.dark
                    : (c.pattern === 'tuxedo' || c.pattern === 'cow') && f > 0.85 ? c.light : c.base;
                dot(x, y, rr);
            }
        }
        function bodyPath(r, s) {
            const [hx, hy] = r.hip, [sx, sy] = r.sh;
            const ang = Math.atan2(sy - hy, sx - hx), len = Math.hypot(sx - hx, sy - hy);
            const arch = (r.arch || 0) * 0.16 * s;
            const mx = (hx + sx) / 2 + Math.sin(ang) * arch, my = (hy + sy) / 2 - Math.cos(ang) * arch;
            ctx.beginPath();
            ctx.ellipse(hx, hy, 0.24 * s, 0.21 * s, ang, 0, TAU);
            ctx.ellipse(sx, sy + 0.01 * s, 0.22 * s, 0.2 * s, ang, 0, TAU);
            ctx.ellipse(mx, my, len / 2 + 0.06 * s, 0.17 * s + arch * 0.3, ang, 0, TAU);
        }
        function body(k, r, s) {
            const c = k.coat;
            const top = Math.min(r.hip[1], r.sh[1]) - 0.24 * s, bot = Math.max(r.hip[1], r.sh[1]) + 0.22 * s;
            const g = ctx.createLinearGradient(0, top, 0, bot);
            g.addColorStop(0, c.top); g.addColorStop(0.55, c.base); g.addColorStop(1, c.under);
            ctx.fillStyle = g; bodyPath(r, s); ctx.fill();
            if (c.pattern === 'solid') return;
            ctx.save(); bodyPath(r, s); ctx.clip();
            const [hx, hy] = r.hip, [sx, sy] = r.sh;
            if (c.pattern === 'tabby') {
                ctx.strokeStyle = c.dark; ctx.lineWidth = 0.045 * s; ctx.beginPath();
                for (let i = 0; i <= 6; i++) {
                    const f = i / 6, x = lerp(hx - 0.15 * s, sx + 0.1 * s, f), y = lerp(hy, sy, f);
                    ctx.moveTo(x, y - 0.25 * s); ctx.lineTo(x + 0.04 * s, y - 0.05 * s); ctx.lineTo(x - 0.01 * s, y + 0.08 * s);
                }
                ctx.stroke();
            } else if (c.pattern === 'calico') {
                ctx.fillStyle = '#d9823a'; dot(hx + 0.05 * s, hy - 0.08 * s, 0.2 * s);
                ctx.fillStyle = c.dark; dot(lerp(hx, sx, 0.6), lerp(hy, sy, 0.6) - 0.12 * s, 0.15 * s);
            } else if (c.pattern === 'cow') {
                ctx.fillStyle = c.dark; dot(hx, hy - 0.1 * s, 0.17 * s); dot(lerp(hx, sx, 0.65), lerp(hy, sy, 0.65) - 0.14 * s, 0.12 * s);
            } else if (c.pattern === 'spots') {
                ctx.fillStyle = c.dark;
                for (let i = 0; i < 9; i++) { const f = (i * 0.37) % 1; dot(lerp(hx - 0.1 * s, sx, f), lerp(hy, sy, f) - 0.15 * s + ((i * 0.53) % 1) * 0.22 * s, 0.035 * s); }
            } else if (c.pattern === 'tuxedo') {
                ctx.fillStyle = c.light; ctx.beginPath(); ctx.ellipse(sx + 0.05 * s, sy + 0.12 * s, 0.17 * s, 0.16 * s, 0, 0, TAU); ctx.fill();
                ctx.beginPath(); ctx.ellipse(lerp(hx, sx, 0.5), Math.max(hy, sy) + 0.16 * s, 0.25 * s, 0.07 * s, Math.atan2(sy - hy, sx - hx), 0, TAU); ctx.fill();
            } else if (c.pattern === 'siamese') {
                ctx.fillStyle = 'rgba(78,58,44,.18)'; dot(hx - 0.05 * s, hy, 0.22 * s);
            }
            ctx.restore();
        }
        function head(k, r, s) {
            const c = k.coat, R = 0.17 * s, [hx, hy] = r.head;
            const [sx, sy] = r.sh;
            // neck
            ctx.fillStyle = c.base;
            const na = Math.atan2(hy - sy, hx - sx), nl = Math.hypot(hx - sx, hy - sy);
            ctx.beginPath(); ctx.ellipse((hx + sx) / 2, (hy + sy) / 2, nl / 2 + 0.03 * s, 0.13 * s, na, 0, TAU); ctx.fill();
            if (c.pattern === 'tuxedo' || c.pattern === 'cow') { ctx.fillStyle = c.light; ctx.beginPath(); ctx.ellipse(hx - 0.02 * s, hy + 0.12 * s, 0.1 * s, 0.08 * s, 0, 0, TAU); ctx.fill(); }
            ctx.save(); ctx.translate(hx, hy); ctx.rotate(r.tilt || 0);
            const earC = c.pattern === 'siamese' ? c.dark : c.base;
            const earFar = c.pattern === 'siamese' ? c.dark : c.under;
            const ears = r.ears ?? 0;   // 0 normal, 1 flat (playful)
            ctx.fillStyle = earFar;
            ctx.beginPath(); ctx.moveTo(-R * 0.6, -R * 0.55); ctx.lineTo(-R * (0.5 + ears * 0.4), -R * (1.35 - ears * 0.5)); ctx.lineTo(-R * 0.1, -R * 0.8); ctx.closePath(); ctx.fill();
            ctx.fillStyle = c.pattern === 'cow' ? c.dark : c.base;
            ctx.beginPath(); ctx.ellipse(0, 0, R * 1.05, R * 0.92, 0, 0, TAU); ctx.fill();
            ctx.beginPath(); ctx.ellipse(-R * 0.15, R * 0.35, R * 0.8, R * 0.52, 0, 0, TAU); ctx.fill();
            ctx.fillStyle = earC;
            ctx.beginPath(); ctx.moveTo(R * 0.0, -R * 0.82); ctx.lineTo(R * (0.3 - ears * 0.2), -R * (1.45 - ears * 0.55)); ctx.lineTo(R * 0.68, -R * 0.52); ctx.closePath(); ctx.fill();
            ctx.fillStyle = 'rgba(232,150,160,.8)';
            ctx.beginPath(); ctx.moveTo(R * 0.14, -R * 0.82); ctx.lineTo(R * (0.32 - ears * 0.2), -R * (1.25 - ears * 0.45)); ctx.lineTo(R * 0.52, -R * 0.6); ctx.closePath(); ctx.fill();
            if (c.pattern === 'tabby') {
                ctx.strokeStyle = c.dark; ctx.lineWidth = R * 0.11; ctx.beginPath();
                ctx.moveTo(-R * 0.3, -R * 0.85); ctx.lineTo(-R * 0.15, -R * 0.45); ctx.moveTo(R * 0.05, -R * 0.9); ctx.lineTo(R * 0.12, -R * 0.5);
                ctx.moveTo(-R * 0.75, R * 0.15); ctx.lineTo(-R * 0.25, R * 0.25);
                ctx.stroke();
            } else if (c.pattern === 'calico') {
                ctx.fillStyle = '#d9823a'; dot(-R * 0.4, -R * 0.4, R * 0.5);
            } else if (c.pattern === 'siamese') {
                ctx.fillStyle = c.dark; ctx.beginPath(); ctx.ellipse(R * 0.45, R * 0.18, R * 0.62, R * 0.55, 0, 0, TAU); ctx.fill();
            } else if (c.pattern === 'spots') {
                ctx.fillStyle = c.dark; dot(-R * 0.3, -R * 0.4, R * 0.1); dot(0, -R * 0.55, R * 0.09); dot(-R * 0.5, 0, R * 0.08);
            }
            // muzzle
            const mz = (c.pattern === 'tuxedo' || c.pattern === 'calico' || c.pattern === 'tabby' || c.pattern === 'cow') ? c.light : (c.pattern === 'siamese' ? c.dark : c.base);
            ctx.fillStyle = mz; ctx.beginPath(); ctx.ellipse(R * 0.72, R * 0.33, R * 0.42, R * 0.3, 0.1, 0, TAU); ctx.fill();
            // eye
            const ex = R * 0.42, ey = -R * 0.08;
            if (r.eyes === 'closed') {
                ctx.strokeStyle = '#1a1a1a'; ctx.lineWidth = Math.max(1, R * 0.07);
                ctx.beginPath(); ctx.arc(ex, ey - R * 0.05, R * 0.16, 0.35, Math.PI - 0.35); ctx.stroke();
            } else {
                ctx.fillStyle = c.eye; ctx.beginPath(); ctx.ellipse(ex, ey, R * 0.17, R * 0.13, -0.12, 0, TAU); ctx.fill();
                const pw = r.eyes === 'wide' ? 0.11 : 0.035;
                ctx.fillStyle = '#0d0d0d'; ctx.beginPath(); ctx.ellipse(ex + R * 0.05 + (r.look || 0) * R * 0.05, ey, R * pw, R * 0.12, 0, 0, TAU); ctx.fill();
                ctx.fillStyle = 'rgba(255,255,255,.85)'; dot(ex - R * 0.03, ey - R * 0.05, R * 0.035);
                ctx.strokeStyle = 'rgba(0,0,0,.45)'; ctx.lineWidth = Math.max(0.8, R * 0.05);
                ctx.beginPath(); ctx.ellipse(ex, ey, R * 0.17, R * 0.13, -0.12, Math.PI * 1.05, Math.PI * 1.95); ctx.stroke();
            }
            ctx.fillStyle = c.pattern === 'solid' && c.base < '#40' ? '#4a3a3a' : '#d97a86';
            ctx.beginPath(); ctx.moveTo(R * 1.02, R * 0.1); ctx.lineTo(R * 1.14, R * 0.12); ctx.lineTo(R * 1.08, R * 0.22); ctx.closePath(); ctx.fill();
            if (r.mouth > 0) {
                ctx.fillStyle = '#7a2a34'; ctx.beginPath(); ctx.ellipse(R * 0.85, R * 0.45, R * 0.22, R * 0.2 * r.mouth, 0.2, 0, TAU); ctx.fill();
                ctx.fillStyle = '#e88a98'; ctx.beginPath(); ctx.ellipse(R * 0.82, R * 0.55, R * 0.14, R * 0.08 * r.mouth, 0.2, 0, TAU); ctx.fill();
            } else {
                ctx.strokeStyle = 'rgba(40,20,20,.5)'; ctx.lineWidth = Math.max(0.7, R * 0.04);
                ctx.beginPath(); ctx.moveTo(R * 1.06, R * 0.22); ctx.lineTo(R * 1.0, R * 0.4); ctx.lineTo(R * 0.86, R * 0.44); ctx.stroke();
            }
            ctx.strokeStyle = 'rgba(245,245,245,.7)'; ctx.lineWidth = 0.7; ctx.beginPath();
            for (const a of [-0.2, 0.02, 0.22]) { ctx.moveTo(R * 0.85, R * 0.32); ctx.lineTo(R * 0.85 + Math.cos(a) * R * 1.2, R * 0.32 + Math.sin(a) * R * 1.2); }
            ctx.stroke();
            ctx.restore();
        }
        function drawRig(k, r) {
            const s = k.s;
            ctx.lineCap = 'round'; ctx.lineJoin = 'round';
            if (r.rot) { ctx.translate(r.pivot[0], r.pivot[1]); ctx.rotate(r.rot); ctx.translate(-r.pivot[0], -r.pivot[1]); }
            hindLeg(k, r, s, r.feet.lh, true);
            foreLeg(k, r, s, r.feet.lf, true);
            if (!r.tailFront) tail(k, r, s);
            body(k, r, s);
            hindLeg(k, r, s, r.feet.rh, false);
            foreLeg(k, r, s, r.feet.rf, false);
            head(k, r, s);
            if (r.tailFront) tail(k, r, s);
        }

        /* ================= poses ================= */
        function gaitFeet(k, s, stride, lift, run, hip, sh) {
            const offs = run ? {lh: 0, rh: 0.1, lf: 0.5, rf: 0.6} : {lh: 0, lf: 0.3, rh: 0.5, rf: 0.8};
            const out = {};
            for (const leg of ['lh', 'rh', 'lf', 'rf']) {
                const bx = leg[1] === 'h' ? hip + 0.02 * s : sh + 0.04 * s;
                const u = ((k.ph / TAU + offs[leg]) % 1 + 1) % 1;
                let x, y;
                if (u < 0.6) { x = bx + stride * (0.5 - u / 0.6); y = 0; } else { const v = (u - 0.6) / 0.4; x = bx + stride * (-0.5 + v); y = -lift * Math.sin(v * Math.PI); }
                out[leg] = {p: [x + (leg[0] === 'l' ? 0.03 * s : 0), y]};
            }
            return out;
        }
        function stand(s, hipX = -0.3, shX = 0.28) {
            return {lh: {p: [hipX * s + 0.05 * s, 0]}, rh: {p: [hipX * s, 0]}, lf: {p: [shX * s + 0.08 * s, 0]}, rf: {p: [shX * s + 0.03 * s, 0]}};
        }
        function lookAt(k, hx, hy, base) {
            let target = null;
            if (k.watch) target = k.watch;
            else if (ptr && Math.hypot(ptr.x - k.x, ptr.y - k.y) < W * 0.35) target = ptr;
            if (!target) return base;
            const dx = (target.x - (k.x + hx * k.dir)) * k.dir, dy = target.y - (k.y + hy);
            if (dx < -k.s * 0.3) return base;
            return clamp(Math.atan2(dy, Math.max(dx, k.s * 0.3)) * 0.8, -0.9, 0.6);
        }
        function rigFor(k) {
            const r = rigBase(k);
            if (k.headOv) { r.head = k.headOv; r.tilt = k.tiltOv; r.eyes = 'closed'; r.ears = 0; }
            if (k.blinkT > 0 && (k.blinkT % 1.2) > 0.35 && (k.blinkT % 1.2) < 0.9) r.eyes = 'closed';
            if (k.chatter) { r.mouth = 0.25 + 0.25 * Math.sin(now * 30); r.eyes = 'wide'; }
            if (k.kickT > 0) r.eyes = 'wide';
            return r;
        }
        function rigBase(k) {
            const s = k.s, st = k.state, pose = k.pose;
            const breath = Math.sin(now * 2.2 + k.ph) * 0.012 * s;
            const tailWalk = {a0: -2.35, curl: 0.03, tip: 4, sway: 0.08, speed: 2};
            if (st === 'air') {
                const j = k.j;
                if (j.leap) {
                    const up = 1 - Math.abs(j.f - 0.5) * 2;
                    return {hip: [-0.18 * s, -0.42 * s], sh: [0.28 * s, -0.75 * s], head: [0.45 * s, -0.98 * s], tilt: -0.5, eyes: 'wide', ears: 0.5,
                        feet: {lh: {p: [-0.35 * s, -0.05 * s]}, rh: {p: [-0.3 * s, 0]}, lf: {p: [0.55 * s, -1.05 * s - up * 0.1 * s]}, rf: {p: [0.48 * s, -1.15 * s]}},
                        tail: {a0: 2.5, curl: -0.04, sway: 0.1}, rot: 0, pivot: [0, -0.4 * s]};
                }
                return {hip: [-0.38 * s, -0.5 * s], sh: [0.36 * s, -0.55 * s], head: [0.58 * s, -0.66 * s], tilt: 0.1, eyes: 'wide',
                    feet: {lh: {p: [-0.82 * s, -0.42 * s]}, rh: {p: [-0.78 * s, -0.36 * s]}, lf: {p: [0.82 * s, -0.5 * s]}, rf: {p: [0.78 * s, -0.42 * s]}},
                    tail: {a0: Math.PI + 0.15, curl: -0.01, sway: 0.03}, rot: j.pitch || 0, pivot: [0, -0.5 * s]};
            }
            if (st === 'walk' || st === 'move') {
                const run = k.running, stride = (run ? 0.75 : 0.36) * s, lift = (run ? 0.16 : 0.08) * s;
                const flex = run ? Math.sin(k.ph) * 0.09 * s : 0, bob = (run ? Math.abs(Math.sin(k.ph)) * 0.06 : Math.abs(Math.sin(k.ph * 2)) * 0.012) * s;
                const hip = -0.3 * s + flex, sh = 0.28 * s - flex;
                const low = k.stalk ? 0.18 * s : 0;
                return {hip: [hip, -0.5 * s - bob + low], sh: [sh, -0.53 * s - bob + low * 1.2], head: [0.52 * s, -0.72 * s - bob + low * 1.6], tilt: k.stalk ? 0.15 : 0.08,
                    eyes: k.stalk || run ? 'wide' : 'open', ears: k.stalk ? 0.4 : 0,
                    feet: gaitFeet(k, s, stride, lift, run, hip, sh),
                    tail: k.stalk ? {a0: Math.PI, curl: 0.0, tip: 0, sway: 0.06, speed: 6} : run ? {a0: Math.PI + 0.3, curl: -0.01, sway: 0.05} : tailWalk};
            }
            if (st === 'crouch') {
                const wig = Math.sin(now * 26) * 0.025 * s * (k.t < 0.3 ? 1 : 0.4);
                return {hip: [-0.3 * s + wig, -0.36 * s], sh: [0.25 * s, -0.27 * s], head: [0.5 * s, -0.38 * s], tilt: 0.1, eyes: 'wide', ears: 0.4,
                    feet: {lh: {p: [-0.22 * s, 0], hock: [-0.36 * s, -0.04 * s]}, rh: {p: [-0.26 * s, 0], hock: [-0.4 * s, -0.04 * s]}, lf: {p: [0.42 * s, 0]}, rf: {p: [0.36 * s, 0]}},
                    tail: {a0: Math.PI, curl: 0.01, tip: 0, sway: 0.12, speed: 9}, fold: 0.6};
            }
            const sitRig = (extra = {}) => Object.assign({hip: [-0.12 * s, -0.22 * s], sh: [0.1 * s, -0.6 * s + breath], head: [0.2 * s, -0.86 * s + breath], tilt: 0, eyes: 'open',
                feet: {lh: {p: [0.06 * s, 0], hock: [-0.2 * s, -0.03 * s]}, rh: {p: [0.02 * s, 0], hock: [-0.24 * s, -0.03 * s]}, lf: {p: [0.2 * s, 0]}, rf: {p: [0.15 * s, 0]}},
                tail: {a0: Math.PI * 0.78, curl: -0.13, tip: 0.3, sway: 0.05, speed: 1.2}, fold: 1, tailFront: true}, extra);
            switch (pose) {
            case 'sit': {
                const r = sitRig();
                r.tilt = lookAt(k, 0.2 * s, -0.86 * s, Math.sin(now * 0.6 + k.ph) * 0.06);
                r.look = 1;
                if (k.watch) r.eyes = 'wide';
                return r;
            }
            case 'window': {
                const r = sitRig({tail: {a0: Math.PI * 0.55, curl: 0.0, sway: 0.15, speed: 1.5, hang: true}, tailFront: false});
                r.tilt = -0.25 + Math.sin(now * 0.8 + k.ph) * 0.15;
                return r;
            }
            case 'groom': {
                const lick = (Math.sin(now * 7) + 1) / 2;
                return sitRig({head: [0.18 * s, -0.82 * s], tilt: 0.45 + lick * 0.15, eyes: 'closed',
                    feet: {lh: {p: [0.06 * s, 0], hock: [-0.2 * s, -0.03 * s]}, rh: {p: [0.02 * s, 0], hock: [-0.24 * s, -0.03 * s]}, lf: {p: [0.2 * s, 0]}, rf: {p: [0.32 * s, -0.66 * s - lick * 0.05 * s]}}});
            }
            case 'earscratch': {
                const sc2 = Math.sin(now * 22) * 0.03 * s;
                return sitRig({head: [0.16 * s, -0.84 * s], tilt: 0.5, eyes: 'closed',
                    feet: {lh: {p: [0.06 * s, 0], hock: [-0.2 * s, -0.03 * s]}, rh: {p: [0.02 * s + sc2, -0.78 * s + sc2], hock: [-0.05 * s, -0.55 * s]}, lf: {p: [0.2 * s, 0]}, rf: {p: [0.15 * s, 0]}}});
            }
            case 'yawn':
                return sitRig({head: [0.18 * s, -0.88 * s], tilt: -0.55, eyes: 'closed', mouth: Math.min(1, Math.sin(Math.min(1, (k.dur - k.t) / k.dur) * Math.PI) * 1.4)});
            case 'loaf':
                return {hip: [-0.26 * s, -0.2 * s], sh: [0.16 * s, -0.22 * s + breath], head: [0.36 * s, -0.44 * s + breath], tilt: lookAt(k, 0.36 * s, -0.44 * s, 0.05), eyes: (now + k.ph) % 7 < 0.2 ? 'closed' : 'open', look: 1,
                    feet: {lh: null, rh: null, lf: null, rf: {p: [0.36 * s, 0]}}, tail: {a0: Math.PI * 0.9, curl: -0.13, sway: 0.03, speed: 1}, fold: 1, tailFront: true};
            case 'sleep':
                return {hip: [-0.2 * s, -0.19 * s], sh: [0.14 * s, -0.19 * s + breath], head: [0.3 * s, -0.22 * s], tilt: 0.75, eyes: 'closed',
                    feet: {lh: null, rh: null, lf: null, rf: null}, tail: {a0: Math.PI * 0.85, curl: -0.19, sway: 0.01, speed: 0.5}, fold: 1, tailFront: true};
            case 'stretch':
                return {hip: [-0.3 * s, -0.56 * s], sh: [0.25 * s, -0.26 * s], head: [0.5 * s, -0.36 * s], tilt: 0.25, eyes: 'closed',
                    feet: {lh: {p: [-0.25 * s, 0]}, rh: {p: [-0.3 * s, 0]}, lf: {p: [0.68 * s, 0]}, rf: {p: [0.6 * s, 0]}}, tail: {a0: -2.0, curl: 0.04, tip: 3, sway: 0.05}};
            case 'eat': {
                const bob = Math.sin(now * 5) * 0.015 * s;
                return {hip: [-0.3 * s, -0.48 * s], sh: [0.22 * s, -0.4 * s], head: [0.48 * s, -0.2 * s + bob], tilt: 0.7, eyes: 'closed',
                    feet: stand(s, -0.3, 0.26), tail: {a0: Math.PI * 0.95, curl: -0.05, tip: 3, sway: 0.06}};
            }
            case 'knead': {
                const a = Math.max(0, Math.sin(now * 6)) * 0.07 * s, b = Math.max(0, -Math.sin(now * 6)) * 0.07 * s;
                return {hip: [-0.3 * s, -0.48 * s], sh: [0.22 * s, -0.42 * s], head: [0.44 * s, -0.6 * s], tilt: 0.1, eyes: 'closed',
                    feet: {lh: {p: [-0.25 * s, 0]}, rh: {p: [-0.3 * s, 0]}, lf: {p: [0.32 * s, -a]}, rf: {p: [0.26 * s, -b]}}, tail: {a0: -2.3, curl: 0.03, tip: 4, sway: 0.1}};
            }
            case 'belly': {
                const bat = Math.sin(now * 9 + k.ph) * 0.1 * s, kick = Math.sin(now * 13 + k.ph) * 0.09 * s;
                return {hip: [-0.3 * s, -0.17 * s], sh: [0.24 * s, -0.19 * s], head: [0.47 * s, -0.24 * s], tilt: -0.45, eyes: 'wide', ears: 0.6,
                    feet: {lh: {p: [-0.28 * s, -0.48 * s + kick], hock: [-0.38 * s, -0.36 * s + kick]}, rh: {p: [-0.16 * s, -0.5 * s - kick], hock: [-0.3 * s, -0.4 * s - kick]},
                        lf: {p: [0.28 * s, -0.58 * s + bat]}, rf: {p: [0.42 * s, -0.52 * s - bat]}}, tail: {a0: Math.PI, curl: 0.03, sway: 0.15, speed: 6}};
            }
            case 'rear': {
                const sw = Math.sin(now * 10 + k.ph);
                return {hip: [-0.06 * s, -0.4 * s], sh: [0.06 * s, -0.92 * s], head: [0.18 * s, -1.12 * s], tilt: lookAt(k, 0.18 * s, -1.12 * s, 0.1), eyes: 'wide', ears: 0.5,
                    feet: {lh: {p: [0.02 * s, 0], hock: [-0.16 * s, -0.03 * s]}, rh: {p: [-0.02 * s, 0], hock: [-0.2 * s, -0.03 * s]},
                        lf: {p: [0.32 * s, -0.86 * s - sw * 0.1 * s]}, rf: {p: [0.4 * s + sw * 0.08 * s, -1.0 * s + sw * 0.12 * s]}},
                    tail: {a0: Math.PI * 0.72, curl: -0.04, sway: 0.1, speed: 4}, fold: 0.6};
            }
            case 'scratch': {
                const st2 = Math.sin(now * 8);
                return {hip: [-0.12 * s, -0.42 * s], sh: [0.12 * s, -0.92 * s], head: [0.26 * s, -1.08 * s], tilt: 0.2, eyes: 'closed',
                    feet: {lh: {p: [-0.04 * s, 0]}, rh: {p: [-0.08 * s, 0]}, lf: {p: [0.42 * s, -0.95 * s + st2 * 0.12 * s]}, rf: {p: [0.42 * s, -1.0 * s - st2 * 0.12 * s]}},
                    tail: {a0: Math.PI * 0.75, curl: -0.03, sway: 0.08, speed: 3}, fold: 0.4};
            }
            case 'arch': {
                const hop = Math.abs(Math.sin(now * 7 + k.ph)) * 0.06 * s;
                return {hip: [-0.24 * s, -0.6 * s - hop], sh: [0.2 * s, -0.6 * s - hop], head: [0.42 * s, -0.62 * s - hop], tilt: 0.3, eyes: 'wide', ears: 0.8, arch: 1,
                    feet: {lh: {p: [-0.28 * s, -hop]}, rh: {p: [-0.24 * s, -hop]}, lf: {p: [0.24 * s, -hop]}, rf: {p: [0.2 * s, -hop]}},
                    tail: {a0: -1.8, curl: 0.02, tip: 1, sway: 0.03, puff: 1.7}};
            }
            case 'swat': {
                const ext = Math.max(0, Math.sin(now * 5 + k.ph));
                return sitRig({tilt: 0.25, eyes: 'open', feet: {lh: {p: [0.06 * s, 0], hock: [-0.2 * s, -0.03 * s]}, rh: {p: [0.02 * s, 0], hock: [-0.24 * s, -0.03 * s]},
                    lf: {p: [0.2 * s, 0]}, rf: {p: [0.32 * s + ext * 0.18 * s, -0.12 * s - ext * 0.06 * s]}}});
            }
            case 'boop':
                return {hip: [-0.3 * s, -0.5 * s], sh: [0.28 * s, -0.5 * s], head: [0.56 * s, -0.66 * s], tilt: 0.05, eyes: 'closed', feet: stand(s), tail: tailWalk};
            case 'lookup': {
                const r = sitRig({eyes: 'wide'});
                r.tilt = lookAt(k, 0.2 * s, -0.86 * s, -0.5);
                return r;
            }
            default:
                return {hip: [-0.3 * s, -0.5 * s], sh: [0.28 * s, -0.53 * s + breath], head: [0.52 * s, -0.74 * s], tilt: lookAt(k, 0.52 * s, -0.74 * s, 0.05), look: 1, eyes: 'open', feet: stand(s), tail: tailWalk};
            }
        }
        function drawCat(k) {
            const r = rigFor(k);
            if (k.state !== 'air') {
                ctx.fillStyle = 'rgba(0,0,0,.18)'; ctx.beginPath(); ctx.ellipse(k.x, k.y, k.s * 0.52, k.s * 0.07, 0, 0, TAU); ctx.fill();
            }
            ctx.save(); ctx.translate(k.x, k.y); ctx.scale(k.dir, 1);
            drawRig(k, r);
            if (k.carry) drawSock(r.head[0] + k.s * 0.2, r.head[1] + k.s * 0.18, k.s);
            ctx.restore();
        }
        function drawInBox(k) {
            const b = k.box, s = k.s;
            const sleepy = k.pose === 'sleep';
            const hy = b.top - s * 0.1 + (1 - k.peek) * s * (sleepy ? 0.28 : 0.36);
            ctx.save(); ctx.translate(b.x, 0); ctx.scale(k.dir, 1);
            if (k.peek > 0.7 && !sleepy && Math.sin(now * 4 + k.ph) > 0.6) {
                ctx.lineCap = 'round'; seg(s * 0.2, b.top + s * 0.05, s * 0.38, b.top - s * 0.1, s * 0.07, k.coat.base);
            }
            head(k, {head: [0, hy], sh: [-0.05 * s, hy + 0.2 * s], tilt: sleepy ? 0.5 : Math.sin(now * 1.3 + k.ph) * 0.15, eyes: sleepy ? 'closed' : 'wide'}, s);
            ctx.restore();
        }

        /* ================= behaviour ================= */
        function mkCat(i) {
            const coat = COATS[i % COATS.length];
            return {coat, s: H * 0.088 * rand(0.82, 1.1), x: rand(W * 0.1, W * 0.9), y: fy, dir: Math.random() < 0.5 ? 1 : -1,
                plat: 0, state: 'pose', pose: 'sit', t: rand(0.5, 3), dur: 1, ph: rand(0, 6), running: false, stalk: false,
                tx: 0, after: null, j: null, box: null, mate: null, sp: null, until: 0, peek: 1, peekT: 1, peekTarget: 1, cd: 0, watch: null, ballCd: rand(0, 3)};
        }
        function setPose(k, pose, dur, after) { k.state = 'pose'; k.pose = pose; k.t = dur; k.dur = dur; k.after = after || null; k.watch = null; }
        function idle(k) {
            k.mate = null; k.sp = null; k.watch = null; k.stalk = false;
            const r = Math.random();
            if (r < 0.16) setPose(k, 'sit', rand(2, 5));
            else if (r < 0.28) setPose(k, 'groom', rand(3, 6));
            else if (r < 0.33) setPose(k, 'earscratch', rand(0.8, 1.6));
            else if (r < 0.47) setPose(k, 'loaf', rand(4, 10));
            else if (r < 0.58) setPose(k, 'sleep', rand(10, 25), () => setPose(k, 'stretch', rand(1.2, 2), () => setPose(k, 'yawn', 1.2)));
            else if (r < 0.63) setPose(k, 'yawn', 1.2);
            else if (r < 0.68) setPose(k, 'stand', rand(1, 3));
            else {
                const p = plats[k.plat];
                walkTo(k, rand(p.x0, p.x1), false, () => idle(k));
            }
        }
        function walkTo(k, tx, run, after) {
            const p = plats[k.plat];
            k.tx = clamp(tx, p.x0 + k.s * 0.4, p.x1 - k.s * 0.4);
            k.running = run; k.state = 'walk'; k.after = after;
        }
        function crouchThen(k, dur, fn) { k.state = 'crouch'; k.t = dur; k.after = fn; }
        function jumpTo(k, tx, ty, plat, after, peakY) {
            const d = Math.hypot(tx - k.x, ty - k.y);
            const h = peakY !== undefined ? Math.max(k.s * 0.3, Math.max(k.y, ty) - peakY) : k.s * 0.6 + Math.max(0, k.y - ty) * 0.55;
            const T = peakY !== undefined ? clamp(Math.sqrt(8 * h / G), 0.35, 0.9) : clamp(d / (k.s * 6), 0.32, 0.75);
            k.j = {x0: k.x, y0: k.y, tx, ty, plat, t: 0, T, h, f: 0, leap: peakY !== undefined && Math.abs(tx - k.x) < k.s * 1.2};
            if (Math.abs(tx - k.x) > 2) k.dir = tx >= k.x ? 1 : -1;
            k.state = 'air'; k.after = after;
        }
        function jumpDown(k, then) {
            const p = plats[k.plat];
            const left = k.plat === 3 ? true : Math.random() < 0.5;
            const tx = clamp(left ? p.x0 - k.s * rand(0.8, 2) : p.x1 + k.s * rand(0.8, 2), k.s, W - k.s);
            crouchThen(k, 0.3, () => jumpTo(k, tx, fy, 0, then));
        }
        function decide(k) {
            k.mate = null; k.sp = null; k.watch = null; k.stalk = false;
            if (solo) return soloDecide(k);
            const r = Math.random();
            if (k.plat === 1) {                       // table
                if (r < 0.2 && items.some(it => it.state === 'table')) return knock(k);
                if (r < 0.35) return toSill(k);
                if (r < 0.65) return jumpDown(k, () => decide(k));
                return idle(k);
            }
            if (k.plat === 3) {                       // window sill
                if (r < 0.45) return setPose(k, 'window', rand(6, 15));
                if (r < 0.75) { const p = plats[1]; return crouchThen(k, 0.35, () => jumpTo(k, p.x0 + k.s * rand(0.6, 1.4), p.y, 1, () => idle(k))); }
                return jumpDown(k, () => decide(k));
            }
            if (k.plat !== 0) return r < 0.55 ? jumpDown(k, () => decide(k)) : idle(k);
            if (r < 0.14) return goYarn(k);
            if (r < 0.24) return goBox(k);
            if (r < 0.34) return goPlat(k, Math.random() < 0.7 ? 1 : 2);
            if (r < 0.44 && startPlay(k)) return;
            if (r < 0.5 && greet(k)) return;
            if (r < 0.55) return goBowl(k);
            if (r < 0.6) return goPost(k);
            if (r < 0.64) return goRug(k);
            if (r < 0.67) return zoomies(k);
            if (r < 0.71 && ptr) { k.state = 'mouse'; k.until = now + rand(4, 8); return; }
            idle(k);
        }
        function goYarn(k) {
            const opts = balls.filter(b => b !== held && b.y >= fy - b.r - 2);
            if (!opts.length) return idle(k);
            k.ball = opts[(Math.random() * opts.length) | 0];
            k.state = 'yarn'; k.until = now + rand(6, 12);
        }
        function goBox(k) {
            const free = boxes.filter(b => !b.occ && (!solo || !ptr || Math.abs(b.x - ptr.x) > k.s * 5));
            if (!free.length) return solo ? (k.state = 'hunt') : idle(k);
            const b = free[(Math.random() * free.length) | 0];
            const side = k.x < b.x ? -1 : 1;
            b.occ = k; k.res = b;
            walkTo(k, b.x + side * (b.w / 2 + k.s * 0.9), true, () => {
                k.dir = -side;
                crouchThen(k, 0.4, () => jumpTo(k, b.x, b.top, 0, () => {
                    k.state = 'inBox'; k.box = b; k.pose = !solo && Math.random() < 0.3 ? 'sleep' : 'peek'; k.ambush = solo; k.boxAge = 0;
                    k.t = k.pose === 'sleep' ? rand(10, 25) : solo ? rand(6, 14) : rand(3, 8); k.peek = 0; k.peekT = rand(0.4, 1.2);
                }));
            });
        }
        function leaveBox(k) {
            const b = k.box;
            k.box = null; b.occ = null; k.res = null;
            k.x = b.x; k.y = b.top;
            const prey = cats.find(o => o !== k && available(o) && Math.abs(o.x - b.x) < k.s * 4);
            if (prey && Math.random() < 0.7) {     // ambush!
                jumpTo(k, clamp(prey.x - Math.sign(prey.x - b.x || 1) * k.s * 0.6, k.s, W - k.s), fy, 0, () => startSpar(k, prey));
                return;
            }
            const side = Math.random() < 0.5 ? -1 : 1;
            jumpTo(k, clamp(b.x + side * (b.w / 2 + k.s * rand(0.8, 2)), k.s, W - k.s), fy, 0, () => idle(k));
        }
        function goPlat(k, pi) {
            const p = plats[pi];
            const fromLeft = k.x < (p.x0 + p.x1) / 2;
            const ax = fromLeft ? p.x0 - k.s * 1.3 : p.x1 + k.s * 1.3;
            const land = fromLeft ? p.x0 + k.s * rand(0.6, 1.4) : p.x1 - k.s * rand(0.6, 1.4);
            walkTo(k, ax, Math.random() < 0.6, () => {
                k.dir = fromLeft ? 1 : -1;
                setPose(k, 'lookup', rand(0.4, 1.2), () => crouchThen(k, 0.45, () => jumpTo(k, land, p.y, pi, () => idle(k))));
                k.watch = {x: land, y: p.y - k.s};
            });
        }
        function toSill(k) {
            const t = plats[1], sl = plats[3];
            walkTo(k, t.x0 + k.s * 0.5, false, () => {
                k.dir = -1;
                setPose(k, 'lookup', rand(0.5, 1.2), () => crouchThen(k, 0.45, () => jumpTo(k, sl.x1 - k.s * rand(0.6, 1.5), sl.y, 3, () => setPose(k, 'window', rand(6, 15)))));
                k.watch = {x: sl.x1 - k.s, y: sl.y - k.s};
            });
        }
        function knock(k, itArg) {
            const its = items.filter(it => it.state === 'table' && (it.plat ?? 1) === k.plat);
            const it = itArg || its[(Math.random() * its.length) | 0];
            if (!it) return idle(k);
            const t = plats[it.plat ?? 1];
            const outward = it.x - t.x0 < t.x1 - it.x ? -1 : 1;
            walkTo(k, it.x - outward * k.s * 0.55, false, () => {
                k.dir = outward;
                let swats = (rand(2, 5)) | 0;
                const swat = () => {
                    if (it.state !== 'table') { setPose(k, 'sit', rand(2, 4)); k.watch = solo && ptr ? ptr : {x: it.x, y: fy}; if (solo) k.blinkT = 2.2; return; }
                    if (Math.abs(it.x - k.x) > k.s * 0.8) { walkTo(k, it.x - outward * k.s * 0.55, false, swat); return; }
                    setPose(k, 'swat', 0.6, () => {
                        it.x += outward * k.s * rand(0.1, 0.25);
                        if (--swats > 0 || it.state === 'table') setPose(k, 'sit', rand(0.4, 1.2), swat); else swat();
                        k.watch = solo && ptr && Math.random() < 0.6 ? ptr : {x: it.x, y: it.y - k.s * 0.2};
                    });
                };
                setPose(k, 'sit', rand(0.8, 1.8), swat);
                k.watch = {x: it.x, y: it.y - k.s * 0.2};
            });
        }
        function goBowl(k) {
            const b = bowls[(Math.random() * bowls.length) | 0];
            if (b.occ) return idle(k);
            b.occ = k; k.res = b;
            const side = k.x < b.x ? -1 : 1;
            walkTo(k, b.x + side * k.s * 0.55, false, () => {
                k.dir = -side;
                setPose(k, 'eat', rand(4, 9), () => { b.occ = null; k.res = null; Math.random() < 0.5 ? setPose(k, 'groom', rand(3, 5)) : idle(k); });
            });
        }
        function goPost(k) {
            const side = k.x < post.x ? -1 : 1;
            walkTo(k, post.x + side * (post.w / 2 + k.s * 0.42), false, () => {
                k.dir = -side;
                setPose(k, 'scratch', rand(2, 4), () => setPose(k, 'stretch', 1.4, () => idle(k)));
            });
        }
        function goRug(k) {
            walkTo(k, rug.x + rand(-rug.w * 0.7, rug.w * 0.7), false, () => {
                if (Math.random() < 0.55) setPose(k, 'knead', rand(3, 6), () => setPose(k, 'loaf', rand(5, 12), () => setPose(k, 'sleep', rand(8, 20))));
                else setPose(k, 'belly', rand(2, 4), () => idle(k));
            });
        }
        function zoomies(k) {
            let legs = (rand(3, 6)) | 0;
            const leg = () => {
                if (legs-- <= 0) return setPose(k, 'groom', rand(2, 4));
                if (Math.random() < 0.25) return setPose(k, 'arch', rand(0.6, 1), leg);
                walkTo(k, k.x < W / 2 ? rand(W * 0.6, W * 0.95) : rand(W * 0.05, W * 0.4), true, leg);
            };
            leg();
        }
        function available(o) {
            return o.plat === 0 && o.state === 'pose' && ['sit', 'stand', 'loaf', 'groom'].includes(o.pose);
        }
        function startPlay(k) {
            const c = cats.filter(o => o !== k && available(o));
            if (!c.length) return false;
            const o = c[(Math.random() * c.length) | 0];
            if (Math.random() < 0.5) {
                k.state = 'chaseK'; o.state = 'fleeK'; k.mate = o; o.mate = k;
                k.until = o.until = now + rand(3, 6);
            } else {
                k.state = 'approach'; k.mate = o; k.until = now + 8;
                o.state = 'pose'; o.pose = 'stand'; o.t = 8; o.watch = k;
            }
            return true;
        }
        function greet(k) {
            const c = cats.filter(o => o !== k && available(o));
            if (!c.length) return false;
            const o = c[(Math.random() * c.length) | 0];
            k.state = 'greet'; k.mate = o; k.until = now + 10;
            o.state = 'pose'; o.pose = o.pose === 'loaf' ? 'loaf' : 'sit'; o.t = 10; o.watch = k;
            return true;
        }
        // Play-fighting: facing each other, rearing up and batting, pouncing, flopping on their backs.
        function startSpar(a, b) {
            const S = {a, b, t: rand(3, 7), done: false};
            for (const k of [a, b]) { k.state = 'spar'; k.sp = S; k.act = 'stand'; k.actT = rand(0.2, 0.6); k.mate = k === a ? b : a; k.watch = null; }
        }
        function endSpar(S) {
            S.done = true;
            const {a, b} = S;
            for (const k of [a, b]) k.sp = null;
            const r = Math.random();
            const free = k => k.state === 'spar';
            if (r < 0.4 && free(a) && free(b)) {
                const chaser = Math.random() < 0.5 ? a : b, fleer = chaser === a ? b : a;
                chaser.state = 'chaseK'; fleer.state = 'fleeK'; chaser.mate = fleer; fleer.mate = chaser;
                chaser.until = fleer.until = now + rand(2, 4);
            } else {
                for (const k of [a, b]) if (free(k)) Math.random() < 0.5 ? setPose(k, 'groom', rand(2, 4)) : idle(k);
            }
        }
        function sparUpdate(k, dt) {
            const S = k.sp, o = k.mate;
            if (!S || S.done || !o) return idle(k);
            if (S.a === k) { S.t -= dt; if (S.t <= 0) return endSpar(S); }
            if (o.state === 'air') { k.dir = Math.sign(o.x - k.x) || k.dir; return; }
            const D = (k.s + o.s) * 0.55, dist = Math.abs(o.x - k.x);
            k.dir = Math.sign(o.x - k.x) || k.dir;
            k.actT -= dt;
            if (k.actT <= 0) {
                const r = Math.random();
                if (k.act === 'pounced') { k.act = 'belly'; k.actT = rand(0.8, 1.4); } else if (r < 0.32) { k.act = 'rear'; k.actT = rand(0.7, 1.4); } else if (r < 0.5) { k.act = 'crouch'; k.actT = rand(0.4, 0.9); } else if (r < 0.66 && dist > D * 0.7) {
                    k.act = 'pounce'; o.act = 'pounced'; o.actT = 0.15;
                    const tx = clamp(o.x - k.dir * D * 0.55, k.s, W - k.s);
                    jumpTo(k, tx, fy, 0, () => { if (k.sp === S && !S.done) { k.state = 'spar'; k.act = 'rear'; k.actT = rand(0.5, 1); } else idle(k); }, fy - k.s * 0.5);
                    return;
                } else if (r < 0.78) { k.act = 'arch'; k.actT = rand(0.6, 1.1); } else if (r < 0.88) { k.act = 'belly'; k.actT = rand(0.8, 1.5); } else { k.act = 'stand'; k.actT = rand(0.3, 0.7); }
            }
            if (k.act === 'arch') {
                if (dist > D * 0.9) k.x = clamp(k.x + k.dir * k.s * 1.2 * dt, k.s, W - k.s);
            } else if (k.act !== 'belly' && k.act !== 'pounced') {
                if (dist > D * 1.6) { k.x += k.dir * k.s * 2 * dt; k.ph += dt * 10; }
                if (dist < D * 0.6) k.x -= k.dir * k.s * 1.5 * dt;
                k.x = clamp(k.x, k.s, W - k.s);
            }
        }
        function sparPose(k) {
            return {rear: 'rear', crouch: 'crouchP', arch: 'arch', belly: 'belly', pounced: 'belly', stand: 'stand'}[k.act] || 'stand';
        }
        function move(k, dir, speed, dt) {
            const p = plats[k.plat];
            k.dir = dir;
            k.x = clamp(k.x + dir * speed * dt, p.x0 + k.s * 0.4, p.x1 - k.s * 0.4);
            k.ph += dt * speed / (k.s * (k.running ? 0.55 : 0.5)) * Math.PI * 0.5;
        }
        function interruptible(k) {
            return k.plat === 0 && ((k.state === 'pose' && k.pose !== 'sleep' && k.pose !== 'boop') || k.state === 'yarn');
        }
        function update(k, dt) {
            const walk = k.s * 1.1, run = k.s * 4.4;
            k.cd -= dt; k.ballCd -= dt;
            if (solo && soloUpdate(k, dt)) return;
            // a ball in the air (or in your hand) gets everyone's attention
            const hot = balls.find(ballActive);
            if (!solo && hot && k.ballCd <= 0 && k.state !== 'ball' && interruptible(k) && Math.abs(hot.x - k.x) < W * 0.4 && Math.random() < dt * 1.2) {
                if (k.res) { k.res.occ = null; k.res = null; }
                k.state = 'ball'; k.ball = hot; k.until = now + rand(6, 12); k.watch = hot; k.after = null;
            }
            switch (k.state) {
            case 'pose':
                k.t -= dt;
                if (k.t <= 0) { const a = k.after; k.after = null; if (a) a(); else decide(k); }
                break;
            case 'walk': {
                const d = k.tx - k.x, sp = k.running ? run : walk;
                if (Math.abs(d) <= sp * dt) { k.x = k.tx; k.state = 'pose'; k.pose = 'stand'; k.t = 99; const a = k.after; k.after = null; a?.(); } else move(k, Math.sign(d), sp, dt);
                break;
            }
            case 'crouch':
                k.t -= dt;
                if (k.t <= 0) { const a = k.after; k.after = null; a?.(); }
                break;
            case 'air': {
                const j = k.j;
                j.t += dt;
                const f = Math.min(1, j.t / j.T); j.f = f;
                k.x = j.x0 + (j.tx - j.x0) * f;
                k.y = j.y0 + (j.ty - j.y0) * f - j.h * 4 * f * (1 - f);
                j.pitch = Math.atan2((j.ty - j.y0) - j.h * 4 * (1 - 2 * f), Math.abs(j.tx - j.x0) + 1) * 0.6;
                if (j.leap && held && Math.hypot(held.x - (k.x + k.dir * k.s * 0.45), held.y - (k.y - k.s * 1.05)) < held.r + k.s * 0.35) held.wob = held.r * 0.4;
                if (j.leap && !held) {
                    for (const b of balls) {
                        if (Math.hypot(b.x - (k.x + k.dir * k.s * 0.45), b.y - (k.y - k.s * 1.05)) < b.r + k.s * 0.35 && b.vy > -50) { b.vx = k.dir * rand(150, 380) * sc; b.vy = -rand(100, 300) * sc; }
                    }
                }
                if (f >= 1) { k.x = j.tx; k.y = j.ty; k.plat = j.plat; k.state = 'pose'; k.pose = 'stand'; k.t = 99; const a = k.after; k.after = null; a?.(); }
                break;
            }
            case 'inBox':
                k.t -= dt; k.peekT -= dt;
                if (k.pose === 'sleep') k.peekTarget = 0.3;
                else if (k.peekT <= 0) { k.peekTarget = Math.random() < 0.6 ? 1 : 0.15; k.peekT = rand(0.5, 1.8); }
                k.peek += (k.peekTarget - k.peek) * Math.min(1, dt * 6);
                if (k.t <= 0) leaveBox(k);
                break;
            case 'yarn': {
                const b = k.ball;
                if (now > k.until || !b || b === held) { idle(k); break; }
                if (b.y < fy - b.r - 2) { k.state = 'ball'; k.until = now + 5; k.watch = b; break; }
                const d = b.x - k.x;
                if (Math.abs(d) < b.r + k.s * 0.6 && Math.abs(b.vx) < run * 0.8) {
                    k.dir = Math.sign(d) || k.dir; k.stalk = false;
                    crouchThen(k, rand(0.3, 0.6), () => jumpTo(k, clamp(b.x - k.dir * k.s * 0.3, k.s, W - k.s), fy, 0, () => {
                        b.vx += k.dir * rand(260, 560) * sc; b.vy = -rand(0, 120) * sc;
                        k.state = 'yarn';
                    }));
                } else {
                    const far = Math.abs(d) > k.s * 3.5;
                    k.running = far; k.stalk = !far;
                    move(k, Math.sign(d), far ? run : walk * 0.7, dt);
                    k.state = 'yarn';
                }
                break;
            }
            case 'ball': {
                const b = k.ball;
                if (!b || now > k.until) { k.watch = null; idle(k); break; }
                if (!ballActive(b) && b !== held) { k.watch = null; k.ball = b; k.state = 'yarn'; k.until = now + rand(3, 6); break; }
                k.watch = b;
                const d = b.x - k.x, above = k.y - (b.y + b.r);
                if (Math.abs(d) > k.s * 0.5) {
                    k.running = Math.abs(d) > k.s * 2; k.stalk = false;
                    move(k, Math.sign(d), k.running ? run : walk * 1.6, dt);
                    k.pose = null; k.state = 'ball'; k.moving = true;
                } else {
                    k.moving = false; k.dir = Math.sign(d) || k.dir;
                    if (above < k.s * 1.1) k.pose = 'rear';
                    else if (above < k.s * 3.4 && k.cd <= 0) {
                        k.cd = rand(1.2, 2.5);
                        crouchThen(k, 0.3, () => jumpTo(k, clamp(b.x + k.dir * k.s * 0.15, k.s, W - k.s), plats[k.plat].y, k.plat, () => { k.state = 'ball'; }, b.y + k.s * 1.0));
                    } else k.pose = 'lookup';
                }
                break;
            }
            case 'chaseK': {
                const o = k.mate;
                if (!o || o.state !== 'fleeK' || now > k.until) { if (o && o.state === 'fleeK') idle(o); idle(k); break; }
                const d = o.x - k.x;
                k.running = true;
                if (Math.abs(d) < k.s * 0.8) startSpar(k, o);
                else move(k, Math.sign(d), run * 1.05, dt);
                break;
            }
            case 'fleeK': {
                const o = k.mate;
                if (!o || o.state !== 'chaseK') { idle(k); break; }
                const dir = Math.sign(k.x - o.x) || 1;
                k.running = true;
                const p = plats[0];
                if ((dir < 0 && k.x < p.x0 + k.s) || (dir > 0 && k.x > p.x1 - k.s)) { startSpar(o, k); break; }
                const stool = plats[2];
                if (Math.random() < dt * 0.5 && Math.abs(k.x - (stool.x0 + stool.x1) / 2) < k.s * 2.5) {
                    o.state = 'pose'; o.pose = 'lookup'; o.t = rand(1, 2); o.watch = k;
                    jumpTo(k, (stool.x0 + stool.x1) / 2, stool.y, 2, () => setPose(k, 'sit', rand(2, 4)));
                    break;
                }
                move(k, dir, run * 0.92, dt);
                break;
            }
            case 'approach': {
                const o = k.mate;
                if (!o || o.state !== 'pose' || now > k.until) { idle(k); break; }
                const d = o.x - k.x;
                k.stalk = Math.abs(d) < k.s * 4; k.running = false;
                if (Math.abs(d) < (k.s + o.s) * 0.75) { k.stalk = false; o.dir = -Math.sign(d) || o.dir; startSpar(k, o); } else move(k, Math.sign(d), walk * (k.stalk ? 0.6 : 1.3), dt);
                break;
            }
            case 'greet': {
                const o = k.mate;
                if (!o || o.state !== 'pose' || now > k.until) { idle(k); break; }
                const d = o.x - k.x;
                if (Math.abs(d) < (k.s + o.s) * 0.5) {
                    k.dir = Math.sign(d) || k.dir; o.dir = -k.dir;
                    const oPose = o.pose;
                    setPose(o, 'boop', 1.4); setPose(k, 'boop', 1.4, () => {
                        if (Math.random() < 0.5) {
                            setPose(o, oPose === 'loaf' ? 'loaf' : 'sit', rand(3, 6));
                            walkTo(k, o.x + k.dir * k.s * 1.4, false, () => idle(k));
                        } else {
                            setPose(o, 'loaf', rand(4, 7)); o.pose = 'loaf';
                            k.x = o.x - k.dir * (k.s + o.s) * 0.35;
                            setPose(k, 'groom', rand(3, 6));
                        }
                    });
                } else move(k, Math.sign(d), walk, dt);
                break;
            }
            case 'spar':
                sparUpdate(k, dt);
                break;
            case 'mouse': {
                const p = ptr;
                if (!p || now > k.until) { idle(k); break; }
                const d = p.x - k.x;
                k.watch = p;
                if (Math.abs(d) < k.s * 0.45 && k.cd <= 0) {
                    k.cd = 1;
                    crouchThen(k, 0.25, () => jumpTo(k, clamp(p.x, k.s, W - k.s), fy, 0, () => { k.state = 'mouse'; }));
                } else if (Math.abs(d) > k.s * 0.25) {
                    k.running = Math.abs(d) > k.s * 2; k.stalk = !k.running;
                    move(k, Math.sign(d), k.running ? run : walk * 0.8, dt);
                }
                break;
            }
            }
        }
        function drawState(k) {
            // map behaviour states onto drawable poses
            const st = k.state;
            if (st === 'spar') { const p = sparPose(k); if (p === 'crouchP') { k.state = 'crouch'; k.t = 1; drawCat(k); k.state = 'spar'; return; } const sv = k.pose; k.state = 'pose'; k.pose = p; drawCat(k); k.state = 'spar'; k.pose = sv; return; }
            if (st === 'yarn' || st === 'chaseK' || st === 'fleeK' || st === 'approach' || st === 'greet' || st === 'mouse' || st === 'hunt' || (st === 'ball' && k.moving !== false && !k.pose)) {
                const moving = st === 'chaseK' || st === 'fleeK' || Math.abs(k.lastX - k.x) > 0.05;
                const sv = k.state, svp = k.pose;
                if (moving) k.state = 'move'; else { k.state = 'pose'; k.pose = k.stalk ? 'stand' : 'stand'; }
                drawCat(k); k.state = sv; k.pose = svp; return;
            }
            if (st === 'ball') { const sv = k.state; k.state = 'pose'; drawCat(k); k.state = sv; return; }
            if (st === 'toy') { const sv = k.state, sp = k.pose; k.state = 'pose'; k.pose = 'rear'; drawCat(k); k.state = sv; k.pose = sp; return; }
            if (st === 'rub') { const sv = k.state, sp = k.pose; k.state = 'pose'; k.pose = k.rubPose; drawCat(k); k.state = sv; k.pose = sp; return; }
            drawCat(k);
        }


        /* ================= Cursor cat: one cat in a loft, hunting your mouse ================= */
        let hearts = [], still = 0, lastPP = null, lastDt = 0, idx = {}, sofaL = null, toy = null, sock = null, lights = [];
        const pawPos = k => [k.x + k.dir * k.s * 0.5, k.y - k.s * (k.j && k.j.leap ? 1.05 : 0.5)];

        /* ----- route finding between furniture ----- */
        function hopCost(a, b) {
            const A = plats[a], B = plats[b], s = cats[0].s;
            const gap = Math.max(0, B.x0 - A.x1, A.x0 - B.x1), up = A.y - B.y;
            if (gap > s * 3.2 || up > s * 3.1) return Infinity;
            if (up < 0 && gap > s * 1.5 && -up > s * 4) return Infinity;
            return 1 + Math.abs(up) / H * 4 + gap / W * 4;
        }
        function route(a, b) {
            const n = plats.length, dist = new Array(n).fill(Infinity), prev = new Array(n).fill(-1), done = new Array(n).fill(false);
            dist[a] = 0;
            for (;;) {
                let u = -1;
                for (let i = 0; i < n; i++) if (!done[i] && dist[i] < Infinity && (u < 0 || dist[i] < dist[u])) u = i;
                if (u < 0 || u === b) break;
                done[u] = true;
                for (let v = 0; v < n; v++) {
                    if (v === u || done[v]) continue;
                    const c = hopCost(u, v);
                    if (dist[u] + c < dist[v]) { dist[v] = dist[u] + c; prev[v] = u; }
                }
            }
            if (dist[b] === Infinity) return null;
            const path = [];
            for (let v = b; v >= 0; v = prev[v]) path.unshift(v);
            return path;
        }
        function hopTo(k, b, then) {
            const A = plats[k.plat], B = plats[b], s = k.s;
            const tx = clamp(clamp(k.x, B.x0 + s * 0.4, B.x1 - s * 0.4), A.x0 + s * 0.4, A.x1 - s * 0.4);
            const lx = clamp(tx, B.x0 + s * 0.45, B.x1 - s * 0.45);
            walkTo(k, tx, true, () => {
                k.dir = Math.abs(lx - k.x) > 2 ? Math.sign(lx - k.x) : k.dir;
                k.watch = {x: lx, y: B.y - s};
                crouchThen(k, 0.22, () => jumpTo(k, lx, B.y, b, then));
            });
        }
        function navTo(k, pi, x, then) {
            if (k.plat === pi) { walkTo(k, x, Math.abs(x - k.x) > k.s * 3, then); return; }
            const path = route(k.plat, pi);
            if (!path || path.length < 2) { then(); return; }
            hopTo(k, path[1], () => navTo(k, pi, x, then));
        }
        // the best spot to leap at the cursor from
        function platFor(x, y) {
            const s = cats[0].s;
            let best = -1, bs = Infinity;
            for (let i = 0; i < plats.length; i++) {
                const p = plats[i], up = p.y - y;
                if (up < -s * 0.3 || up > s * 3.3) continue;
                const hx = Math.max(0, p.x0 - x, x - p.x1);
                if (hx > s * 1.2) continue;
                const sc2 = up * 0.6 + hx * 2;
                if (sc2 < bs) { bs = sc2; best = i; }
            }
            if (best >= 0) return [best, true];
            for (let i = 0; i < plats.length; i++) {       // unreachable: get as close as possible
                const p = plats[i];
                if (p.y < y) continue;
                const sc2 = Math.max(0, p.x0 - x, x - p.x1) * 2 + (p.y - y);
                if (sc2 < bs) { bs = sc2; best = i; }
            }
            return [Math.max(0, best), false];
        }

        /* ----- the loft ----- */
        function buildLoft() {
            // A back garden at golden hour. The furniture positions are the same
            // climbing spots as before, dressed as trees, a bench, a wall and a shed.
            back = makeLayer(W, H, env.rs);
            const g = back.ctx;
            const sky = g.createLinearGradient(0, 0, 0, fy);
            sky.addColorStop(0, '#4f74b0'); sky.addColorStop(0.55, '#b98aa0'); sky.addColorStop(0.8, '#f3b48a'); sky.addColorStop(1, '#f7c99a');
            g.fillStyle = sky; g.fillRect(0, 0, W, fy);
            const sunX = W * 0.56, sunY = H * 0.5;
            const sun = g.createRadialGradient(sunX, sunY, 0, sunX, sunY, H * 0.35);
            sun.addColorStop(0, 'rgba(255,230,170,.75)'); sun.addColorStop(0.15, 'rgba(255,210,150,.35)'); sun.addColorStop(1, 'rgba(255,210,150,0)');
            g.fillStyle = sun; g.fillRect(sunX - H * 0.35, sunY - H * 0.35, H * 0.7, H * 0.7);
            g.fillStyle = '#fff0c8'; dotOn(g, sunX, sunY, H * 0.045);
            g.fillStyle = 'rgba(255,255,255,.35)';
            for (const [cx2, cy2, w2] of [[0.2, 0.12, 0.12], [0.55, 0.08, 0.16], [0.82, 0.2, 0.1]]) {
                for (let i = 0; i < 5; i++) { g.beginPath(); g.ellipse(W * (cx2 + (i - 2) * w2 * 0.18), H * (cy2 + Math.abs(i - 2) * 0.008), W * w2 * 0.16, H * 0.022, 0, 0, TAU); g.fill(); }
            }
            // distant hills and hedge
            for (const [col, base, amp, f] of [['#7c9a86', 0.58, 0.05, 0.0035], ['#5e8264', 0.63, 0.035, 0.006]]) {
                g.fillStyle = col; g.beginPath(); g.moveTo(0, fy);
                for (let x = 0; x <= W + 20; x += 20) g.lineTo(x, H * base - Math.sin(x * f + base * 9) * H * amp - Math.sin(x * f * 2.7) * H * amp * 0.3);
                g.lineTo(W, fy); g.closePath(); g.fill();
            }
            // wooden fence
            const fTop = H * 0.6;
            g.fillStyle = '#a7845e';
            for (let x = -H * 0.01; x < W; x += H * 0.05) {
                g.beginPath(); g.moveTo(x, fy); g.lineTo(x, fTop + H * 0.015); g.lineTo(x + H * 0.02, fTop); g.lineTo(x + H * 0.04, fTop + H * 0.015); g.lineTo(x + H * 0.04, fy); g.closePath(); g.fill();
            }
            g.fillStyle = 'rgba(0,0,0,.12)';
            for (let x = -H * 0.01; x < W; x += H * 0.05) g.fillRect(x + H * 0.04, fTop + H * 0.015, H * 0.01, fy - fTop);
            g.fillStyle = '#8f6e4c'; g.fillRect(0, fTop + H * 0.06, W, H * 0.018); g.fillRect(0, fy - H * 0.1, W, H * 0.018);
            // lawn
            const lawn = g.createLinearGradient(0, fy, 0, H);
            lawn.addColorStop(0, '#6b9a44'); lawn.addColorStop(1, '#4a7030');
            g.fillStyle = lawn; g.fillRect(0, fy - H * 0.01, W, H - fy + H * 0.01);
            g.strokeStyle = '#7fae52'; g.lineWidth = 1.5; g.beginPath();
            for (let x = 0; x < W; x += 4) { g.moveTo(x, fy); g.lineTo(x + rand(-3, 3), fy - rand(4, 12)); }
            g.stroke();
            g.fillStyle = 'rgba(190,180,160,.85)';
            for (let i = 0; i < 6; i++) { g.beginPath(); g.ellipse(W * (0.6 + i * 0.07), fy + H * (0.04 + (i % 2) * 0.03), H * 0.04, H * 0.014, 0, 0, TAU); g.fill(); }
            for (let i = 0; i < 40; i++) {       // a flower patch where the cat likes to roll
                g.fillStyle = ['#ff8fb0', '#ffe066', '#ffffff', '#c49bff'][i % 4];
                dotOn(g, W * 0.5 + rand(-0.12, 0.12) * W, fy + H * rand(0.03, 0.1), H * rand(0.004, 0.007));
            }
            // stone wall (the old window sill)
            const sill = plats[idx.sill];
            g.fillStyle = '#8c8478'; g.fillRect(sill.x0, sill.y, sill.x1 - sill.x0, fy - sill.y);
            g.strokeStyle = 'rgba(40,35,30,.35)'; g.lineWidth = 2; g.beginPath();
            for (let y = sill.y + H * 0.04, row = 0; y < fy; y += H * 0.04, row++) {
                g.moveTo(sill.x0, y); g.lineTo(sill.x1, y);
                for (let x = sill.x0 + (row % 2 ? H * 0.04 : 0); x < sill.x1; x += H * 0.08) { g.moveTo(x, y - H * 0.04); g.lineTo(x, y); }
            }
            g.stroke();
            g.fillStyle = '#a39a8c'; g.fillRect(sill.x0 - H * 0.008, sill.y, sill.x1 - sill.x0 + H * 0.016, H * 0.02);
            // trees: canopies first, then trunks and the branches the cat walks along
            const canopy = (x0, x1, y0, y1, n) => {
                for (let i = 0; i < n; i++) {
                    const x = W * rand(x0, x1), y = H * rand(y0, y1), r = H * rand(0.06, 0.12);
                    g.fillStyle = ['#3f6b3a', '#4d7d42', '#5a8a48', '#355e33'][i % 4]; dotOn(g, x, y, r);
                }
            };
            canopy(-0.02, 0.3, -0.04, 0.28, 34);
            canopy(0.38, 0.86, -0.05, 0.24, 46);
            const bark = '#6b4a32', limb = (x0, y0, x1, y1, w) => { g.strokeStyle = bark; g.lineWidth = w; g.lineCap = 'round'; g.beginPath(); g.moveTo(x0, y0); g.lineTo(x1, y1); g.stroke(); };
            g.fillStyle = bark;
            g.beginPath(); g.moveTo(W * 0.075, fy); g.lineTo(W * 0.093, H * 0.25); g.lineTo(W * 0.112, H * 0.25); g.lineTo(W * 0.13, fy); g.closePath(); g.fill();
            g.beginPath(); g.moveTo(W * 0.645, fy); g.lineTo(W * 0.66, H * 0.1); g.lineTo(W * 0.678, H * 0.1); g.lineTo(W * 0.695, fy); g.closePath(); g.fill();
            for (const i of [idx.tree1, idx.tree2, idx.tree3]) { const p = plats[i]; limb(p.x0, p.y + H * 0.01, p.x1, p.y + H * 0.012, H * 0.022); }
            const s1 = plats[idx.s1], s4 = plats[idx.s4], s2 = plats[idx.s2], s3 = plats[idx.s3], s5 = plats[idx.s5];
            limb(W * 0.11, s1.y + H * 0.05, s1.x0, s1.y + H * 0.01, H * 0.024); limb(s1.x0, s1.y + H * 0.01, s1.x1, s1.y + H * 0.012, H * 0.02);
            limb(W * 0.105, s4.y + H * 0.06, s4.x0, s4.y + H * 0.01, H * 0.022); limb(s4.x0, s4.y + H * 0.01, s4.x1, s4.y + H * 0.012, H * 0.018);
            limb(W * 0.665, s2.y + H * 0.06, s2.x1, s2.y + H * 0.01, H * 0.024); limb(s2.x0, s2.y + H * 0.012, s2.x1, s2.y + H * 0.01, H * 0.02);
            limb(s3.x0, s3.y + H * 0.012, s3.x1, s3.y + H * 0.012, H * 0.022);
            limb(s5.x0, s5.y + H * 0.012, s5.x1, s5.y + H * 0.012, H * 0.02);
            g.fillStyle = '#4d7d42';
            for (const p of [s1, s4, s2, s3, s5]) for (let i = 0; i < 4; i++) dotOn(g, rand(p.x0, p.x1), p.y + H * rand(0.02, 0.05), H * rand(0.015, 0.028));
            // picnic table with a lantern (the old desk)
            const dk = plats[idx.desk];
            g.strokeStyle = '#7a5434'; g.lineWidth = H * 0.016; g.lineCap = 'butt'; g.beginPath();
            g.moveTo(dk.x0 + H * 0.03, fy); g.lineTo(dk.x0 + H * 0.09, dk.y); g.moveTo(dk.x0 + H * 0.09, fy); g.lineTo(dk.x0 + H * 0.03, dk.y);
            g.moveTo(dk.x1 - H * 0.03, fy); g.lineTo(dk.x1 - H * 0.09, dk.y); g.moveTo(dk.x1 - H * 0.09, fy); g.lineTo(dk.x1 - H * 0.03, dk.y);
            g.stroke();
            g.fillStyle = '#9a6c44'; g.fillRect(dk.x0 - H * 0.01, dk.y, dk.x1 - dk.x0 + H * 0.02, H * 0.022);
            g.fillStyle = 'rgba(0,0,0,.15)'; for (let x = dk.x0; x < dk.x1; x += H * 0.05) g.fillRect(x, dk.y, 2, H * 0.022);
            const lx = dk.x1 - (dk.x1 - dk.x0) * 0.12, ly = dk.y;
            g.fillStyle = '#2e2a26'; g.fillRect(lx - H * 0.012, ly - H * 0.05, H * 0.024, H * 0.05);
            g.fillStyle = '#ffd88a'; g.fillRect(lx - H * 0.008, ly - H * 0.044, H * 0.016, H * 0.036);
            const glow = g.createRadialGradient(lx, ly - H * 0.025, 0, lx, ly - H * 0.025, H * 0.18);
            glow.addColorStop(0, 'rgba(255,210,140,.35)'); glow.addColorStop(1, 'rgba(255,210,140,0)');
            g.fillStyle = glow; g.fillRect(lx - H * 0.2, ly - H * 0.22, H * 0.4, H * 0.4);
            // potting shed with shelves of plants (the old bookcase)
            const bk = idx.books.map(i => plats[i]);
            const bx0 = bk[0].x0, bx1 = bk[0].x1, btop = plats[idx.booktop].y;
            g.fillStyle = '#7d5a3c'; g.fillRect(bx0 - H * 0.012, btop, bx1 - bx0 + H * 0.024, fy - btop);
            g.fillStyle = '#3c2a1e'; g.fillRect(bx0, btop + H * 0.02, bx1 - bx0, fy - btop - H * 0.02);
            g.fillStyle = 'rgba(255,255,255,.05)'; for (let x = bx0 - H * 0.012; x < bx1; x += H * 0.03) g.fillRect(x, btop, 2, H * 0.02);
            const lv = [btop, ...bk.map(p => p.y).sort((a, b) => a - b), fy];
            for (let l = 1; l < lv.length; l++) {
                const y = lv[l];
                for (let x = bx0 + H * 0.03; x < bx1 - H * 0.03; x += H * rand(0.05, 0.08)) {
                    if (Math.random() < 0.3) continue;
                    g.fillStyle = '#b8603a'; g.beginPath(); g.moveTo(x - H * 0.014, y - H * 0.03); g.lineTo(x + H * 0.014, y - H * 0.03); g.lineTo(x + H * 0.01, y); g.lineTo(x - H * 0.01, y); g.closePath(); g.fill();
                    g.fillStyle = ['#4f9a48', '#6fae4a', '#e86a8a', '#f0c040'][(Math.random() * 4) | 0];
                    dotOn(g, x, y - H * 0.042, H * 0.016);
                }
                if (l < lv.length - 1) { g.fillStyle = '#8f6a48'; g.fillRect(bx0, y, bx1 - bx0, H * 0.014); }
            }
            g.fillStyle = '#5a3c28'; g.fillRect(bx0 - H * 0.025, btop - H * 0.004, bx1 - bx0 + H * 0.05, H * 0.022);
            // crate backs
            for (const b of boxes) { g.fillStyle = '#8a6a44'; g.fillRect(b.x - b.w / 2, b.top - b.h * 0.12, b.w, b.h * 0.12); }
            // garden bench: in front of anything hiding behind it
            sofaL = makeLayer(W, H, env.rs);
            const f = sofaL.ctx, seat = plats[idx.seat], bkr = plats[idx.back];
            f.fillStyle = '#6e4a2e';
            f.fillRect(bkr.x0 + H * 0.01, bkr.y, H * 0.018, fy - bkr.y); f.fillRect(bkr.x1 - H * 0.028, bkr.y, H * 0.018, fy - bkr.y);
            f.fillStyle = '#a5764a';
            for (let i = 0; i < 4; i++) f.fillRect(bkr.x0, bkr.y + i * (seat.y - bkr.y) / 4, bkr.x1 - bkr.x0, (seat.y - bkr.y) / 4 - H * 0.006);
            f.fillStyle = '#b88654'; f.fillRect(seat.x0 - H * 0.01, seat.y, seat.x1 - seat.x0 + H * 0.02, H * 0.024);
            f.fillStyle = '#6e4a2e'; f.fillRect(seat.x0, seat.y + H * 0.024, H * 0.016, fy - seat.y - H * 0.024); f.fillRect(seat.x1 - H * 0.016, seat.y + H * 0.024, H * 0.016, fy - seat.y - H * 0.024);
            // festoon lights strung between the trees
            lights = [];
            const string = (x0, y0, x1, y1, n) => {
                for (let i = 0; i <= n; i++) { const u = i / n; lights.push({x: lerp(x0, x1, u), y: lerp(y0, y1, u) + Math.sin(u * Math.PI) * H * 0.05, c: ['255,214,140', '255,190,120', '255,236,180'][i % 3], ph: rand(0, TAU)}); }
            };
            string(W * 0.12, H * 0.1, W * 0.66, H * 0.08, 14);
            string(W * 0.68, H * 0.08, W * 0.9, H * 0.17, 6);
        }
        function dotOn(g, x, y, r) { g.beginPath(); g.arc(x, y, r, 0, TAU); g.fill(); }
        function initLoft() {
            sc = H / 1080; fy = H * 0.88; now = 0; G = 2400 * sc; held = null; prevDown = false;
            const P = (x0, x1, y, kind) => ({x0: W * x0, x1: W * x1, y: H * y, kind});
            plats = [{x0: 0, x1: W, y: fy, kind: 'floor'}];
            const add = (name, p) => { plats.push(p); idx[name] = plats.length - 1; return plats.length - 1; };
            add('tree1', P(0.05, 0.15, 0.70)); add('tree2', P(0.08, 0.17, 0.52)); add('tree3', P(0.04, 0.13, 0.34));
            add('seat', P(0.23, 0.41, 0.76)); add('back', P(0.22, 0.42, 0.665));
            idx.shelves = [add('s1', P(0.26, 0.36, 0.44)), add('s2', P(0.40, 0.50, 0.27)), add('s3', P(0.60, 0.70, 0.46)), add('s4', P(0.18, 0.27, 0.20)), add('s5', P(0.62, 0.72, 0.17))];
            add('sill', P(0.45, 0.59, 0.63)); add('desk', P(0.62, 0.80, 0.66));
            idx.books = [add('b1', P(0.84, 0.97, 0.72)), add('b2', P(0.84, 0.97, 0.54)), add('b3', P(0.84, 0.97, 0.36))];
            add('booktop', P(0.835, 0.975, 0.18));
            boxes = [W * 0.53, W * 0.2].map((x, i) => { const w = H * (i ? 0.12 : 0.15), h = H * (i ? 0.075 : 0.09); return {x, w, h, top: fy - h, occ: null}; });
            for (const b of boxes) { plats.push({x0: b.x - b.w / 2, x1: b.x + b.w / 2, y: b.top, kind: 'box'}); b.plat = plats.length - 1; }
            items = [
                {type: 'mug', plat: idx.desk, home: 0.2, col: '#e8e4d8'}, {type: 'plant', plat: idx.desk, home: 0.55},
                {type: 'plant', plat: idx.sill, home: 0.7}, {type: 'mug', plat: idx.books[1], home: 0.5, col: '#5a8ac8'},
                {type: 'plant', plat: idx.booktop, home: 0.45},
            ];
            for (const b of boxes) b.crate = true;
            items.forEach(resetItem);
            balls = []; bowls = [];
            toy = {ax: W * 0.29, ay: plats[idx.s1].y + H * 0.014, L: H * 0.12, a: 0.2, w: 0};
            sock = {x: W * 0.68, carried: false};
            const c = mkCat(4);   // calico: white, orange and black
            c.s = H * 0.09; c.x = W * 0.5; c.y = fy; c.plat = 0;
            cats = [c];
            buildLoft();
            hearts = []; still = 0; lastPP = null;
        }
        function updateToy(dt) {
            toy.w += (-(G / toy.L) * Math.sin(toy.a) * 0.35 - toy.w * 0.8) * dt;
            toy.a += toy.w * dt;
            toy.x = toy.ax + Math.sin(toy.a) * toy.L; toy.y = toy.ay + Math.cos(toy.a) * toy.L;
        }
        function drawToy() {
            ctx.strokeStyle = 'rgba(240,240,240,.7)'; ctx.lineWidth = 1.2;
            ctx.beginPath(); ctx.moveTo(toy.ax, toy.ay); ctx.lineTo(toy.x, toy.y); ctx.stroke();
            const r = H * 0.03;
            ctx.save(); ctx.translate(toy.x, toy.y); ctx.rotate(toy.a);
            ctx.fillStyle = '#e8508a'; ctx.beginPath(); ctx.ellipse(0, r * 0.55, r * 0.22, r * 0.6, 0, 0, TAU); ctx.fill();
            ctx.fillStyle = '#42c2e8'; ctx.beginPath(); ctx.ellipse(r * 0.12, r * 0.45, r * 0.14, r * 0.45, 0.25, 0, TAU); ctx.fill();
            ctx.strokeStyle = '#f4f0e8'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, r * 1.15); ctx.stroke();
            ctx.restore();
        }
        function drawSock(x, y, s, flip = 1) {
            // a yellow gardening glove (the cat's favourite thing to steal)
            ctx.save(); ctx.translate(x, y); ctx.scale(flip, 1);
            ctx.fillStyle = '#e8c23a';
            ctx.beginPath(); ctx.ellipse(0, -s * 0.04, s * 0.1, s * 0.07, 0, 0, TAU); ctx.fill();
            for (let i = 0; i < 4; i++) { ctx.beginPath(); ctx.ellipse(s * 0.1, -s * 0.09 + i * s * 0.03, s * 0.05, s * 0.016, 0.2, 0, TAU); ctx.fill(); }
            ctx.fillStyle = '#2f7a5a'; ctx.fillRect(-s * 0.16, -s * 0.08, s * 0.07, s * 0.08);
            ctx.restore();
        }

        /* ----- behaviour ----- */
        function startRub(k) {
            k.caught = false; k.trap = false; k.state = 'rub'; k.until = now + rand(4, 8); k.rubPose = 'stand';
        }
        function hunt(k) { k.state = 'hunt'; k.navT = 0; }
        function pounceAt(k) {
            const p = ptr, above = k.y - p.y, P2 = plats[k.plat];
            const tx = clamp(p.x, P2.x0 + k.s * 0.4, P2.x1 - k.s * 0.4);
            k.caught = false;
            const land = () => { if (k.caught) startRub(k); else if (Math.random() < 0.15) cheeky(k); else hunt(k); };
            if (above > k.s * 1.2) jumpTo(k, tx, P2.y, k.plat, land, p.y + k.s * 1.0);
            else jumpTo(k, tx, P2.y, k.plat, land, P2.y - k.s * 0.55);
        }
        function settle(k) {
            // somewhere comfy to lie down
            const spots = [[idx.seat, rand(plats[idx.seat].x0, plats[idx.seat].x1)], [idx.booktop, W * 0.9], [idx.tree3, W * 0.08], [idx.sill, W * 0.52]];
            const [pi, x] = spots[(Math.random() * spots.length) | 0];
            if (Math.random() < 0.3 && boxes.some(b => !b.occ)) return navTo(k, 0, k.x, () => goBox(k));
            navTo(k, pi, x, () => setPose(k, 'loaf', rand(4, 8), () => setPose(k, 'sleep', 999)));
        }
        function knockForAttention(k) {
            const its = items.filter(it => it.state === 'table');
            if (!its.length) return settle(k);
            const it = its[(Math.random() * its.length) | 0], t = plats[it.plat];
            const outward = it.x - t.x0 < t.x1 - it.x ? -1 : 1;
            navTo(k, it.plat, it.x - outward * k.s * 0.55, () => knock(k, it));
        }
        function cheeky(k) {
            const r = Math.random(), s = k.s;
            if (r < 0.16) return knockForAttention(k);
            if (r < 0.3) return navTo(k, idx.back, toy.ax + rand(-0.2, 0.2) * s, () => { k.state = 'toy'; k.until = now + rand(4, 8); k.cd = 0; });
            if (r < 0.44 && !sock.carried) {
                return navTo(k, 0, sock.x + (k.x < sock.x ? -1 : 1) * s * 0.5, () => {
                    sock.carried = true; k.carry = true;
                    let legs = (rand(3, 5)) | 0;
                    const leg = () => {
                        if (legs-- <= 0) { sock.x = clamp(k.x + k.dir * s * 0.55, s, W - s); sock.carried = false; k.carry = false; setPose(k, 'sit', rand(1, 2), () => hunt(k)); k.watch = ptr; return; }
                        walkTo(k, k.x < W / 2 ? rand(W * 0.55, W * 0.95) : rand(W * 0.05, W * 0.45), true, leg);
                    };
                    leg();
                });
            }
            if (r < 0.58) return navTo(k, 0, W * 0.5 + rand(-0.06, 0.06) * W, () => { setPose(k, 'belly', rand(6, 10), () => { k.trap = false; hunt(k); }); k.trap = true; });
            if (r < 0.72) {
                const seat = plats[idx.seat];
                return navTo(k, 0, rand(seat.x0 + s, seat.x1 - s), () => { k.state = 'behind'; k.pose = 'peek'; k.box = {x: k.x, top: plats[idx.back].y + s * 0.05}; k.peek = 0; k.peekTarget = 1; k.t = rand(6, 12); k.boxAge = 0; });
            }
            if (r < 0.84 && boxes.some(b => !b.occ)) return navTo(k, 0, k.x, () => goBox(k));
            setPose(k, 'sit', 2.4, () => hunt(k)); k.blinkT = 2.4; k.watch = ptr;     // a slow blink: "I love you"
        }
        function soloDecide(k) {
            if (!ptr) return idle(k);
            if (still > 2.5) return Math.random() < 0.35 ? knockForAttention(k) : settle(k);
            if (Math.random() < 0.25) return cheeky(k);
            hunt(k);
        }
        function ambushFrom(k, top) {
            k.box = null; k.res = null; k.x = clamp(k.x, k.s, W - k.s); k.y = top; k.caught = false; k.boxAge = 0;
            jumpTo(k, clamp(ptr.x, k.s, W - k.s), fy, 0, () => { if (k.caught) startRub(k); else hunt(k); }, Math.min(ptr.y + k.s, top - k.s * 0.5));
        }
        function soloUpdate(k, dt) {
            const walk = k.s * 1.1, run = k.s * 4.4, s = k.s;
            if (k.state !== 'rub') k.headOv = null;
            if (k.blinkT > 0) k.blinkT -= dt;
            if (!(k.state === 'pose' && k.pose === 'lookup')) k.chatter = false;
            // wake up when the mouse moves again
            if (k.state === 'pose' && (k.pose === 'loaf' || k.pose === 'sleep') && ptr && still < 0.05) {
                k.settling = false;
                if (k.pose === 'sleep') setPose(k, 'stretch', 1.2, () => setPose(k, 'sit', 0.4, () => hunt(k))); else setPose(k, 'sit', 0.3, () => hunt(k));
                return true;
            }
            if (k.settling && k.state === 'walk' && ptr && still < 0.05) { k.settling = false; hunt(k); return true; }
            // settle down, or knock something over for attention, when the mouse stops
            if (still > 2.5 && !k.settling && (k.state === 'hunt' || (k.state === 'pose' && ['sit', 'stand', 'lookup'].includes(k.pose)))) {
                k.settling = true;
                if (Math.random() < 0.35) knockForAttention(k); else settle(k);
                return true;
            }
            if (k.state === 'air' && ptr) {
                const [px, py] = pawPos(k);
                if (Math.hypot(px - ptr.x, py - ptr.y) < s * 0.55) k.caught = true;
                return false;
            }
            // belly-up trap: get too close and it grabs the cursor
            if (k.state === 'pose' && k.pose === 'belly' && k.trap && ptr) {
                if (k.kickT > 0) { k.kickT -= dt; if (k.kickT <= 0) startRub(k); return false; }
                if (Math.hypot(ptr.x - k.x, ptr.y - (k.y - s * 0.3)) < s * 1.3) { k.kickT = 1.2; k.t = 99; }
                return false;
            }
            if ((k.state === 'inBox' && k.ambush) || k.state === 'behind') {
                k.t -= dt; k.boxAge = (k.boxAge || 0) + dt;
                const b = k.box, d = ptr ? Math.abs(ptr.x - b.x) : Infinity;
                k.peekTarget = d < s * 6 ? 0.2 : 1;
                k.peek += (k.peekTarget - k.peek) * Math.min(1, dt * 6);
                k.dir = ptr && ptr.x < b.x ? -1 : 1;
                if (ptr && d < s * 3 && still < 0.5 && k.boxAge > 1.5) {
                    if (k.state === 'inBox') { b.occ = null; k.x = b.x; }
                    ambushFrom(k, b.top);
                } else if (k.t <= 0) {
                    if (k.state === 'inBox') { k.boxAge = 0; leaveBox(k); } else { k.box = null; hunt(k); }
                }
                return true;
            }
            if (k.state === 'toy') {
                if (now > k.until || k.plat !== idx.back) { hunt(k); return true; }
                k.dir = Math.sign(toy.x - k.x) || k.dir; k.watch = toy;
                if (Math.abs(toy.x - k.x) > s * 0.6) move(k, Math.sign(toy.x - k.x), walk, dt);
                if (k.cd <= 0) { toy.w += rand(1.5, 3.5) * (Math.random() < 0.5 ? -1 : 1); k.cd = rand(0.4, 0.9); }
                return true;
            }
            if (k.state === 'hunt') {
                k.settling = false;
                if (!ptr) { idle(k); return true; }
                k.watch = ptr;
                k.navT = (k.navT || 0) - dt;
                if (!(k.navT > 0) || k.goal === undefined) { k.navT = 0.35; [k.goal, k.reach] = platFor(ptr.x, ptr.y); }
                if (k.plat !== k.goal) {
                    const path = route(k.plat, k.goal);
                    if (path && path.length > 1) { hopTo(k, path[1], () => hunt(k)); return true; }
                }
                const P2 = plats[k.plat];
                const tx = clamp(ptr.x, P2.x0 + s * 0.4, P2.x1 - s * 0.4), d = tx - k.x, ad = Math.abs(d), above = k.y - ptr.y;
                if (Math.random() < dt * 0.08) { cheeky(k); return true; }
                if (Math.random() < dt * 0.04) { setPose(k, 'earscratch', rand(1, 1.6), () => hunt(k)); return true; }
                if (ad > s * 4) { k.running = true; k.stalk = false; move(k, Math.sign(d), run, dt); } else if (ad > s * 1.0) {
                    k.running = false; k.stalk = true;
                    if (Math.random() < dt * 0.4) { k.stalk = false; setPose(k, 'lookup', rand(0.4, 1), () => hunt(k)); k.watch = ptr; return true; }
                    move(k, Math.sign(d), walk * 0.65, dt);
                } else if (!k.reach || above > s * 3.4) {
                    setPose(k, 'lookup', rand(0.8, 1.5), () => hunt(k)); k.watch = ptr; k.chatter = true;
                } else if (k.cd <= 0) {
                    k.cd = rand(0.9, 1.8); k.dir = Math.sign(ptr.x - k.x) || k.dir; k.stalk = false;
                    crouchThen(k, rand(0.35, 0.8), () => { if (ptr) pounceAt(k); else idle(k); });
                } else {
                    k.dir = Math.sign(ptr.x - k.x) || k.dir;
                }
                return true;
            }
            if (k.state === 'rub') {
                if (!ptr || now > k.until) { setPose(k, 'sit', rand(1, 2), () => hunt(k)); return true; }
                let hx = (ptr.x - k.x) * k.dir;
                if (hx < s * 0.15) { k.dir = -k.dir; hx = (ptr.x - k.x) * k.dir; }
                const hy = ptr.y - k.y;
                const headWX = k.x + k.dir * s * 0.55, headWY = k.y - s * 0.75;
                if (Math.hypot(ptr.x - headWX, ptr.y - headWY) > s * 1.3) { hunt(k); k.headOv = null; return true; }
                const P2 = plats[k.plat], want = clamp(ptr.x - k.dir * s * 0.55, P2.x0 + s * 0.4, P2.x1 - s * 0.4);
                if (Math.abs(want - k.x) > s * 0.05) k.x += Math.sign(want - k.x) * Math.min(Math.abs(want - k.x), s * 0.8 * dt);
                k.rubPose = hy < -s * 0.98 ? 'rear' : 'stand';
                k.headOv = [clamp(hx, s * 0.35, s * 0.8) + Math.sin(now * 3) * 0.05 * s, clamp(hy, -1.05 * s, -0.35 * s) + Math.sin(now * 6) * 0.02 * s];
                k.tiltOv = 0.25 + Math.sin(now * 5) * 0.32;
                if (Math.random() < dt * 2) hearts.push({x: headWX, y: headWY - s * 0.3, vx: rand(-15, 15), life: 1.4});
                return true;
            }
            return false;
        }
        function drawHearts(dt) {
            for (let i = hearts.length - 1; i >= 0; i--) {
                const h = hearts[i];
                h.life -= dt;
                if (h.life <= 0) { hearts.splice(i, 1); continue; }
                h.y -= 35 * sc * dt; h.x += h.vx * dt;
                const a = Math.min(1, h.life), r = H * 0.008;
                ctx.fillStyle = `rgba(255,120,170,${(a * 0.85).toFixed(2)})`;
                dot(h.x - r * 0.5, h.y, r * 0.6); dot(h.x + r * 0.5, h.y, r * 0.6);
                ctx.beginPath(); ctx.moveTo(h.x - r * 1.05, h.y + r * 0.2); ctx.lineTo(h.x + r * 1.05, h.y + r * 0.2); ctx.lineTo(h.x, h.y + r * 1.3); ctx.closePath(); ctx.fill();
            }
        }
        function frameLoft(dt) {
            now += dt; lastDt = dt;
            handlePointer();
            updateItems(dt);
            updateToy(dt);
            for (const k of cats) { k.lastX = k.x; update(k, dt); }
            ctx.drawImage(back, 0, 0);
            ctx.globalCompositeOperation = 'lighter';
            for (const l of lights) {
                const tw = 0.55 + 0.45 * Math.sin(now * 2 + l.ph);
                ctx.fillStyle = `rgba(${l.c},${(0.18 * tw).toFixed(2)})`; dot(l.x, l.y, H * 0.012);
                ctx.fillStyle = `rgba(${l.c},${(0.8 * tw).toFixed(2)})`; dot(l.x, l.y, H * 0.003);
            }
            ctx.globalCompositeOperation = 'source-over';
            drawToy();
            for (const it of items) drawItem(it);
            if (!sock.carried) drawSock(sock.x, fy - cats[0].s * 0.03, cats[0].s);
            for (const k of cats) if (k.state === 'behind') drawInBox(k);
            ctx.drawImage(sofaL, 0, 0);
            for (const k of cats) if (k.state === 'inBox') drawInBox(k);
            for (const b of boxes) drawBoxFront(b);
            for (const k of cats) if (k.state !== 'inBox' && k.state !== 'behind') drawState(k);
            drawHearts(dt);
        }
        function init() {
            if (solo) return initLoft();
            sc = H / 1080; fy = H * 0.8; now = 0; G = 2400 * sc; held = null; prevDown = false;
            win = {x: W * 0.4, y: H * 0.12, w: W * 0.2, h: H * 0.34};
            plats = [{x0: 0, x1: W, y: fy},
                {x0: W * 0.64, x1: W * 0.84, y: fy - H * 0.2},
                {x0: W * 0.27, x1: W * 0.32, y: fy - H * 0.12},
                {x0: win.x - H * 0.03, x1: win.x + win.w + H * 0.03, y: win.y + win.h + H * 0.015}];
            rug = {x: W * 0.3, w: W * 0.17};
            post = {x: W * 0.19, w: H * 0.04, top: fy - H * 0.24};
            bowls = [{x: W * 0.37, w: H * 0.06, h: H * 0.022, col: '#3e7fb8', food: '#8a5a32', occ: null}, {x: W * 0.405, w: H * 0.06, h: H * 0.022, col: '#c8484c', food: '#9fc6e6', occ: null}];
            const bw = H * 0.15, bh = H * 0.1;
            boxes = [W * 0.08, W * 0.53, W * 0.94].map(x => ({x, w: bw * rand(0.9, 1.1), h: bh, top: fy - bh, occ: null}));
            items = [{type: 'mug', home: 0.25, col: ['#e8e4d8', '#5a8ac8', '#d8b04a'][(Math.random() * 3) | 0]}, {type: 'plant', home: 0.75}];
            items.forEach(resetItem);
            balls = [['#d6455a', '#9e2c3e'], ['#4a7fd6', '#2c5296'], ['#e8b83a', '#b38a1e']].map(([col, dark], i) => {
                const x = W * (0.25 + i * 0.22);
                return {x, y: fy - H * 0.022, r: H * 0.022, vx: 0, vy: 0, rot: 0, col, dark, wob: 0, tail: {x: x - H * 0.06, y: fy - 1, vx: 0, vy: 0}};
            });
            buildRoom();
            const n = solo ? 1 : W > 1600 ? 8 : W > 1000 ? 6 : 5;
            const start = (Math.random() * COATS.length) | 0;
            cats = Array.from({length: n}, (_, i) => mkCat(start + i));
        }
        function handlePointer() {
            ptr = env.pointer;
            if (ptr && lastPP && Math.hypot(ptr.x - lastPP.x, ptr.y - lastPP.y) > 2) still = 0; else still += lastDt;
            lastPP = ptr ? {x: ptr.x, y: ptr.y} : null;
            const down = !!(ptr && ptr.down);
            if (down && !prevDown && ptr.free) {
                let best = null, bd = Infinity;
                for (const b of balls) { const d = Math.hypot(b.x - ptr.x, b.y - ptr.y); if (d < b.r * 2.2 && d < bd) { bd = d; best = b; } }
                held = best;
            }
            if (!down && held) { held.vx = clamp(held.vx, -2500, 2500); held.vy = clamp(held.vy, -2500, 2500); held = null; }
            if (!ptr) held = null;
            prevDown = down;
        }
        function frame(dt) {
            if (solo) return frameLoft(dt);
            now += dt; lastDt = dt;
            handlePointer();
            updateBalls(dt);
            updateItems(dt);
            for (const k of cats) { k.lastX = k.x; update(k, dt); }
            ctx.drawImage(back, 0, 0);
            for (const it of items) drawItem(it);
            for (const k of cats) if (k.state === 'inBox') drawInBox(k);
            for (const b of boxes) drawBoxFront(b);
            for (const b of balls) if (!ballActive(b)) drawBall(b);
            const order = cats.filter(k => k.state !== 'inBox').sort((p, q) => (p.plat ? 1 : 0) - (q.plat ? 1 : 0));
            for (const k of order) drawState(k);
            for (const b of balls) if (ballActive(b)) drawBall(b);
        }
        return {init, frame};
    };
    const kittens = makeKittens(false);
    const cursorcat = makeKittens(true);

    /* Neon: a big pulsing emblem (your own image, chosen in Settings) on a dark blue/purple gaming backdrop */
    const neon = (() => {
        let t = 0, grid = 0, bg = null, parts = [], sparks = [], bolts = [], waves = [], trail = [];
        let nextBolt = 2, nextWave = 1, hover = 0, beat = 0, prevDown = false, cx = 0, cy = 0, L = 0, horizon = 0;
        const COLS = ['150,90,255', '90,120,255', '200,110,255', '110,170,255'];
        function makeBg() {
            bg = makeLayer(W, H, env.rs);
            const g = bg.ctx;
            const sky = g.createLinearGradient(0, 0, 0, H);
            sky.addColorStop(0, '#000004'); sky.addColorStop(0.55, '#03020e'); sky.addColorStop(1, '#050312');
            g.fillStyle = sky; g.fillRect(0, 0, W, H);
            // faint hex pattern
            g.strokeStyle = 'rgba(120,90,255,.02)'; g.lineWidth = 1;
            const hr = H * 0.035, hw = hr * Math.sqrt(3);
            g.beginPath();
            for (let row = 0; row * hr * 1.5 < horizon + hr; row++) {
                for (let col = -1; col * hw < W + hw; col++) {
                    const x = col * hw + (row % 2 ? hw / 2 : 0), y = row * hr * 1.5;
                    for (let i = 0; i <= 6; i++) {
                        const a = Math.PI / 6 + i * Math.PI / 3, px = x + Math.cos(a) * hr, py = y + Math.sin(a) * hr;
                        if (i === 0) g.moveTo(px, py); else g.lineTo(px, py);
                    }
                }
            }
            g.stroke();
            const hz = g.createLinearGradient(0, horizon - H * 0.12, 0, horizon + H * 0.04);
            hz.addColorStop(0, 'rgba(140,70,255,0)'); hz.addColorStop(0.8, 'rgba(140,70,255,.07)'); hz.addColorStop(1, 'rgba(140,70,255,0)');
            g.fillStyle = hz; g.fillRect(0, horizon - H * 0.12, W, H * 0.16);
        }
        function newPart(p, initial) {
            p.x = rand(0, W); p.y = initial ? rand(0, H) : H + 20;
            p.vx = rand(-8, 8); p.vy = -rand(10, 40);
            p.r = rand(1, 3.2); p.col = COLS[(Math.random() * COLS.length) | 0];
            p.kind = Math.random() < 0.18 ? 'plus' : Math.random() < 0.15 ? 'ring' : 'dot';
            p.rot = rand(0, TAU); p.spin = rand(-1, 1); p.glow = 0;
        }
        function init() {
            t = 0; cx = W / 2; cy = H * 0.45; L = Math.min(W, H) * 0.44; horizon = H * 0.7;
            makeBg();
            parts = Array.from({length: Math.round(Math.min(140, W * H / 15000))}, () => { const p = {}; newPart(p, true); return p; });
            sparks = []; bolts = []; waves = []; trail = []; hover = 0; nextBolt = 2; nextWave = 1; lastP = null; boomT = -1; flash = 0; pending = [];
        }
        function burst(x, y, n, speed, ang = null, spread = TAU, size = 1) {
            for (let i = 0; i < n && sparks.length < 900; i++) {
                const a = ang === null ? rand(0, TAU) : ang + rand(-spread / 2, spread / 2), v = speed * rand(0.4, 1);
                sparks.push({x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, life: rand(0.5, 1.2) * (0.6 + size * 0.4), max: 1, r: rand(1, 2.6) * size, col: COLS[(Math.random() * 3) | 0]});
                sparks[sparks.length - 1].max = sparks[sparks.length - 1].life;
            }
        }
        function hookSparks(n, size = 1) {
            const k = H / 1080;
            for (let i = 0; i < n && sparks.length < 900; i++) {
                const a = rand(0, TAU), v = rand(260, 520) * k * (0.6 + size * 0.4), life = rand(0.7, 1.3) * (0.7 + size * 0.3);
                sparks.push({x: cx + Math.cos(a) * L * 0.48, y: cy + Math.sin(a) * L * 0.48, vx: Math.cos(a) * v, vy: Math.sin(a) * v,
                    life, max: life, r: rand(1.2, 2.6) * size, col: COLS[(Math.random() * 3) | 0], curl: (Math.random() < 0.5 ? -1 : 1) * rand(2, 4.5)});
            }
        }
        // Clicking the emblem: it bursts into a huge shower of neon sparks, then reforms.
        function explode() {
            const k = H / 1080;
            boomT = 0; flash = 0.6;
            for (let i = 0; i < 90; i++) {
                const a = rand(0, TAU);
                burst(cx + Math.cos(a) * L * 0.47, cy + Math.sin(a) * L * 0.47, 1, rand(450, 1000) * k, a, 0.4, rand(1.3, 2.2));
            }
            hookSparks(36, 1.8);
            shootBolts(10, 1.8);
            pending.push({at: 0.18, bolts: 6}, {at: 0.36, bolts: 4});
            for (const [at, w, life] of [[0, 10, 1.2], [0.12, 7, 1.4], [0.26, 5, 1.6]])
                pending.push({at, w: {x: cx, y: cy, r: L * 0.3, life, max: life, w}});
        }
        function shootBolts(n, size = 1) {
            for (let i = 0; i < n; i++) {
                const a = rand(0, TAU), r0 = L * 0.5, len = L * rand(0.5, 1.1) * size;
                const pts = [];
                let x = cx + Math.cos(a) * r0, y = cy + Math.sin(a) * r0;
                pts.push([x, y]);
                const steps = 9;
                for (let s = 1; s <= steps; s++) {
                    const f = s / steps, j = (1 - f * 0.5) * L * 0.05;
                    x = cx + Math.cos(a) * (r0 + len * f) + rand(-j, j); y = cy + Math.sin(a) * (r0 + len * f) + rand(-j, j);
                    pts.push([x, y]);
                }
                bolts.push({pts, life: 0.45 * (0.6 + size * 0.4), max: 0.45 * (0.6 + size * 0.4), w: size});
                burst(x, y, Math.round(10 * size), 220 * (H / 1080) * size, null, TAU, size > 1 ? 1.5 : 1);
            }
        }
        function drawLogo(scale, alpha) {
            const img = env.logo;
            if (!img) return;
            const fit = L / Math.max(img.w, img.h) * scale;
            const w = img.w * fit, h = img.h * fit;
            const ox = ptrOff[0], oy = ptrOff[1];
            ctx.globalAlpha = alpha;
            ctx.drawImage(img, cx - w / 2 + ox, cy - h / 2 + oy, w, h);
            ctx.globalAlpha = 1;
        }
        let ptrOff = [0, 0], lastP = null, wasPeak = false, wasHover = false, boomT = -1, flash = 0, pending = [];
        function frame(dt) {
            t += dt; grid = (grid + dt * 0.35) % 1;
            const p = env.pointer;
            const k = H / 1080;
            // pointer: hover over the emblem, click shockwaves, a glowing trail
            const dist = p ? Math.hypot(p.x - cx, p.y - cy) : Infinity;
            hover += ((env.logo && dist < L * 0.55 ? 1 : 0) - hover) * Math.min(1, dt * 5);
            ptrOff = [0, 0];
            if (p && p.down && !prevDown && p.free) {
                if (env.logo && dist < L * 0.5 && boomT < 0) explode();
                else { waves.push({x: p.x, y: p.y, r: 10, life: 1, max: 1, w: 3}); burst(p.x, p.y, 24, 320 * k); }
            }
            for (let i = pending.length - 1; i >= 0; i--) {
                pending[i].at -= dt;
                if (pending[i].at <= 0) { if (pending[i].w) waves.push(pending[i].w); if (pending[i].bolts) shootBolts(pending[i].bolts, 1.6); pending.splice(i, 1); }
            }
            if (boomT >= 0) { boomT += dt; if (boomT > 1.3) boomT = -1; }
            flash *= Math.exp(-dt * 5);
            prevDown = !!(p && p.down);
            // spark trail: the faster the mouse moves, the more sparks fly off it
            if (p && lastP) {
                const mvx = (p.x - lastP.x) / Math.max(dt, 0.001), mvy = (p.y - lastP.y) / Math.max(dt, 0.001), sp = Math.hypot(mvx, mvy);
                const nsp = Math.min(4, sp * dt / 16);
                for (let i = 0; i < nsp && trail.length < 500; i++) {
                    const f = Math.random(), life = rand(0.25, 0.55);
                    trail.push({x: lastP.x + (p.x - lastP.x) * f, y: lastP.y + (p.y - lastP.y) * f,
                        vx: -mvx * 0.08 + rand(-90, 90) * k, vy: -mvy * 0.08 + rand(-110, 30) * k, life, max: life, col: COLS[(Math.random() * 4) | 0]});
                }
            }
            lastP = p ? {x: p.x, y: p.y} : null;
            // heartbeat pulse
            // heavy double heartbeat ("lub-dub")
            const ph = (t * 0.33) % 1;
            beat = Math.exp(-Math.pow((ph - 0.04) / 0.02, 2)) + 0.7 * Math.exp(-Math.pow((ph - 0.12) / 0.022, 2));
            const has = !!env.logo;
            const peak = beat > 0.85;
            if (has && peak && !wasPeak) {
                waves.push({x: cx, y: cy, r: L * 0.45, life: 1.2, max: 1.2, w: 3});
                // little sparks on every beat; bigger and more of them while hovered
                if (hover > 0.3) hookSparks(Math.round(hover * 14));
                for (let i = 0; i < 12 + hover * 16; i++) {
                    const a = rand(0, TAU);
                    burst(cx + Math.cos(a) * L * 0.46, cy + Math.sin(a) * L * 0.46, 1, (260 + hover * 260) * k, a, 0.3, 0.45 + hover * 0.55);
                }
            }
            wasPeak = peak;
            // the emblem only fires energy bolts while the mouse is over it
            if (has && hover > 0.5 && !wasHover) { shootBolts(8); waves.push({x: cx, y: cy, r: L * 0.5, life: 1, max: 1, w: 8}); }
            wasHover = hover > 0.5;
            if (has && hover > 0.3) {
                nextBolt -= dt * (1 + hover * 2);
                if (nextBolt <= 0) { shootBolts((rand(2, 5) + hover * 2) | 0); nextBolt = rand(0.4, 1.1); }
            }
            if (has && hover > 0.5 && Math.random() < dt * 12) {
                const a = rand(0, TAU);
                burst(cx + Math.cos(a) * L * 0.45, cy + Math.sin(a) * L * 0.45, 3, 300 * k, a, 0.8);
            }

            ctx.drawImage(bg, 0, 0);
            ctx.globalCompositeOperation = 'lighter';
            // aurora ribbons
            for (let r = 0; r < 2; r++) {
                const base = H * (0.18 + r * 0.14), amp = H * 0.05, col = r ? '90,120,255' : '170,80,255';
                for (const [lw, a] of [[H * 0.09, 0.018], [H * 0.025, 0.035]]) {
                    ctx.strokeStyle = `rgba(${col},${a})`; ctx.lineWidth = lw; ctx.beginPath();
                    for (let x = -20; x <= W + 20; x += 30) {
                        const y = base + Math.sin(x * 0.004 + t * (0.35 + r * 0.2) + r) * amp + Math.sin(x * 0.011 - t * 0.5) * amp * 0.3;
                        if (x === -20) ctx.moveTo(x, y); else ctx.lineTo(x, y);
                    }
                    ctx.stroke();
                }
            }
            // neon grid floor
            ctx.lineCap = 'butt';
            for (let i = 0; i < 16; i++) {
                const z = (i + grid) / 16, y = horizon + (H - horizon) * Math.pow(z, 2.2);
                ctx.strokeStyle = `rgba(150,80,255,${(0.03 + z * 0.17).toFixed(2)})`; ctx.lineWidth = 0.6 + z * 1.8;
                ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
            }
            ctx.strokeStyle = 'rgba(100,110,255,.1)'; ctx.lineWidth = 1.1; ctx.beginPath();
            for (let j = -18; j <= 18; j++) { ctx.moveTo(cx + j * W * 0.018, horizon); ctx.lineTo(cx + j * W * 0.14, H); }
            ctx.stroke();
            if (p && p.y > horizon) {
                const fg = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, H * 0.18);
                fg.addColorStop(0, 'rgba(160,90,255,.22)'); fg.addColorStop(1, 'rgba(180,100,255,0)');
                ctx.fillStyle = fg; ctx.fillRect(p.x - H * 0.18, p.y - H * 0.18, H * 0.36, H * 0.36);
            }
            // drifting particles that react to the pointer
            for (const q of parts) {
                if (p) {
                    const dx = q.x - p.x, dy = q.y - p.y, d = Math.hypot(dx, dy);
                    if (d < 160 * k) { const f = (1 - d / (160 * k)) * 600 * k * dt; q.vx += dx / (d || 1) * f; q.vy += dy / (d || 1) * f; q.glow = 1; }
                }
                q.glow = Math.max(0, q.glow - dt * 1.5);
                q.vx *= Math.exp(-dt * 1.2); q.vy += (-25 * k - q.vy) * dt * 0.8;
                q.x += q.vx * dt; q.y += q.vy * dt; q.rot += q.spin * dt;
                if (q.y < -20 || q.x < -30 || q.x > W + 30) newPart(q, false);
                const a = 0.17 + q.glow * 0.65, r = q.r * (1 + q.glow);
                ctx.fillStyle = `rgba(${q.col},${(a * 0.25).toFixed(2)})`; dot(q.x, q.y, r * 3.5);
                ctx.fillStyle = `rgba(${q.col},${a.toFixed(2)})`;
                if (q.kind === 'plus') {
                    ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(q.rot);
                    ctx.fillRect(-r * 2.4, -r * 0.8, r * 4.8, r * 1.6); ctx.fillRect(-r * 0.8, -r * 2.4, r * 1.6, r * 4.8);
                    ctx.restore();
                } else if (q.kind === 'ring') {
                    ctx.strokeStyle = `rgba(${q.col},${a.toFixed(2)})`; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.arc(q.x, q.y, r * 2.2, 0, TAU); ctx.stroke();
                } else dot(q.x, q.y, r);
            }
            // glow behind the emblem
            const g1 = has ? 0.27 + beat * 0.3 + hover * 0.35 : 0;
            const halo = ctx.createRadialGradient(cx, cy, L * 0.1, cx, cy, L * (1.05 + beat * 0.12 + hover * 0.2));
            halo.addColorStop(0, `rgba(150,70,255,${(0.45 * g1).toFixed(2)})`); halo.addColorStop(0.45, `rgba(80,90,255,${(0.18 * g1).toFixed(2)})`); halo.addColorStop(1, 'rgba(80,90,255,0)');
            if (has) { ctx.fillStyle = halo; ctx.fillRect(cx - L * 1.5, cy - L * 1.5, L * 3, L * 3); }
            // rotating rings
            ctx.lineCap = 'round';
            for (let i = 0; i < (has ? 3 : 0); i++) {
                const R = L * (0.62 + i * 0.09 + hover * 0.05), dir = i % 2 ? -1 : 1, segs = 3 + i;
                ctx.strokeStyle = `rgba(${COLS[i]},${(0.35 + hover * 0.3).toFixed(2)})`; ctx.lineWidth = 2 + (2 - i);
                for (let sgi = 0; sgi < segs; sgi++) {
                    const a = t * (0.4 + i * 0.25) * dir + sgi * TAU / segs;
                    ctx.beginPath(); ctx.arc(cx, cy, R, a, a + TAU / segs * 0.55); ctx.stroke();
                }
            }
            // shockwaves
            for (let i = waves.length - 1; i >= 0; i--) {
                const w = waves[i];
                w.life -= dt; w.r += dt * L * 0.9;
                if (w.life <= 0) { waves.splice(i, 1); continue; }
                const a = w.life / w.max;
                ctx.strokeStyle = `rgba(170,100,255,${(a * 0.6).toFixed(2)})`; ctx.lineWidth = w.w * (0.5 + a);
                ctx.beginPath(); ctx.arc(w.x, w.y, w.r, 0, TAU); ctx.stroke();
            }
            // energy bolts
            ctx.lineJoin = 'round';
            for (let i = bolts.length - 1; i >= 0; i--) {
                const b = bolts[i];
                b.life -= dt;
                if (b.life <= 0) { bolts.splice(i, 1); continue; }
                const a = b.life / b.max;
                for (const [lw, col, al] of [[10, '150,60,255', 0.12], [4, '190,120,255', 0.4], [1.6, '245,230,255', 0.9]]) {
                    ctx.strokeStyle = `rgba(${col},${(al * a).toFixed(2)})`; ctx.lineWidth = lw * (b.w || 1);
                    ctx.beginPath(); ctx.moveTo(b.pts[0][0], b.pts[0][1]);
                    for (let j = 1; j < b.pts.length; j++) ctx.lineTo(b.pts[j][0], b.pts[j][1]);
                    ctx.stroke();
                }
            }
            // the emblem: pulse, bloom, pop-out on hover
            ctx.globalCompositeOperation = 'source-over';
            let sc = (1 + beat * 0.04) * (1 + hover * 0.12), la = 1;
            if (boomT >= 0) {           // a big springy pulse when clicked
                const tb = boomT;
                sc *= tb < 0.12 ? 1 + 0.28 * (tb / 0.12) : 1 + 0.28 * Math.exp(-(tb - 0.12) * 4.5) * Math.cos((tb - 0.12) * 13);
            }
            if (has && la > 0.05) {
                ctx.fillStyle = `rgba(0,0,0,${(0.35 * la).toFixed(2)})`;
                ctx.beginPath(); ctx.ellipse(cx, cy + L * 0.52 * sc, L * 0.38 * sc, L * 0.06, 0, 0, TAU); ctx.fill();
            }
            if (la > 0.01) drawLogo(sc, la);
            ctx.globalCompositeOperation = 'lighter';
            if (la > 0.01) {
                drawLogo(sc * (1.04 + beat * 0.02), (0.14 + beat * 0.15 + hover * 0.15) * la);
                drawLogo(sc * (1.1 + beat * 0.04), (0.05 + beat * 0.08 + hover * 0.08) * la);
            }
            // sparks and pointer trail
            for (let i = sparks.length - 1; i >= 0; i--) {
                const s = sparks[i];
                s.life -= dt;
                if (s.life <= 0) { sparks.splice(i, 1); continue; }
                if (s.curl) {
                    const c = Math.cos(s.curl * dt), sn = Math.sin(s.curl * dt), vx = s.vx;
                    s.vx = vx * c - s.vy * sn; s.vy = vx * sn + s.vy * c;
                }
                s.vx *= Math.exp(-dt * 1.8); s.vy *= Math.exp(-dt * 1.8);
                const ox = s.x, oy = s.y;
                s.x += s.vx * dt; s.y += s.vy * dt;
                if (s.curl) {
                    const a2 = s.life / s.max;
                    ctx.strokeStyle = `rgba(${s.col},${(a2 * 0.5).toFixed(1)})`; ctx.lineWidth = s.r * 1.4;
                    ctx.beginPath(); ctx.moveTo(ox - s.vx * 0.04, oy - s.vy * 0.04); ctx.lineTo(s.x, s.y); ctx.stroke();
                }
                const a = s.life / s.max;
                ctx.fillStyle = `rgba(${s.col},${(a * 0.3).toFixed(2)})`; dot(s.x, s.y, s.r * 3);
                ctx.fillStyle = `rgba(235,220,255,${a.toFixed(2)})`; dot(s.x, s.y, s.r * 0.8);
            }
            ctx.lineCap = 'round';
            for (let i = trail.length - 1; i >= 0; i--) {
                const q = trail[i];
                q.life -= dt;
                if (q.life <= 0) { trail.splice(i, 1); continue; }
                q.vy += 700 * k * dt; q.vx *= Math.exp(-dt * 2);
                q.x += q.vx * dt; q.y += q.vy * dt;
                const a = q.life / q.max, tx = q.x - q.vx * 0.035, ty = q.y - q.vy * 0.035;
                ctx.strokeStyle = `rgba(${q.col},${(a * 0.35).toFixed(1)})`; ctx.lineWidth = 2.4;
                ctx.beginPath(); ctx.moveTo(q.x, q.y); ctx.lineTo(tx, ty); ctx.stroke();
                ctx.strokeStyle = `rgba(245,235,255,${(a * 0.8).toFixed(1)})`; ctx.lineWidth = 0.9;
                ctx.beginPath(); ctx.moveTo(q.x, q.y); ctx.lineTo(tx, ty); ctx.stroke();
            }
            if (p) {
                const cg = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, 26);
                cg.addColorStop(0, 'rgba(200,150,255,.2)'); cg.addColorStop(1, 'rgba(200,150,255,0)');
                ctx.fillStyle = cg; ctx.fillRect(p.x - 26, p.y - 26, 52, 52);
            }
            if (flash > 0.02) { ctx.fillStyle = `rgba(170,90,255,${(flash * 0.22).toFixed(2)})`; ctx.fillRect(0, 0, W, H); }
            ctx.globalCompositeOperation = 'source-over';
        }
        return {init, frame};
    })();

    /* Floating orbs: shimmering soap bubbles and bokeh lights, with optional wallpaper behind */
    const orbs = (() => {
        let O = [], bgL = null, t = 0, minR = 0, maxR = 0;
        const COL = [['80,255,170', 3], ['255,90,200', 3], ['170,90,255', 3], ['60,210,220', 2], ['255,150,90', 2]];
        // soap-film colours used around each bubble's rim
        const IRIS = ['255,120,200', '255,170,90', '255,235,140', '120,255,190', '90,210,255', '150,130,255', '220,110,255', '255,120,160'];
        let glitter = [];
        const totalW = COL.reduce((a, c) => a + c[1], 0);
        const pickCol = () => { let r = Math.random() * totalW; for (const [c, w] of COL) { if ((r -= w) < 0) return c; } return COL[0][0]; };
        function mk() {
            const a = rand(0, TAU);
            return {x: rand(0, W), y: rand(0, H), vx: Math.cos(a) * 20, vy: Math.sin(a) * 20, a, z: rand(0, 1), zt: rand(0, 1), zT: rand(2, 10),
                col: pickCol(), ring: Math.random() < 0.6, ph: rand(0, TAU), sp: rand(45, 110), spin: rand(-0.4, 0.4)};
        }
        function init() {
            t = 0; minR = H * 0.008; maxR = H * 0.075;
            bgL = makeLayer(W, H, env.rs);
            const g = bgL.ctx;
            const sky = g.createLinearGradient(0, 0, W, H);
            sky.addColorStop(0, '#04121e'); sky.addColorStop(0.5, '#0a0a24'); sky.addColorStop(1, '#10061e');
            g.fillStyle = sky; g.fillRect(0, 0, W, H);
            g.globalCompositeOperation = 'lighter';
            for (const [x, y, r, c, a] of [[W * 0.85, H * 0.15, 0.5, '255,140,120', 0.1], [W * 0.75, H * 0.3, 0.35, '255,90,200', 0.08], [W * 0.4, H * 0.55, 0.45, '40,200,200', 0.08], [W * 0.1, H * 0.8, 0.4, '120,80,255', 0.07]]) {
                const R = r * Math.max(W, H);
                const gr = g.createRadialGradient(x, y, 0, x, y, R);
                gr.addColorStop(0, `rgba(${c},${a})`); gr.addColorStop(1, `rgba(${c},0)`);
                g.fillStyle = gr; g.fillRect(x - R, y - R, R * 2, R * 2);
            }
            for (let i = 0; i < 10; i++) {
                const x = rand(0, W), y = rand(0, H), r = rand(0.15, 0.4) * Math.max(W, H), c = pickCol();
                const gr = g.createRadialGradient(x, y, 0, x, y, r);
                gr.addColorStop(0, `rgba(${c},.04)`); gr.addColorStop(1, `rgba(${c},0)`);
                g.fillStyle = gr; g.fillRect(x - r, y - r, r * 2, r * 2);
            }
            g.globalCompositeOperation = 'source-over';
            const n = Math.round(Math.max(40, Math.min(95, W * H / 24000)));
            O = Array.from({length: n}, mk);
            glitter = Array.from({length: Math.round(W * H / 9000)}, () => ({x: rand(0, W), y: rand(0, H), ph: rand(0, TAU), sp: rand(1, 3), vy: -rand(3, 12), c: IRIS[(Math.random() * IRIS.length) | 0]}));
        }
        function background() {
            const img = env.wall;
            if (!img) { ctx.drawImage(bgL, 0, 0); return; }
            const s2 = Math.max(W / img.w, H / img.h), w = img.w * s2, h = img.h * s2;
            ctx.fillStyle = '#000000'; ctx.fillRect(0, 0, W, H);
            ctx.drawImage(img, (W - w) / 2, (H - h) / 2, w, h);
            // blend it into the theme: darken, then wash it with the theme's colours
            const dim = (env.opts.orbsDim ?? 45) / 100;
            ctx.fillStyle = `rgba(8,3,26,${dim.toFixed(2)})`; ctx.fillRect(0, 0, W, H);
            ctx.globalAlpha = 0.5; ctx.drawImage(bgL, 0, 0); ctx.globalAlpha = 1;
        }
        function frame(dt) {
            t += dt;
            const k = H / 1080, p = env.pointer;
            const focus = 0.45 + Math.sin(t * 0.07) * 0.18;
            for (const o of O) {
                // wander, with nearer orbs drifting faster (parallax)
                o.a += rand(-1, 1) * dt * 1.3;
                const sp = o.sp * k * (0.4 + o.z * 1.2);
                o.vx += (Math.cos(o.a) * sp - o.vx) * dt * 0.9;
                o.vy += (Math.sin(o.a) * sp - o.vy) * dt * 0.9;
                // shy of the mouse
                if (p) {
                    const dx = o.x - p.x, dy = o.y - p.y, d = Math.hypot(dx, dy) || 1, R = 260 * k * (0.6 + o.z);
                    if (d < R) { const f = (1 - d / R) * 4200 * k * dt * (0.5 + o.z); o.vx += dx / d * f; o.vy += dy / d * f; }
                }
                const vmax = 900 * k;
                const v = Math.hypot(o.vx, o.vy);
                if (v > vmax) { o.vx *= vmax / v; o.vy *= vmax / v; }
                o.x += o.vx * dt; o.y += o.vy * dt;
                // bounce off the edges and corners of the screen
                const r = minR + (maxR - minR) * Math.pow(o.z, 1.4);
                if (o.x < r) { o.x = r; o.vx = Math.abs(o.vx); o.a = Math.PI - o.a; }
                if (o.x > W - r) { o.x = W - r; o.vx = -Math.abs(o.vx); o.a = Math.PI - o.a; }
                if (o.y < r) { o.y = r; o.vy = Math.abs(o.vy); o.a = -o.a; }
                if (o.y > H - r) { o.y = H - r; o.vy = -Math.abs(o.vy); o.a = -o.a; }
                // drift closer and further away
                o.zT -= dt;
                if (o.zT <= 0) { o.zt = rand(0, 1); o.zT = rand(4, 12); }
                o.z += (o.zt - o.z) * dt * 0.22;
            }
            O.sort((a, b) => a.z - b.z);
            background();
            ctx.globalCompositeOperation = 'lighter';
            // glitter drifting in the light
            for (const g of glitter) {
                g.y += g.vy * k * dt;
                if (g.y < -4) { g.y = H + 4; g.x = rand(0, W); }
                const tw = Math.max(0, Math.sin(t * g.sp + g.ph));
                if (tw < 0.2) continue;
                ctx.fillStyle = `rgba(${g.c},${(tw * 0.7).toFixed(2)})`; dot(g.x, g.y, 0.8 + tw * 0.8);
            }
            for (const o of O) {
                const r = minR + (maxR - minR) * Math.pow(o.z, 1.4);
                const b = Math.min(1, Math.abs(o.z - focus) * 2.4);      // 0 = sharp, 1 = blurred
                const a = (0.5 + 0.5 * (1 - b)) * (0.45 + 0.55 * o.z) * (0.88 + 0.12 * Math.sin(t * 1.3 + o.ph));
                // out of focus: a soft, flat bokeh disc in the orb's colour
                const bok = o.ring ? Math.max(0, (b - 0.35) / 0.65) : 1;
                if (bok > 0.02) {
                    const R = r * (1 + b * 0.4);
                    const gr = ctx.createRadialGradient(o.x, o.y, 0, o.x, o.y, R);
                    const fa = (0.3 - 0.12 * b) * a * bok;
                    gr.addColorStop(0, `rgba(${o.col},${(fa * 0.8).toFixed(3)})`);
                    gr.addColorStop(0.82, `rgba(${o.col},${fa.toFixed(3)})`);
                    gr.addColorStop(1, `rgba(${o.col},0)`);
                    ctx.fillStyle = gr; ctx.fillRect(o.x - R, o.y - R, R * 2, R * 2);
                }
                // in focus: a glassy soap bubble with a rainbow rim and highlights
                const bub = o.ring ? 1 - bok : 0;
                if (bub < 0.02) continue;
                const ba = a * bub;
                const inner = ctx.createRadialGradient(o.x - r * 0.2, o.y - r * 0.25, r * 0.1, o.x, o.y, r);
                inner.addColorStop(0, `rgba(90,210,255,${(0.05 * ba).toFixed(3)})`);
                inner.addColorStop(0.8, `rgba(${o.col},${(0.1 * ba).toFixed(3)})`);
                inner.addColorStop(1, `rgba(255,255,255,${(0.22 * ba).toFixed(3)})`);
                ctx.fillStyle = inner; dot(o.x, o.y, r);
                const segs = IRIS.length, rot = o.ph + t * o.spin;
                ctx.lineCap = 'round';
                for (const [lw, al] of [[r * 0.16, 0.18], [Math.max(1, r * 0.055), 0.75]]) {
                    ctx.lineWidth = lw;
                    for (let i = 0; i < segs; i++) {
                        const a0 = rot + i * TAU / segs;
                        ctx.strokeStyle = `rgba(${IRIS[i]},${(al * ba).toFixed(3)})`;
                        ctx.beginPath(); ctx.arc(o.x, o.y, r * 0.95, a0, a0 + TAU / segs + 0.02); ctx.stroke();
                    }
                }
                // warm reflection along the lower inside edge
                ctx.strokeStyle = `rgba(255,170,110,${(0.4 * ba).toFixed(3)})`; ctx.lineWidth = Math.max(1, r * 0.07);
                ctx.beginPath(); ctx.arc(o.x, o.y, r * 0.8, Math.PI * 0.15, Math.PI * 0.75); ctx.stroke();
                // window highlight and a small second glint
                ctx.fillStyle = `rgba(255,255,255,${(0.75 * ba).toFixed(3)})`;
                ctx.beginPath(); ctx.ellipse(o.x - r * 0.38, o.y - r * 0.42, r * 0.2, r * 0.11, -0.7, 0, TAU); ctx.fill();
                ctx.fillStyle = `rgba(255,255,255,${(0.45 * ba).toFixed(3)})`; dot(o.x + r * 0.45, o.y + r * 0.38, r * 0.06);
                // a twinkling star on the sharpest bubbles
                if (b < 0.2) {
                    const tw = Math.max(0, Math.sin(t * 2.2 + o.ph * 3)), L2 = r * 0.35 * tw;
                    if (tw > 0.1) {
                        const sx = o.x - r * 0.25, sy = o.y - r * 0.1;
                        ctx.strokeStyle = `rgba(255,255,255,${(0.8 * tw * ba).toFixed(2)})`; ctx.lineWidth = 1;
                        ctx.beginPath(); ctx.moveTo(sx - L2, sy); ctx.lineTo(sx + L2, sy); ctx.moveTo(sx, sy - L2); ctx.lineTo(sx, sy + L2); ctx.stroke();
                    }
                }
            }
            ctx.globalCompositeOperation = 'source-over';
        }
        return {init, frame};
    })();

    /* Fireflies in a night forest, with a campfire */
    const fireflies = (() => {
        let F = [], E = [], backL = null, nearL = null, fire = null, t = 0, burst = 3;
        const glow = makeLayer(64, 64);
        const gr = glow.ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
        gr.addColorStop(0, 'rgba(255,248,180,1)'); gr.addColorStop(0.18, 'rgba(225,255,120,.7)'); gr.addColorStop(1, 'rgba(150,255,80,0)');
        glow.ctx.fillStyle = gr; glow.ctx.fillRect(0, 0, 64, 64);
        const disc = (g, x, y, r) => { g.beginPath(); g.arc(x, y, r, 0, TAU); g.fill(); };

        // Conifer: stacked tiers with ragged, drooping edges.
        function pine(g, x, base, h) {
            g.fillRect(x - h * 0.018, base - h * 0.12, h * 0.036, h * 0.14);
            const tiers = 9, teeth = 4;
            for (let k = 0; k < tiers; k++) {
                const f = k / tiers;
                const y0 = base - h * 0.08 - f * h * 0.8;
                const half = h * 0.26 * (1 - f * 0.85);
                const top = y0 - h * 0.2 * (1 - f * 0.4);
                g.beginPath();
                g.moveTo(x, top);
                g.lineTo(x - half, y0 + h * 0.015);
                for (let i = 1; i <= teeth * 2; i++) {
                    const px = x - half + 2 * half * i / (teeth * 2);
                    const py = i % 2 ? y0 - h * 0.03 : y0 + h * 0.012 * rand(0.5, 1.5);
                    g.lineTo(px, py);
                }
                g.closePath();
                g.fill();
            }
        }

        // Broadleaf: a branching trunk with leafy clusters at the tips.
        function branch(g, x, y, ang, len, w, depth) {
            const x2 = x + Math.cos(ang) * len, y2 = y + Math.sin(ang) * len;
            g.lineWidth = Math.max(0.8, w);
            g.beginPath(); g.moveTo(x, y); g.lineTo(x2, y2); g.stroke();
            if (depth <= 1) {
                // Leafy clump around the twig tips; overlapping blobs make a soft canopy edge.
                const k = depth <= 0 ? 7 : 4;
                for (let i = 0; i < k; i++) {
                    g.beginPath();
                    g.ellipse(x2 + rand(-1, 1) * len * 0.9, y2 + rand(-1.1, 0.5) * len * 0.9, len * rand(0.45, 0.95), len * rand(0.35, 0.7), rand(0, TAU), 0, TAU);
                    g.fill();
                }
                if (depth <= 0 || len < 3)
                    return;
            }
            const n = Math.random() < 0.3 ? 3 : 2;
            for (let i = 0; i < n; i++) {
                const spread = n === 2 ? (i ? 1 : -1) * rand(0.25, 0.6) : (i - 1) * rand(0.35, 0.6);
                branch(g, x2, y2, ang + spread + rand(-0.12, 0.12), len * rand(0.66, 0.8), w * 0.68, depth - 1);
            }
        }
        function broadleaf(g, x, base, h, depth) {
            g.lineCap = 'round';
            branch(g, x, base, -Math.PI / 2 + rand(-0.06, 0.06), h * 0.28, h * 0.06, depth);
        }

        // A person sitting on a stump, leaning toward the fire (dir = +1 faces right).
        function seated(g, x, base, s, dir) {
            g.lineCap = 'round';
            g.fillRect(x - s * 0.26, base - s * 0.2, s * 0.5, s * 0.2);
            const hipY = base - s * 0.26;
            g.lineWidth = s * 0.12;
            g.beginPath(); g.moveTo(x, hipY); g.lineTo(x + dir * s * 0.3, base - s * 0.36); g.lineTo(x + dir * s * 0.36, base); g.stroke();
            g.lineWidth = s * 0.24;
            g.beginPath(); g.moveTo(x - dir * s * 0.02, hipY); g.lineTo(x + dir * s * 0.05, base - s * 0.68); g.stroke();
            disc(g, x + dir * s * 0.09, base - s * 0.79, s * 0.105);
            g.lineWidth = s * 0.07;
            g.beginPath(); g.moveTo(x + dir * s * 0.05, base - s * 0.66); g.lineTo(x + dir * s * 0.08, base - s * 0.74); g.stroke();
            g.lineWidth = s * 0.08;
            g.beginPath(); g.moveTo(x + dir * s * 0.06, base - s * 0.64); g.lineTo(x + dir * s * 0.28, base - s * 0.44); g.lineTo(x + dir * s * 0.42, base - s * 0.52); g.stroke();
        }

        function init() {
            t = 0; E = []; burst = rand(2, 5);
            const gy = H * 0.95;
            fire = {x: W * 0.5 + rand(-W * 0.08, W * 0.08), base: H * 0.968, s: Math.max(9, H * 0.027)};

            backL = makeLayer(W, H, env.rs);
            let g = backL.ctx;
            const sky = g.createLinearGradient(0, 0, 0, H);
            sky.addColorStop(0, '#02040d'); sky.addColorStop(0.65, '#0a1430'); sky.addColorStop(1, '#101c38');
            g.fillStyle = sky; g.fillRect(0, 0, W, H);
            const ns = Math.round(W * H / 6000);
            for (let i = 0; i < ns; i++) {
                g.fillStyle = `rgba(255,255,255,${rand(0.2, 0.9).toFixed(2)})`;
                const sz = rand(0.6, 1.6);
                g.fillRect(rand(0, W), rand(0, H * 0.65), sz, sz);
            }
            const mx = W * 0.8, my = H * 0.18, mr = Math.max(14, Math.min(W, H) * 0.045);
            const halo = g.createRadialGradient(mx, my, mr, mx, my, mr * 5);
            halo.addColorStop(0, 'rgba(220,225,255,.18)'); halo.addColorStop(1, 'rgba(220,225,255,0)');
            g.fillStyle = halo; g.fillRect(mx - mr * 5, my - mr * 5, mr * 10, mr * 10);
            g.fillStyle = '#efe9d2'; disc(g, mx, my, mr);
            g.fillStyle = 'rgba(0,0,0,.08)';
            for (const [dx, dy, r] of [[-0.3, -0.2, 0.22], [0.25, 0.1, 0.18], [-0.05, 0.35, 0.12]]) disc(g, mx + dx * mr, my + dy * mr, r * mr);

            // Distant treeline
            g.fillStyle = '#0b1526'; g.strokeStyle = '#0b1526';
            const base = H * 0.8;
            let x = -40;
            while (x < W + 60) {
                const h = H * rand(0.16, 0.32);
                if (Math.random() < 0.65) pine(g, x, base + rand(0, 10), h);
                else broadleaf(g, x, base + rand(0, 10), h * 1.1, 5);
                x += rand(25, 70);
            }
            g.fillRect(0, base, W, H - base);

            // Foreground trees, ground, campers
            nearL = makeLayer(W, H, env.rs);
            g = nearL.ctx;
            g.fillStyle = '#010302'; g.strokeStyle = '#010302';
            x = rand(-80, 40);
            while (x < W + 100) {
                if (Math.abs(x - fire.x) > W * 0.14) {
                    const h = H * rand(0.5, 0.85);
                    if (Math.random() < 0.5) pine(g, x, H + 5, h);
                    else broadleaf(g, x, H + 5, h, 7);
                }
                x += rand(180, 360);
            }
            g.fillRect(0, gy, W, H - gy + 2);
            g.lineWidth = 1.5; g.lineCap = 'round';
            g.beginPath();
            for (let gx = 0; gx < W; gx += 3) { g.moveTo(gx, gy + 2); g.lineTo(gx + rand(-3, 3), gy - rand(3, 11)); }
            g.stroke();

            const ps = H * 0.1, fs = fire.s;
            seated(g, fire.x - fs * 4.2, fire.base, ps, 1);
            seated(g, fire.x - fs * 7.6, fire.base + 2, ps * 1.06, 1);
            seated(g, fire.x + fs * 4.4, fire.base, ps * 0.96, -1);

            g.strokeStyle = '#140a05'; g.lineWidth = fs * 0.3; g.lineCap = 'round';
            g.beginPath();
            g.moveTo(fire.x - fs * 1.3, fire.base + fs * 0.1); g.lineTo(fire.x + fs * 1.1, fire.base - fs * 0.35);
            g.moveTo(fire.x + fs * 1.3, fire.base + fs * 0.1); g.lineTo(fire.x - fs * 1.1, fire.base - fs * 0.35);
            g.stroke();

            const n = Math.round(Math.max(35, Math.min(90, W * H / 20000)));
            F = Array.from({length: n}, () => {
                const far = Math.random() < 0.5;
                return {far, x: rand(0, W), y: rand(H * 0.35, H * 0.92), vx: rand(-15, 15), vy: rand(-15, 15), ph: rand(0, TAU), rate: rand(0.8, 2.2), s: rand(18, 40) * (far ? 0.6 : 1)};
            });
        }

        function flies(dt, far) {
            ctx.globalCompositeOperation = 'lighter';
            for (const f of F) {
                if (f.far !== far) continue;
                f.vx += rand(-60, 60) * dt; f.vy += rand(-60, 60) * dt;
                if (f.y < H * 0.3) f.vy += 40 * dt;
                if (f.y > H * 0.93) f.vy -= 40 * dt;
                const damp = 1 - Math.min(1, dt * 0.6);
                f.vx *= damp; f.vy *= damp;
                f.x += f.vx * dt; f.y += f.vy * dt;
                if (f.x < -40) f.x = W + 40;
                if (f.x > W + 40) f.x = -40;
                f.ph += f.rate * dt;
                const b = Math.pow(Math.max(0, Math.sin(f.ph)), 3);
                ctx.globalAlpha = (0.12 + b * 0.88) * (far ? 0.7 : 1);
                ctx.drawImage(glow, f.x - f.s / 2, f.y - f.s / 2, f.s, f.s);
            }
            ctx.globalAlpha = 1;
            ctx.globalCompositeOperation = 'source-over';
        }

        function drawFire() {
            const {x, base, s} = fire;
            const flick = Math.max(0.6, 0.88 + 0.12 * Math.sin(t * 13) * Math.sin(t * 7.3 + 1) + rand(-0.05, 0.05));
            ctx.globalCompositeOperation = 'lighter';
            const g = ctx.createRadialGradient(x, base - s, 0, x, base - s, s * 10);
            g.addColorStop(0, `rgba(255,140,50,${(0.4 * flick).toFixed(2)})`);
            g.addColorStop(0.35, `rgba(200,80,20,${(0.14 * flick).toFixed(2)})`);
            g.addColorStop(1, 'rgba(0,0,0,0)');
            ctx.fillStyle = g;
            ctx.fillRect(x - s * 10, base - s * 11, s * 20, s * 14);
            const layers = [['rgba(255,70,20,.55)', 1, 1], ['rgba(255,150,40,.6)', 0.75, 0.72], ['rgba(255,230,140,.7)', 0.45, 0.42]];
            for (const [col, wf, hf] of layers) {
                ctx.fillStyle = col;
                for (let i = 0; i < 4; i++) {
                    const off = (i - 1.5) * s * 0.35 * wf;
                    const hh = s * 2.4 * hf * (0.75 + 0.3 * Math.sin(t * (6 + i * 1.7) + i * 2)) * flick;
                    const sway = Math.sin(t * (3 + i) + i) * s * 0.25;
                    const w = s * 0.55 * wf, cx = x + off;
                    ctx.beginPath();
                    ctx.moveTo(cx - w, base);
                    ctx.bezierCurveTo(cx - w, base - hh * 0.45, cx + sway - w * 0.2, base - hh * 0.7, cx + sway, base - hh);
                    ctx.bezierCurveTo(cx + sway + w * 0.2, base - hh * 0.7, cx + w, base - hh * 0.45, cx + w, base);
                    ctx.closePath();
                    ctx.fill();
                }
            }
            ctx.globalCompositeOperation = 'source-over';
        }

        function spawnEmber(pop) {
            const life = rand(1.5, 3.5);
            E.push({x: fire.x + rand(-0.5, 0.5) * fire.s, y: fire.base - fire.s * rand(0.5, 1.5),
                vx: rand(-20, 20) * (pop ? 2.5 : 1), vy: -rand(30, 70) * (pop ? 1.8 : 1), life, max: life, r: rand(0.8, 1.8), ph: rand(0, 6)});
        }
        function embers(dt) {
            burst -= dt;
            if (burst <= 0) {
                const n = rand(8, 20) | 0;
                for (let i = 0; i < n; i++) spawnEmber(true);
                burst = rand(2, 6);
            }
            if (Math.random() < dt * 5) spawnEmber(false);
            ctx.globalCompositeOperation = 'lighter';
            for (let i = E.length - 1; i >= 0; i--) {
                const e = E[i];
                e.life -= dt;
                if (e.life <= 0) { E.splice(i, 1); continue; }
                e.vx += rand(-40, 40) * dt; e.vy -= 10 * dt;
                e.x += e.vx * dt; e.y += e.vy * dt;
                e.ph += dt * 20;
                const a = e.life / e.max, tw = 0.6 + 0.4 * Math.sin(e.ph);
                ctx.fillStyle = `rgba(255,${(150 + a * 80) | 0},60,${(a * tw).toFixed(2)})`;
                dot(e.x, e.y, e.r);
            }
            ctx.globalCompositeOperation = 'source-over';
        }

        function frame(dt) {
            t += dt;
            ctx.drawImage(backL, 0, 0);
            flies(dt, true);
            ctx.drawImage(nearL, 0, 0);
            drawFire();
            embers(dt);
            flies(dt, false);
        }
        return {init, frame};
    })();

    return {matrix, code, storm, cyclone: storm, spiders: critters, starfield, fireflies, kittens, cursorcat, neon, orbs};
}

/* ---------- Engine: one per monitor ---------- */
export class Engine {
    constructor(width, height, rs = 1) {
        this.W = width;
        this.H = height;
        this.rs = rs;
        this.main = makeLayer(width, height, rs);
        this.ctx = this.main.ctx;
        this.pointer = null;
        this.logo = null;
        this.wall = null;
        this.opts = {};
        this.themes = makeThemes(this);
        this.current = null;
    }

    setTheme(id) {
        this.current = this.themes[id] ?? this.themes.matrix;
        this.ctx.globalAlpha = 1;
        this.ctx.globalCompositeOperation = 'source-over';
        this.current.init();
    }

    setLogo(logo) {
        this.logo = logo;
    }

    setWallpaper(img) {
        this.wall = img;
    }

    setOption(key, value) {
        this.opts[key] = value;
    }

    step(dt, pointer) {
        this.pointer = pointer;
        this.current?.frame(dt);
    }

    paint(cr) {
        cr.setSourceSurface(this.main.surface, 0, 0);
        cr.paint();
    }

    destroy() {
        this.current = null;
        this.themes = null;
        try {
            this.main.surface.finish();
        } catch (e) {}
    }
}
